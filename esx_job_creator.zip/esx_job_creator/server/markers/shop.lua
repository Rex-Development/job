local L0_1, L1_1, L2_1, L3_1
function L0_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2
  L3_2 = canUseMarkerWithLog
  L4_2 = A0_2
  L5_2 = A2_2
  L3_2 = L3_2(L4_2, L5_2)
  if not L3_2 then
    return
  end
  L3_2 = JobsCreator
  L3_2 = L3_2.Markers
  L3_2 = L3_2[A2_2]
  L3_2 = L3_2.data
  if not L3_2 then
    L3_2 = {}
  end
  L4_2 = {}
  L5_2 = L3_2.itemsOnSale
  if L5_2 then
    L5_2 = pairs
    L6_2 = L3_2.itemsOnSale
    L5_2, L6_2, L7_2, L8_2 = L5_2(L6_2)
    for L9_2, L10_2 in L5_2, L6_2, L7_2, L8_2 do
      L11_2 = nil
      L12_2 = nil
      L13_2 = Framework
      L13_2 = L13_2.getFramework
      L13_2 = L13_2()
      if "ESX" == L13_2 then
        L13_2 = ESX
        L13_2 = L13_2.GetWeaponLabel
        L14_2 = L9_2
        L13_2 = L13_2(L14_2)
        L11_2 = L13_2
        L12_2 = "item_weapon"
        if not L11_2 then
          L12_2 = "item_standard"
          L13_2 = Framework
          L13_2 = L13_2.getItemLabel
          L14_2 = L9_2
          L13_2 = L13_2(L14_2)
          L11_2 = L13_2
        end
      else
        L13_2 = Framework
        L13_2 = L13_2.getFramework
        L13_2 = L13_2()
        if "QB-core" == L13_2 then
          L13_2 = Framework
          L13_2 = L13_2.getItemLabel
          L14_2 = L9_2
          L13_2 = L13_2(L14_2)
          L11_2 = L13_2
          L13_2 = QBCore
          L13_2 = L13_2.Shared
          L13_2 = L13_2.Weapons
          L14_2 = GetHashKey
          L15_2 = L9_2
          L14_2 = L14_2(L15_2)
          L13_2 = L13_2[L14_2]
          if L13_2 then
            L12_2 = "item_weapon"
          else
            L12_2 = "item_standard"
          end
        end
      end
      if L11_2 then
        L13_2 = L10_2.blackMoney
        if L13_2 then
          L13_2 = "orange"
          if L13_2 then
            goto lbl_77
          end
        end
        L13_2 = "green"
        ::lbl_77::
        L14_2 = table
        L14_2 = L14_2.insert
        L15_2 = L4_2
        L16_2 = {}
        L17_2 = getLocalizedText
        L18_2 = "shop:item"
        L19_2 = L11_2
        L20_2 = L13_2
        L21_2 = L10_2.price
        L17_2 = L17_2(L18_2, L19_2, L20_2, L21_2)
        L16_2.label = L17_2
        L16_2.value = L9_2
        L16_2.itemType = L12_2
        L14_2(L15_2, L16_2)
      end
    end
  end
  L5_2 = #L4_2
  if 0 == L5_2 then
    L5_2 = table
    L5_2 = L5_2.insert
    L6_2 = L4_2
    L7_2 = {}
    L8_2 = getLocalizedText
    L9_2 = "shop_empty"
    L8_2 = L8_2(L9_2)
    L7_2.label = L8_2
    L5_2(L6_2, L7_2)
  end
  L5_2 = A1_2
  L6_2 = L4_2
  L5_2(L6_2)
end
L1_1 = RegisterServerCallback
L2_1 = Utils
L2_1 = L2_1.eventsPrefix
L3_1 = ":getShopData"
L2_1 = L2_1 .. L3_1
L3_1 = L0_1
L1_1(L2_1, L3_1)
L1_1 = RegisterNetEvent
L2_1 = Utils
L2_1 = L2_1.eventsPrefix
L3_1 = ":buyShopItem"
L2_1 = L2_1 .. L3_1
L1_1(L2_1)
L1_1 = AddEventHandler
L2_1 = Utils
L2_1 = L2_1.eventsPrefix
L3_1 = ":buyShopItem"
L2_1 = L2_1 .. L3_1
function L3_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2
  L3_2 = source
  L4_2 = JobsCreator
  L4_2 = L4_2.Markers
  L4_2 = L4_2[A0_2]
  L4_2 = L4_2.data
  if not L4_2 then
    L4_2 = {}
  end
  L5_2 = L4_2.itemsOnSale
  L5_2 = L5_2[A1_2]
  L5_2 = L5_2.price
  L6_2 = L4_2.itemsOnSale
  L6_2 = L6_2[A1_2]
  L6_2 = L6_2.blackMoney
  L7_2 = L5_2 * A2_2
  L8_2 = nil
  L9_2 = nil
  L10_2 = Framework
  L10_2 = L10_2.getFramework
  L10_2 = L10_2()
  if "ESX" == L10_2 then
    L10_2 = ESX
    L10_2 = L10_2.GetWeaponLabel
    L11_2 = A1_2
    L10_2 = L10_2(L11_2)
    L8_2 = L10_2
    L9_2 = "item_weapon"
    if L8_2 then
      L10_2 = INVENTORY_TO_USE
    end
    if "qs-inventory" == L10_2 then
      L9_2 = "item_standard"
      L10_2 = Framework
      L10_2 = L10_2.getItemLabel
      L11_2 = A1_2
      L10_2 = L10_2(L11_2)
      L8_2 = L10_2
    end
  else
    L10_2 = Framework
    L10_2 = L10_2.getFramework
    L10_2 = L10_2()
    if "QB-core" == L10_2 then
      L10_2 = Framework
      L10_2 = L10_2.getItemLabel
      L11_2 = A1_2
      L10_2 = L10_2(L11_2)
      L8_2 = L10_2
      L10_2 = QBCore
      L10_2 = L10_2.Shared
      L10_2 = L10_2.Weapons
      L11_2 = GetHashKey
      L12_2 = A1_2
      L11_2 = L11_2(L12_2)
      L10_2 = L10_2[L11_2]
      if L10_2 then
        L9_2 = "item_weapon"
      else
        L9_2 = "item_standard"
      end
    end
  end
  L10_2 = L4_2.itemsOnSale
  if L10_2 and L5_2 then
    L10_2 = false
    if "item_standard" == L9_2 then
      L11_2 = Framework
      L11_2 = L11_2.canPlayerCarryItem
      L12_2 = L3_2
      L13_2 = A1_2
      L14_2 = A2_2
      L11_2 = L11_2(L12_2, L13_2, L14_2)
      if L11_2 then
        L10_2 = true
      else
        L11_2 = notify
        L12_2 = L3_2
        L13_2 = getLocalizedText
        L14_2 = "no_space"
        L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2 = L13_2(L14_2)
        L11_2(L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2)
      end
    elseif "item_weapon" == L9_2 then
      L11_2 = Framework
      L11_2 = L11_2.getFramework
      L11_2 = L11_2()
      if "QB-core" ~= L11_2 then
        L11_2 = Framework
        L11_2 = L11_2.getFramework
        L11_2 = L11_2()
        if "ESX" ~= L11_2 then
          goto lbl_110
        end
        L11_2 = Framework
        L11_2 = L11_2.hasPlayerWeapon
        L12_2 = L3_2
        L13_2 = A1_2
        L11_2 = L11_2(L12_2, L13_2)
        if L11_2 then
          goto lbl_110
        end
      end
      L10_2 = true
      goto lbl_117
      ::lbl_110::
      L11_2 = notify
      L12_2 = L3_2
      L13_2 = getLocalizedText
      L14_2 = "shop:you_already_have_that_weapon"
      L15_2 = L8_2
      L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2 = L13_2(L14_2, L15_2)
      L11_2(L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2)
    end
    ::lbl_117::
    if not L10_2 then
      goto lbl_258
    end
    L11_2 = false
    if L6_2 then
      L12_2 = Framework
      L12_2 = L12_2.getFramework
      L12_2 = L12_2()
      if "ESX" == L12_2 then
        L12_2 = Framework
        L12_2 = L12_2.getIdentifier
        L13_2 = L3_2
        L12_2 = L12_2(L13_2)
        L13_2 = Framework
        L13_2 = L13_2.getAccountMoneyFromIdentifier
        L14_2 = L12_2
        L15_2 = "black_money"
        L13_2 = L13_2(L14_2, L15_2)
        if L7_2 <= L13_2 then
          L13_2 = Framework
          L13_2 = L13_2.removeAccountMoneyFromIdentifier
          L14_2 = L12_2
          L15_2 = "black_money"
          L16_2 = L7_2
          L13_2(L14_2, L15_2, L16_2)
          L11_2 = true
        end
      else
        L12_2 = Framework
        L12_2 = L12_2.getFramework
        L12_2 = L12_2()
        if "QB-core" == L12_2 then
          L12_2 = Framework
          L12_2 = L12_2.getBlackMoneyValue
          L13_2 = L3_2
          L12_2 = L12_2(L13_2)
          if L7_2 <= L12_2 then
            L12_2 = Framework
            L12_2 = L12_2.removeBlackMoneyValue
            L13_2 = L3_2
            L14_2 = L7_2
            L12_2(L13_2, L14_2)
            L11_2 = true
          end
        end
      end
    else
      L12_2 = payInSomeWay
      L13_2 = L3_2
      L14_2 = L7_2
      L12_2 = L12_2(L13_2, L14_2)
      if L12_2 then
        L11_2 = true
      end
    end
    if L11_2 then
      if "item_standard" == L9_2 then
        L12_2 = Framework
        L12_2 = L12_2.giveItemToPlayer
        L13_2 = L3_2
        L14_2 = A1_2
        L15_2 = A2_2
        L12_2(L13_2, L14_2, L15_2)
      elseif "item_weapon" == L9_2 then
        L12_2 = Framework
        L12_2 = L12_2.giveWeaponToPlayer
        L13_2 = L3_2
        L14_2 = A1_2
        L15_2 = 60
        L12_2(L13_2, L14_2, L15_2)
      end
      if L6_2 then
        L12_2 = "r"
        if L12_2 then
          goto lbl_196
        end
      end
      L12_2 = "g"
      ::lbl_196::
      L13_2 = notify
      L14_2 = L3_2
      L15_2 = getLocalizedText
      L16_2 = "you_bought"
      L17_2 = A2_2
      L18_2 = L8_2
      L19_2 = L12_2
      L20_2 = Framework
      L20_2 = L20_2.groupDigits
      L21_2 = L7_2
      L20_2, L21_2 = L20_2(L21_2)
      L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2 = L15_2(L16_2, L17_2, L18_2, L19_2, L20_2, L21_2)
      L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2)
      L13_2 = log
      L14_2 = L3_2
      L15_2 = getLocalizedText
      L16_2 = "log_bought_item"
      L15_2 = L15_2(L16_2)
      L16_2 = getLocalizedText
      L17_2 = "log_bought_item_description"
      L18_2 = A2_2
      L19_2 = L8_2
      L20_2 = A1_2
      L21_2 = A0_2
      L16_2 = L16_2(L17_2, L18_2, L19_2, L20_2, L21_2)
      L17_2 = "success"
      L18_2 = "shop"
      L13_2(L14_2, L15_2, L16_2, L17_2, L18_2)
      L13_2 = TriggerEvent
      L14_2 = Utils
      L14_2 = L14_2.eventsPrefix
      L15_2 = ":shop:boughtItem"
      L14_2 = L14_2 .. L15_2
      L15_2 = L3_2
      L16_2 = A0_2
      L17_2 = A1_2
      L18_2 = A2_2
      L19_2 = L7_2
      L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2)
    else
      L12_2 = notify
      L13_2 = L3_2
      L14_2 = getLocalizedText
      L15_2 = "not_enough_money"
      L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2 = L14_2(L15_2)
      L12_2(L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2)
    end
  elseif not L5_2 then
    L10_2 = log
    L11_2 = L3_2
    L12_2 = getLocalizedText
    L13_2 = "log_not_existing_item"
    L12_2 = L12_2(L13_2)
    L13_2 = getLocalizedText
    L14_2 = "log_not_existing_item_description"
    L15_2 = A1_2
    L16_2 = A0_2
    L13_2 = L13_2(L14_2, L15_2, L16_2)
    L14_2 = "error"
    L15_2 = "shop"
    L10_2(L11_2, L12_2, L13_2, L14_2, L15_2)
  end
  ::lbl_258::
end
L1_1(L2_1, L3_1)

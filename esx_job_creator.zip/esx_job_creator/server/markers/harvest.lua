local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1
L0_1 = {}
function L1_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2
  L3_2 = L0_1
  L3_2[A0_2] = false
  L3_2 = TriggerClientEvent
  L4_2 = Utils
  L4_2 = L4_2.eventsPrefix
  L5_2 = ":harvest:finishedHarvesting"
  L4_2 = L4_2 .. L5_2
  L5_2 = A0_2
  L6_2 = A1_2
  L7_2 = A2_2
  L3_2(L4_2, L5_2, L6_2, L7_2)
end
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2
  L1_2 = source
  L2_2 = canUseMarkerWithLog
  L3_2 = L1_2
  L4_2 = A0_2
  L2_2 = L2_2(L3_2, L4_2)
  if not L2_2 then
    return
  end
  L2_2 = L0_1
  L2_2 = L2_2[L1_2]
  if L2_2 then
    return
  end
  L2_2 = JobsCreator
  L2_2 = L2_2.Markers
  L2_2 = L2_2[A0_2]
  L2_2 = L2_2.data
  if L2_2 then
    L2_2 = JobsCreator
    L2_2 = L2_2.Markers
    L2_2 = L2_2[A0_2]
    L2_2 = L2_2.data
    L2_2 = L2_2.harvestableItems
    L3_2 = getRandomElementFromTable
    L4_2 = L2_2
    L3_2 = L3_2(L4_2)
    L4_2 = math
    L4_2 = L4_2.random
    L5_2 = L3_2.minQuantity
    L6_2 = L3_2.maxQuantity
    L4_2 = L4_2(L5_2, L6_2)
    L5_2 = L3_2.name
    L6_2 = Framework
    L6_2 = L6_2.doesItemExists
    L7_2 = L5_2
    L6_2 = L6_2(L7_2)
    if not L6_2 then
      L6_2 = print
      L7_2 = "Item '"
      L8_2 = L5_2
      L9_2 = "' does not exists in harvest marker '"
      L10_2 = A0_2
      L11_2 = "'"
      L7_2 = L7_2 .. L8_2 .. L9_2 .. L10_2 .. L11_2
      L6_2(L7_2)
      L6_2 = L1_1
      L7_2 = L1_2
      L8_2 = A0_2
      L9_2 = false
      L6_2(L7_2, L8_2, L9_2)
      return
    end
    L6_2 = L3_2.time
    L7_2 = JobsCreator
    L7_2 = L7_2.Markers
    L7_2 = L7_2[A0_2]
    L7_2 = L7_2.data
    L7_2 = L7_2.animations
    if not L7_2 then
      L7_2 = {}
    end
    L8_2 = JobsCreator
    L8_2 = L8_2.Markers
    L8_2 = L8_2[A0_2]
    L8_2 = L8_2.data
    L8_2 = L8_2.itemTool
    if L8_2 then
      L9_2 = Framework
      L9_2 = L9_2.doesItemExists
      L10_2 = L8_2
      L9_2 = L9_2(L10_2)
      if not L9_2 then
        L9_2 = print
        L10_2 = "Item tool '"
        L11_2 = L8_2
        L12_2 = "' does not exists in harvest marker '"
        L13_2 = A0_2
        L14_2 = "'"
        L10_2 = L10_2 .. L11_2 .. L12_2 .. L13_2 .. L14_2
        L9_2(L10_2)
        L9_2 = L1_1
        L10_2 = L1_2
        L11_2 = A0_2
        L12_2 = false
        L9_2(L10_2, L11_2, L12_2)
        return
      end
    end
    L9_2 = JobsCreator
    L9_2 = L9_2.Markers
    L9_2 = L9_2[A0_2]
    L9_2 = L9_2.data
    L9_2 = L9_2.itemToolLoseQuantity
    L10_2 = JobsCreator
    L10_2 = L10_2.Markers
    L10_2 = L10_2[A0_2]
    L10_2 = L10_2.data
    L10_2 = L10_2.itemToolLoseProbability
    L11_2 = JobsCreator
    L11_2 = L11_2.Markers
    L11_2 = L11_2[A0_2]
    L11_2 = L11_2.data
    L11_2 = L11_2.disappearAfterUse
    L12_2 = JobsCreator
    L12_2 = L12_2.Markers
    L12_2 = L12_2[A0_2]
    L12_2 = L12_2.data
    L12_2 = L12_2.disappearSeconds
    L13_2 = #L7_2
    if 0 == L13_2 then
      L13_2 = table
      L13_2 = L13_2.insert
      L14_2 = L7_2
      L15_2 = {}
      L15_2.type = "animation"
      L15_2.animDict = "random@mugging4"
      L15_2.animName = "pickup_low"
      L15_2.animDuration = L6_2
      L13_2(L14_2, L15_2)
    end
    if L5_2 and L4_2 and L6_2 then
      L13_2 = JobsCreator
      L13_2 = L13_2.Markers
      L13_2 = L13_2[A0_2]
      L13_2 = L13_2.data
      L13_2 = L13_2.requiresMinimumAccountMoney
      if L13_2 then
        L13_2 = JobsCreator
        L13_2 = L13_2.Markers
        L13_2 = L13_2[A0_2]
        L13_2 = L13_2.data
        L13_2 = L13_2.minimumAccountAmount
        L14_2 = JobsCreator
        L14_2 = L14_2.Markers
        L14_2 = L14_2[A0_2]
        L14_2 = L14_2.data
        L14_2 = L14_2.minimumAccountName
        L15_2 = Framework
        L15_2 = L15_2.getIdentifier
        L16_2 = L1_2
        L15_2 = L15_2(L16_2)
        L16_2 = Framework
        L16_2 = L16_2.getAccountMoneyFromIdentifier
        L17_2 = L15_2
        L18_2 = L14_2
        L16_2 = L16_2(L17_2, L18_2)
        if L13_2 > L16_2 then
          L16_2 = notify
          L17_2 = L1_2
          L18_2 = getLocalizedText
          L19_2 = "you_need_minimum_account_money"
          L20_2 = L13_2
          L21_2 = Framework
          L21_2 = L21_2.getAccountLabel
          L22_2 = L14_2
          L21_2, L22_2 = L21_2(L22_2)
          L18_2, L19_2, L20_2, L21_2, L22_2 = L18_2(L19_2, L20_2, L21_2, L22_2)
          L16_2(L17_2, L18_2, L19_2, L20_2, L21_2, L22_2)
          L16_2 = L1_1
          L17_2 = L1_2
          L18_2 = A0_2
          L19_2 = false
          L16_2(L17_2, L18_2, L19_2)
          return
        end
      end
      L6_2 = L6_2 * 1000
      L13_2 = Framework
      L13_2 = L13_2.canPlayerCarryItem
      L14_2 = L1_2
      L15_2 = L5_2
      L16_2 = L4_2
      L13_2 = L13_2(L14_2, L15_2, L16_2)
      if L13_2 then
        L13_2 = L0_1
        L13_2[L1_2] = true
        if L8_2 then
          if L9_2 then
            L13_2 = Framework
            L13_2 = L13_2.hasPlayerEnoughOfItem
            L14_2 = L1_2
            L15_2 = L8_2
            L16_2 = L9_2
            L13_2 = L13_2(L14_2, L15_2, L16_2)
            if L13_2 then
              L13_2 = math
              L13_2 = L13_2.random
              L14_2 = 1
              L15_2 = 100
              L13_2 = L13_2(L14_2, L15_2)
              if L10_2 >= L13_2 then
                L14_2 = Framework
                L14_2 = L14_2.removeItemFromPlayer
                L15_2 = L1_2
                L16_2 = L8_2
                L17_2 = L9_2
                L14_2(L15_2, L16_2, L17_2)
              end
            else
              L13_2 = notify
              L14_2 = L1_2
              L15_2 = getLocalizedText
              L16_2 = "harvest:you_need_tool_count"
              L17_2 = L9_2
              L18_2 = Framework
              L18_2 = L18_2.getItemLabel
              L19_2 = L8_2
              L18_2, L19_2, L20_2, L21_2, L22_2 = L18_2(L19_2)
              L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2 = L15_2(L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2)
              L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2)
              L13_2 = L1_1
              L14_2 = L1_2
              L15_2 = A0_2
              L16_2 = false
              L13_2(L14_2, L15_2, L16_2)
              return
            end
          else
            L13_2 = Framework
            L13_2 = L13_2.hasPlayerEnoughOfItem
            L14_2 = L1_2
            L15_2 = L8_2
            L16_2 = 1
            L13_2 = L13_2(L14_2, L15_2, L16_2)
            if not L13_2 then
              L13_2 = notify
              L14_2 = L1_2
              L15_2 = getLocalizedText
              L16_2 = "harvest:you_need_tool"
              L17_2 = Framework
              L17_2 = L17_2.getItemLabel
              L18_2 = L8_2
              L17_2, L18_2, L19_2, L20_2, L21_2, L22_2 = L17_2(L18_2)
              L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2 = L15_2(L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2)
              L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2)
              L13_2 = L1_1
              L14_2 = L1_2
              L15_2 = A0_2
              L16_2 = false
              L13_2(L14_2, L15_2, L16_2)
              return
            end
          end
        end
        L13_2 = progressBar
        L14_2 = L1_2
        L15_2 = L6_2
        L16_2 = getLocalizedText
        L17_2 = "harvest:harvesting"
        L18_2 = Framework
        L18_2 = L18_2.getItemLabel
        L19_2 = L5_2
        L18_2, L19_2, L20_2, L21_2, L22_2 = L18_2(L19_2)
        L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2 = L16_2(L17_2, L18_2, L19_2, L20_2, L21_2, L22_2)
        L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2)
        L13_2 = playAnimation
        L14_2 = L1_2
        L15_2 = L7_2
        L13_2(L14_2, L15_2)
        L13_2 = Citizen
        L13_2 = L13_2.Wait
        L14_2 = L6_2
        L13_2(L14_2)
        L13_2 = isCloseToMarker
        L14_2 = L1_2
        L15_2 = A0_2
        L13_2 = L13_2(L14_2, L15_2)
        if L13_2 then
          L13_2 = Framework
          L13_2 = L13_2.canPlayerCarryItem
          L14_2 = L1_2
          L15_2 = L5_2
          L16_2 = L4_2
          L13_2 = L13_2(L14_2, L15_2, L16_2)
          if L13_2 then
            L13_2 = Framework
            L13_2 = L13_2.giveItemToPlayer
            L14_2 = L1_2
            L15_2 = L5_2
            L16_2 = L4_2
            L13_2(L14_2, L15_2, L16_2)
            L13_2 = log
            L14_2 = L1_2
            L15_2 = getLocalizedText
            L16_2 = "log_harvested"
            L15_2 = L15_2(L16_2)
            L16_2 = getLocalizedText
            L17_2 = "log_harvested_description"
            L18_2 = L4_2
            L19_2 = Framework
            L19_2 = L19_2.getItemLabel
            L20_2 = L5_2
            L19_2 = L19_2(L20_2)
            L20_2 = A0_2
            L16_2 = L16_2(L17_2, L18_2, L19_2, L20_2)
            L17_2 = "success"
            L18_2 = "harvest"
            L13_2(L14_2, L15_2, L16_2, L17_2, L18_2)
            L13_2 = TriggerEvent
            L14_2 = Utils
            L14_2 = L14_2.eventsPrefix
            L15_2 = ":harvest:harvestedItem"
            L14_2 = L14_2 .. L15_2
            L15_2 = L1_2
            L16_2 = A0_2
            L17_2 = L5_2
            L18_2 = L4_2
            L13_2(L14_2, L15_2, L16_2, L17_2, L18_2)
            if not L11_2 then
              L13_2 = L1_1
              L14_2 = L1_2
              L15_2 = A0_2
              L16_2 = config
              L16_2 = L16_2.allowAfkFarming
              L13_2(L14_2, L15_2, L16_2)
            else
              L13_2 = L1_1
              L14_2 = L1_2
              L15_2 = A0_2
              L16_2 = false
              L13_2(L14_2, L15_2, L16_2)
              L13_2 = TriggerClientEvent
              L14_2 = Utils
              L14_2 = L14_2.eventsPrefix
              L15_2 = ":harvest:hideMarker"
              L14_2 = L14_2 .. L15_2
              L15_2 = L1_2
              L16_2 = A0_2
              L17_2 = L12_2
              L13_2(L14_2, L15_2, L16_2, L17_2)
            end
          else
            L13_2 = L1_1
            L14_2 = L1_2
            L15_2 = A0_2
            L16_2 = false
            L13_2(L14_2, L15_2, L16_2)
            L13_2 = notify
            L14_2 = L1_2
            L15_2 = getLocalizedText
            L16_2 = "no_space"
            L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2 = L15_2(L16_2)
            L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2)
          end
        else
          L13_2 = L1_1
          L14_2 = L1_2
          L15_2 = A0_2
          L16_2 = false
          L13_2(L14_2, L15_2, L16_2)
          L13_2 = notify
          L14_2 = L1_2
          L15_2 = getLocalizedText
          L16_2 = "too_far"
          L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2 = L15_2(L16_2)
          L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2)
        end
      else
        L13_2 = L1_1
        L14_2 = L1_2
        L15_2 = A0_2
        L16_2 = false
        L13_2(L14_2, L15_2, L16_2)
        L13_2 = notify
        L14_2 = L1_2
        L15_2 = getLocalizedText
        L16_2 = "no_space"
        L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2 = L15_2(L16_2)
        L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2)
      end
    else
      L13_2 = L1_1
      L14_2 = L1_2
      L15_2 = A0_2
      L16_2 = false
      L13_2(L14_2, L15_2, L16_2)
      L13_2 = print
      L14_2 = "Harvesting marker ID "
      L15_2 = A0_2
      L16_2 = " not configured"
      L14_2 = L14_2 .. L15_2 .. L16_2
      L13_2(L14_2)
    end
  end
end
L3_1 = RegisterNetEvent
L4_1 = Utils
L4_1 = L4_1.eventsPrefix
L5_1 = ":harvestMarkerId"
L4_1 = L4_1 .. L5_1
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = Utils
L4_1 = L4_1.eventsPrefix
L5_1 = ":harvestMarkerId"
L4_1 = L4_1 .. L5_1
L5_1 = L2_1
L3_1(L4_1, L5_1)

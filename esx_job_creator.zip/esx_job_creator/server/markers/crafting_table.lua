local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1
function L0_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2
  L3_2 = canUseMarkerWithLog
  L4_2 = A0_2
  L5_2 = A2_2
  L3_2 = L3_2(L4_2, L5_2)
  if not L3_2 then
    return
  end
  L3_2 = JobsCreator
  L3_2 = L3_2.Markers
  L3_2 = L3_2[A2_2]
  L3_2 = L3_2.data
  if not L3_2 then
    L3_2 = {}
  end
  L4_2 = {}
  L5_2 = L3_2.craftablesItems
  if L5_2 then
    L5_2 = pairs
    L6_2 = L3_2.craftablesItems
    L5_2, L6_2, L7_2, L8_2 = L5_2(L6_2)
    for L9_2, L10_2 in L5_2, L6_2, L7_2, L8_2 do
      L11_2 = true
      L12_2 = L10_2.recipes
      L13_2 = {}
      L14_2 = 0
      L15_2 = pairs
      L16_2 = L12_2
      L15_2, L16_2, L17_2, L18_2 = L15_2(L16_2)
      for L19_2, L20_2 in L15_2, L16_2, L17_2, L18_2 do
        L21_2 = Framework
        L21_2 = L21_2.getPlayerItemCount
        L22_2 = A0_2
        L23_2 = L19_2
        L21_2 = L21_2(L22_2, L23_2)
        L22_2 = Framework
        L22_2 = L22_2.getItemLabel
        L23_2 = L19_2
        L22_2 = L22_2(L23_2)
        L23_2 = math
        L23_2 = L23_2.floor
        L24_2 = L20_2.quantity
        L24_2 = L21_2 / L24_2
        L23_2 = L23_2(L24_2)
        if L14_2 > L23_2 or 0 == L14_2 then
          L14_2 = L23_2
        end
        L24_2 = "green"
        L25_2 = L20_2.quantity
        if L21_2 < L25_2 then
          L24_2 = "orange"
          L11_2 = false
        end
        L25_2 = getLocalizedText
        L26_2 = "ingredient"
        L27_2 = L22_2
        L28_2 = L24_2
        L29_2 = L21_2
        L30_2 = L20_2.quantity
        L25_2 = L25_2(L26_2, L27_2, L28_2, L29_2, L30_2)
        L26_2 = table
        L26_2 = L26_2.insert
        L27_2 = L13_2
        L28_2 = {}
        L28_2.label = L25_2
        L29_2 = L20_2.quantity
        L28_2.quantity = L29_2
        L28_2.itemLabel = L22_2
        L28_2.itemQuantity = L21_2
        L26_2(L27_2, L28_2)
      end
      L15_2 = table
      L15_2 = L15_2.insert
      L16_2 = L13_2
      L17_2 = {}
      L18_2 = getLocalizedText
      L19_2 = "craft_amount"
      L18_2 = L18_2(L19_2)
      L17_2.label = L18_2
      if L14_2 > 0 then
        L18_2 = 1
        if L18_2 then
          goto lbl_96
        end
      end
      L18_2 = 0
      ::lbl_96::
      L17_2.value = L18_2
      L17_2.min = 1
      L17_2.max = L14_2
      L17_2.type = "slider"
      L15_2(L16_2, L17_2)
      L15_2 = Framework
      L15_2 = L15_2.getItemLabel
      L16_2 = L9_2
      L15_2 = L15_2(L16_2)
      if not L15_2 then
        L15_2 = ESX
        L15_2 = L15_2.GetWeaponLabel
        L16_2 = L9_2
        L15_2 = L15_2(L16_2)
        if not L15_2 then
          L15_2 = L9_2
        end
      end
      L16_2 = "green"
      if not L11_2 then
        L16_2 = "orange"
      end
      L17_2 = table
      L17_2 = L17_2.insert
      L18_2 = L4_2
      L19_2 = {}
      L20_2 = getLocalizedText
      L21_2 = "craft_item_label"
      L22_2 = L16_2
      L23_2 = L15_2
      L20_2 = L20_2(L21_2, L22_2, L23_2)
      L19_2.label = L20_2
      L19_2.itemName = L9_2
      L19_2.recipeElements = L13_2
      L17_2(L18_2, L19_2)
    end
  end
  L5_2 = A1_2
  L6_2 = L4_2
  L5_2(L6_2)
end
L1_1 = RegisterServerCallback
L2_1 = Utils
L2_1 = L2_1.eventsPrefix
L3_1 = ":getCraftingTableData"
L2_1 = L2_1 .. L3_1
L3_1 = L0_1
L1_1(L2_1, L3_1)
function L1_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  L2_2 = true
  L3_2 = pairs
  L4_2 = A1_2
  L3_2, L4_2, L5_2, L6_2 = L3_2(L4_2)
  for L7_2, L8_2 in L3_2, L4_2, L5_2, L6_2 do
    L9_2 = Framework
    L9_2 = L9_2.hasPlayerEnoughOfItem
    L10_2 = A0_2
    L11_2 = L7_2
    L12_2 = L8_2.quantity
    L9_2 = L9_2(L10_2, L11_2, L12_2)
    if not L9_2 then
      L2_2 = false
    end
  end
  return L2_2
end
L2_1 = {}
L3_1 = {}
L4_1 = RegisterNetEvent
L5_1 = Utils
L5_1 = L5_1.eventsPrefix
L6_1 = ":craftItem"
L5_1 = L5_1 .. L6_1
L4_1(L5_1)
L4_1 = AddEventHandler
L5_1 = Utils
L5_1 = L5_1.eventsPrefix
L6_1 = ":craftItem"
L5_1 = L5_1 .. L6_1
function L6_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2
  if not A2_2 then
    A2_2 = 1
  end
  L3_2 = source
  L4_2 = L2_1
  L4_2 = L4_2[L3_2]
  if not L4_2 then
    L4_2 = JobsCreator
    L4_2 = L4_2.Markers
    L4_2 = L4_2[A0_2]
    L4_2 = L4_2.data
    if not L4_2 then
      L4_2 = {}
    end
    L5_2 = L4_2.craftablesItems
    if L5_2 then
      L5_2 = L4_2.craftablesItems
      L5_2 = L5_2[A1_2]
      L5_2 = L5_2.recipes
      L6_2 = L4_2.craftablesItems
      L6_2 = L6_2[A1_2]
      L6_2 = L6_2.animations
      if not L6_2 then
        L6_2 = {}
      end
      L7_2 = L4_2.craftablesItems
      L7_2 = L7_2[A1_2]
      L7_2 = L7_2.quantity
      if not L7_2 then
        L7_2 = 1
      end
      L8_2 = L4_2.craftablesItems
      L8_2 = L8_2[A1_2]
      L8_2 = L8_2.craftingTime
      if not L8_2 then
        L8_2 = 8
      end
      L9_2 = #L6_2
      if 0 == L9_2 then
        L9_2 = table
        L9_2 = L9_2.insert
        L10_2 = L6_2
        L11_2 = {}
        L11_2.type = "scenario"
        L11_2.scenarioName = "PROP_HUMAN_BUM_BIN"
        L11_2.scenarioDuration = L8_2
        L9_2(L10_2, L11_2)
      end
      if L5_2 then
        L9_2 = L2_1
        L9_2[L3_2] = true
        L9_2 = 1
        L10_2 = A2_2
        L11_2 = 1
        for L12_2 = L9_2, L10_2, L11_2 do
          L13_2 = L3_1
          L13_2 = L13_2[L3_2]
          if L13_2 then
            L13_2 = L2_1
            L13_2[L3_2] = false
            L13_2 = L3_1
            L13_2[L3_2] = false
            return
          end
          L13_2 = L1_1
          L14_2 = L3_2
          L15_2 = L5_2
          L13_2 = L13_2(L14_2, L15_2)
          if L13_2 then
            L13_2 = "item"
            L14_2 = Framework
            L14_2 = L14_2.getItemLabel
            L15_2 = A1_2
            L14_2 = L14_2(L15_2)
            if not L14_2 then
              L13_2 = "weapon"
              L15_2 = ESX
              L15_2 = L15_2.GetWeaponLabel
              L16_2 = A1_2
              L15_2 = L15_2(L16_2)
              L14_2 = L15_2
            end
            if not L14_2 then
              L14_2 = A1_2
            end
            if "item" == L13_2 then
              L15_2 = Framework
              L15_2 = L15_2.canPlayerCarryItem
              L16_2 = L3_2
              L17_2 = A1_2
              L18_2 = 1
              L15_2 = L15_2(L16_2, L17_2, L18_2)
              if not L15_2 then
                L15_2 = notify
                L16_2 = L3_2
                L17_2 = getLocalizedText
                L18_2 = "no_space"
                L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2 = L17_2(L18_2)
                L15_2(L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2)
                L15_2 = L2_1
                L15_2[L3_2] = false
                return
              end
            elseif "weapon" == L13_2 then
              L15_2 = Framework
              L15_2 = L15_2.getFramework
              L15_2 = L15_2()
              if "ESX" == L15_2 then
                L15_2 = ESX
                L15_2 = L15_2.GetPlayerFromId
                L16_2 = L3_2
                L15_2 = L15_2(L16_2)
                L16_2 = L15_2.hasWeapon
                L17_2 = A1_2
                L16_2 = L16_2(L17_2)
                if L16_2 then
                  L16_2 = notify
                  L17_2 = L3_2
                  L18_2 = getLocalizedText
                  L19_2 = "already_have"
                  L20_2 = L14_2
                  L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2 = L18_2(L19_2, L20_2)
                  L16_2(L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2)
                  L16_2 = L2_1
                  L16_2[L3_2] = false
                  return
                end
              end
            end
            L15_2 = L8_2 * 1000
            L16_2 = TriggerClientEvent
            L17_2 = Utils
            L17_2 = L17_2.eventsPrefix
            L18_2 = ":crafting_table:startCrafting"
            L17_2 = L17_2 .. L18_2
            L18_2 = L3_2
            L19_2 = L15_2
            L20_2 = getLocalizedText
            L21_2 = "crafting"
            L22_2 = L14_2
            L20_2, L21_2, L22_2, L23_2, L24_2, L25_2 = L20_2(L21_2, L22_2)
            L16_2(L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2)
            L16_2 = playAnimation
            L17_2 = L3_2
            L18_2 = L6_2
            L16_2(L17_2, L18_2)
            L16_2 = Citizen
            L16_2 = L16_2.Wait
            L17_2 = L15_2
            L16_2(L17_2)
            L16_2 = L1_1
            L17_2 = L3_2
            L18_2 = L5_2
            L16_2 = L16_2(L17_2, L18_2)
            if L16_2 then
              L16_2 = pairs
              L17_2 = L5_2
              L16_2, L17_2, L18_2, L19_2 = L16_2(L17_2)
              for L20_2, L21_2 in L16_2, L17_2, L18_2, L19_2 do
                L22_2 = L21_2.loseOnUse
                if L22_2 then
                  L22_2 = Framework
                  L22_2 = L22_2.removeItemFromPlayer
                  L23_2 = L3_2
                  L24_2 = L20_2
                  L25_2 = L21_2.quantity
                  L22_2(L23_2, L24_2, L25_2)
                end
              end
              if "item" == L13_2 then
                L16_2 = Framework
                L16_2 = L16_2.giveItemToPlayer
                L17_2 = L3_2
                L18_2 = A1_2
                L19_2 = L7_2
                L16_2(L17_2, L18_2, L19_2)
              else
                L16_2 = Framework
                L16_2 = L16_2.giveWeaponToPlayer
                L17_2 = L3_2
                L18_2 = A1_2
                L19_2 = 0
                L16_2(L17_2, L18_2, L19_2)
              end
              L16_2 = notify
              L17_2 = L3_2
              L18_2 = getLocalizedText
              L19_2 = "you_crafted"
              L20_2 = L7_2
              L21_2 = L14_2
              L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2 = L18_2(L19_2, L20_2, L21_2)
              L16_2(L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2)
              L16_2 = log
              L17_2 = L3_2
              L18_2 = getLocalizedText
              L19_2 = "log_crafted_item"
              L18_2 = L18_2(L19_2)
              L19_2 = getLocalizedText
              L20_2 = "log_crafted_item_description"
              L21_2 = L7_2
              L22_2 = L14_2
              L23_2 = A1_2
              L24_2 = A0_2
              L19_2 = L19_2(L20_2, L21_2, L22_2, L23_2, L24_2)
              L20_2 = "success"
              L21_2 = "crafting_table"
              L16_2(L17_2, L18_2, L19_2, L20_2, L21_2)
              L16_2 = TriggerEvent
              L17_2 = Utils
              L17_2 = L17_2.eventsPrefix
              L18_2 = ":crafting_table:craftedItem"
              L17_2 = L17_2 .. L18_2
              L18_2 = L3_2
              L19_2 = A0_2
              L20_2 = A1_2
              L21_2 = L7_2
              L16_2(L17_2, L18_2, L19_2, L20_2, L21_2)
              L16_2 = Citizen
              L16_2 = L16_2.Wait
              L17_2 = 2000
              L16_2(L17_2)
            else
              L16_2 = notify
              L17_2 = L3_2
              L18_2 = getLocalizedText
              L19_2 = "dont_have_ingredients"
              L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2 = L18_2(L19_2)
              L16_2(L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2)
            end
          else
            L13_2 = notify
            L14_2 = L3_2
            L15_2 = getLocalizedText
            L16_2 = "dont_have_ingredients"
            L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2 = L15_2(L16_2)
            L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2)
          end
        end
        L9_2 = L2_1
        L9_2[L3_2] = false
      end
    end
  end
end
L4_1(L5_1, L6_1)
L4_1 = RegisterNetEvent
L5_1 = Utils
L5_1 = L5_1.eventsPrefix
L6_1 = ":stopCrafting"
L5_1 = L5_1 .. L6_1
L4_1(L5_1)
L4_1 = AddEventHandler
L5_1 = Utils
L5_1 = L5_1.eventsPrefix
L6_1 = ":stopCrafting"
L5_1 = L5_1 .. L6_1
function L6_1()
  local L0_2, L1_2
  L0_2 = source
  L1_2 = L3_1
  L1_2[L0_2] = true
end
L4_1(L5_1, L6_1)

local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1
L0_1 = {}
function L1_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2
  L3_2 = canUseMarkerWithLog
  L4_2 = A0_2
  L5_2 = A2_2
  L3_2 = L3_2(L4_2, L5_2)
  if not L3_2 then
    return
  end
  L3_2 = {}
  L4_2 = pairs
  L5_2 = JobsCreator
  L5_2 = L5_2.Markers
  L5_2 = L5_2[A2_2]
  L5_2 = L5_2.data
  L5_2 = L5_2.items
  L4_2, L5_2, L6_2, L7_2 = L4_2(L5_2)
  for L8_2, L9_2 in L4_2, L5_2, L6_2, L7_2 do
    L10_2 = "green"
    L11_2 = L9_2.blackMoney
    if L11_2 then
      L10_2 = "orange"
    end
    L11_2 = table
    L11_2 = L11_2.insert
    L12_2 = L3_2
    L13_2 = {}
    L14_2 = getLocalizedText
    L15_2 = "market_item"
    L16_2 = Framework
    L16_2 = L16_2.getItemLabel
    L17_2 = L8_2
    L16_2 = L16_2(L17_2)
    L17_2 = L10_2
    L18_2 = L9_2.minPrice
    L19_2 = L9_2.maxPrice
    L14_2 = L14_2(L15_2, L16_2, L17_2, L18_2, L19_2)
    L13_2.label = L14_2
    L13_2.value = L8_2
    L11_2(L12_2, L13_2)
  end
  L4_2 = A1_2
  L5_2 = L3_2
  L4_2(L5_2)
end
L2_1 = RegisterServerCallback
L3_1 = Utils
L3_1 = L3_1.eventsPrefix
L4_1 = ":getMarketItems"
L3_1 = L3_1 .. L4_1
L4_1 = L1_1
L2_1(L3_1, L4_1)
function L2_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2
  L3_2 = source
  L4_2 = canUseMarkerWithLog
  L5_2 = L3_2
  L6_2 = A0_2
  L4_2 = L4_2(L5_2, L6_2)
  if not L4_2 then
    return
  end
  L4_2 = JobsCreator
  L4_2 = L4_2.Markers
  L4_2 = L4_2[A0_2]
  L4_2 = L4_2.data
  L4_2 = L4_2.items
  L4_2 = L4_2[A1_2]
  L5_2 = L0_1
  L5_2 = L5_2[L3_2]
  if not L5_2 then
    if L4_2 then
      L5_2 = Framework
      L5_2 = L5_2.getItemLabel
      L6_2 = A1_2
      L5_2 = L5_2(L6_2)
      L6_2 = Framework
      L6_2 = L6_2.hasPlayerEnoughOfItem
      L7_2 = L3_2
      L8_2 = A1_2
      L9_2 = A2_2
      L6_2 = L6_2(L7_2, L8_2, L9_2)
      if L6_2 then
        L6_2 = L4_2.sellTime
        if not L6_2 then
          L6_2 = 0
        end
        L6_2 = L6_2 * 1000
        L6_2 = L6_2 * A2_2
        if L6_2 > 0 then
          L7_2 = progressBar
          L8_2 = L3_2
          L9_2 = L6_2
          L10_2 = getLocalizedText
          L11_2 = "market:selling"
          L12_2 = A2_2
          L13_2 = L5_2
          L10_2, L11_2, L12_2, L13_2 = L10_2(L11_2, L12_2, L13_2)
          L7_2(L8_2, L9_2, L10_2, L11_2, L12_2, L13_2)
          L7_2 = timedFreezePlayer
          L8_2 = L3_2
          L9_2 = L6_2
          L7_2(L8_2, L9_2)
        end
        L7_2 = TriggerClientEvent
        L8_2 = Utils
        L8_2 = L8_2.eventsPrefix
        L9_2 = ":market:toggleSelling"
        L8_2 = L8_2 .. L9_2
        L9_2 = L3_2
        L10_2 = true
        L7_2(L8_2, L9_2, L10_2)
        L7_2 = L0_1
        L8_2 = Timeout
        L9_2 = L6_2
        function L10_2()
          local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3
          L0_3 = Framework
          L0_3 = L0_3.hasPlayerEnoughOfItem
          L1_3 = L3_2
          L2_3 = A1_2
          L3_3 = A2_2
          L0_3 = L0_3(L1_3, L2_3, L3_3)
          if L0_3 then
            L0_3 = Framework
            L0_3 = L0_3.removeItemFromPlayer
            L1_3 = L3_2
            L2_3 = A1_2
            L3_3 = A2_2
            L0_3(L1_3, L2_3, L3_3)
            L0_3 = math
            L0_3 = L0_3.random
            L1_3 = L4_2.minPrice
            L2_3 = L4_2.maxPrice
            L0_3 = L0_3(L1_3, L2_3)
            L1_3 = A2_2
            L0_3 = L0_3 * L1_3
            L1_3 = JobsCreator
            L1_3 = L1_3.Markers
            L2_3 = A0_2
            L1_3 = L1_3[L2_3]
            L1_3 = L1_3.jobName
            if "public_marker" ~= L1_3 then
              L1_3 = JobsCreator
              L1_3 = L1_3.Markers
              L2_3 = A0_2
              L1_3 = L1_3[L2_3]
              L1_3 = L1_3.data
              L1_3 = L1_3.percentageForSociety
              if L1_3 then
                L1_3 = math
                L1_3 = L1_3.floor
                L2_3 = JobsCreator
                L2_3 = L2_3.Markers
                L3_3 = A0_2
                L2_3 = L2_3[L3_3]
                L2_3 = L2_3.data
                L2_3 = L2_3.percentageForSociety
                L2_3 = L0_3 * L2_3
                L2_3 = L2_3 / 100
                L1_3 = L1_3(L2_3)
                L0_3 = L0_3 - L1_3
                L2_3 = exports
                L3_3 = GetCurrentResourceName
                L3_3 = L3_3()
                L2_3 = L2_3[L3_3]
                L3_3 = L2_3
                L2_3 = L2_3.addSocietyMoney
                L4_3 = JobsCreator
                L4_3 = L4_3.Markers
                L5_3 = A0_2
                L4_3 = L4_3[L5_3]
                L4_3 = L4_3.jobName
                L5_3 = L1_3
                L2_3 = L2_3(L3_3, L4_3, L5_3)
                if L2_3 then
                  L3_3 = notify
                  L4_3 = L3_2
                  L5_3 = getLocalizedText
                  L6_3 = "society_received_money_from_your_sale"
                  L7_3 = Framework
                  L7_3 = L7_3.groupDigits
                  L8_3 = L1_3
                  L7_3, L8_3, L9_3, L10_3 = L7_3(L8_3)
                  L5_3, L6_3, L7_3, L8_3, L9_3, L10_3 = L5_3(L6_3, L7_3, L8_3, L9_3, L10_3)
                  L3_3(L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3)
                else
                  L3_3 = TriggerClientEvent
                  L4_3 = Utils
                  L4_3 = L4_3.eventsPrefix
                  L5_3 = ":market:toggleSelling"
                  L4_3 = L4_3 .. L5_3
                  L5_3 = L3_2
                  L6_3 = false
                  L3_3(L4_3, L5_3, L6_3)
                  L3_3 = print
                  L4_3 = "^1Couldn't give money to society ^3"
                  L5_3 = JobsCreator
                  L5_3 = L5_3.Markers
                  L6_3 = A0_2
                  L5_3 = L5_3[L6_3]
                  L5_3 = L5_3.jobName
                  L6_3 = "^1 (try deleting and recreating the job)^7"
                  L4_3 = L4_3 .. L5_3 .. L6_3
                  L3_3(L4_3)
                  return
                end
              end
            end
            L1_3 = L4_2.blackMoney
            if L1_3 then
              L1_3 = Framework
              L1_3 = L1_3.giveBlackMoneyValue
              L2_3 = L3_2
              L3_3 = L0_3
              L1_3(L2_3, L3_3)
            else
              L1_3 = Framework
              L1_3 = L1_3.getFramework
              L1_3 = L1_3()
              if "ESX" == L1_3 then
                L1_3 = Framework
                L1_3 = L1_3.giveAccountMoneyToPlayer
                L2_3 = L3_2
                L3_3 = "money"
                L4_3 = L0_3
                L1_3(L2_3, L3_3, L4_3)
              else
                L1_3 = Framework
                L1_3 = L1_3.getFramework
                L1_3 = L1_3()
                if "QB-core" == L1_3 then
                  L1_3 = Framework
                  L1_3 = L1_3.giveAccountMoneyToPlayer
                  L2_3 = L3_2
                  L3_3 = "cash"
                  L4_3 = L0_3
                  L1_3(L2_3, L3_3, L4_3)
                end
              end
            end
            L1_3 = "~g~"
            L2_3 = L4_2.blackMoney
            if L2_3 then
              L1_3 = "~r~"
            end
            if L0_3 > 0 then
              L2_3 = notify
              L3_3 = L3_2
              L4_3 = getLocalizedText
              L5_3 = "you_sold"
              L6_3 = A2_2
              L7_3 = L5_2
              L8_3 = L1_3
              L9_3 = Framework
              L9_3 = L9_3.groupDigits
              L10_3 = L0_3
              L9_3, L10_3 = L9_3(L10_3)
              L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3 = L4_3(L5_3, L6_3, L7_3, L8_3, L9_3, L10_3)
              L2_3(L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3)
            end
            L2_3 = log
            L3_3 = L3_2
            L4_3 = getLocalizedText
            L5_3 = "log_sold_item"
            L4_3 = L4_3(L5_3)
            L5_3 = getLocalizedText
            L6_3 = "log_sold_item_description"
            L7_3 = A2_2
            L8_3 = L5_2
            L9_3 = Framework
            L9_3 = L9_3.groupDigits
            L10_3 = L0_3
            L9_3, L10_3 = L9_3(L10_3)
            L5_3 = L5_3(L6_3, L7_3, L8_3, L9_3, L10_3)
            L6_3 = "success"
            L7_3 = "market"
            L2_3(L3_3, L4_3, L5_3, L6_3, L7_3)
            L2_3 = TriggerEvent
            L3_3 = Utils
            L3_3 = L3_3.eventsPrefix
            L4_3 = ":market:soldItem"
            L3_3 = L3_3 .. L4_3
            L4_3 = L3_2
            L5_3 = A0_2
            L6_3 = A1_2
            L7_3 = A2_2
            L8_3 = L0_3
            L2_3(L3_3, L4_3, L5_3, L6_3, L7_3, L8_3)
          else
            L0_3 = notify
            L1_3 = L3_2
            L2_3 = getLocalizedText
            L3_3 = "not_enough_item"
            L4_3 = L5_2
            L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3 = L2_3(L3_3, L4_3)
            L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3)
          end
          L0_3 = TriggerClientEvent
          L1_3 = Utils
          L1_3 = L1_3.eventsPrefix
          L2_3 = ":market:toggleSelling"
          L1_3 = L1_3 .. L2_3
          L2_3 = L3_2
          L3_3 = false
          L0_3(L1_3, L2_3, L3_3)
          L1_3 = L3_2
          L0_3 = L0_1
          L0_3[L1_3] = nil
        end
        L8_2 = L8_2(L9_2, L10_2)
        L7_2[L3_2] = L8_2
      else
        L6_2 = notify
        L7_2 = L3_2
        L8_2 = getLocalizedText
        L9_2 = "not_enough_item"
        L10_2 = L5_2
        L8_2, L9_2, L10_2, L11_2, L12_2, L13_2 = L8_2(L9_2, L10_2)
        L6_2(L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2)
      end
    end
  else
    L5_2 = notify
    L6_2 = L3_2
    L7_2 = getLocalizedText
    L8_2 = "market:you_are_already_selling"
    L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2 = L7_2(L8_2)
    L5_2(L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2)
  end
end
L3_1 = RegisterNetEvent
L4_1 = Utils
L4_1 = L4_1.eventsPrefix
L5_1 = ":sellMarketItem"
L4_1 = L4_1 .. L5_1
L5_1 = L2_1
L3_1(L4_1, L5_1)
function L3_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = source
  L1_2 = L0_1
  L1_2 = L1_2[L0_2]
  if L1_2 then
    L1_2 = print
    L2_2 = "Timeout ID: "
    L3_2 = tostring
    L4_2 = L0_1
    L4_2 = L4_2[L0_2]
    L3_2 = L3_2(L4_2)
    L2_2 = L2_2 .. L3_2
    L1_2(L2_2)
    L1_2 = ClearTimeout
    L2_2 = L0_1
    L2_2 = L2_2[L0_2]
    L1_2(L2_2)
    L1_2 = L0_1
    L1_2[L0_2] = nil
  end
  L1_2 = TriggerClientEvent
  L2_2 = Utils
  L2_2 = L2_2.eventsPrefix
  L3_2 = ":market:toggleSelling"
  L2_2 = L2_2 .. L3_2
  L3_2 = L0_2
  L4_2 = false
  L1_2(L2_2, L3_2, L4_2)
end
L4_1 = RegisterNetEvent
L5_1 = Utils
L5_1 = L5_1.eventsPrefix
L6_1 = ":market:stopSelling"
L5_1 = L5_1 .. L6_1
L6_1 = L3_1
L4_1(L5_1, L6_1)

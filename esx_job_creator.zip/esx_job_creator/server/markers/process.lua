local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1
L0_1 = {}
function L1_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2
  L3_2 = L0_1
  L3_2[A0_2] = false
  L3_2 = TriggerClientEvent
  L4_2 = Utils
  L4_2 = L4_2.eventsPrefix
  L5_2 = ":process:finishedProcessing"
  L4_2 = L4_2 .. L5_2
  L5_2 = A0_2
  L6_2 = A1_2
  L7_2 = A2_2
  L3_2(L4_2, L5_2, L6_2, L7_2)
end
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2
  L1_2 = source
  L2_2 = canUseMarkerWithLog
  L3_2 = L1_2
  L4_2 = A0_2
  L2_2 = L2_2(L3_2, L4_2)
  if not L2_2 then
    return
  end
  L2_2 = L0_1
  L2_2 = L2_2[L1_2]
  if L2_2 then
    return
  end
  L2_2 = L0_1
  L2_2[L1_2] = true
  L2_2 = JobsCreator
  L2_2 = L2_2.Markers
  L2_2 = L2_2[A0_2]
  L2_2 = L2_2.data
  if L2_2 then
    L2_2 = JobsCreator
    L2_2 = L2_2.Markers
    L2_2 = L2_2[A0_2]
    L2_2 = L2_2.data
    L2_2 = L2_2.requiresMinimumAccountMoney
    if L2_2 then
      L2_2 = JobsCreator
      L2_2 = L2_2.Markers
      L2_2 = L2_2[A0_2]
      L2_2 = L2_2.data
      L2_2 = L2_2.minimumAccountAmount
      L3_2 = JobsCreator
      L3_2 = L3_2.Markers
      L3_2 = L3_2[A0_2]
      L3_2 = L3_2.data
      L3_2 = L3_2.minimumAccountName
      L4_2 = Framework
      L4_2 = L4_2.getIdentifier
      L5_2 = L1_2
      L4_2 = L4_2(L5_2)
      L5_2 = Framework
      L5_2 = L5_2.getAccountMoneyFromIdentifier
      L6_2 = L4_2
      L7_2 = L3_2
      L5_2 = L5_2(L6_2, L7_2)
      if L2_2 > L5_2 then
        L5_2 = notify
        L6_2 = L1_2
        L7_2 = getLocalizedText
        L8_2 = "you_need_minimum_account_money"
        L9_2 = L2_2
        L10_2 = Framework
        L10_2 = L10_2.getAccountLabel
        L11_2 = L3_2
        L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2 = L10_2(L11_2)
        L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2 = L7_2(L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2)
        L5_2(L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2)
        L5_2 = L1_1
        L6_2 = L1_2
        L7_2 = A0_2
        L8_2 = false
        L5_2(L6_2, L7_2, L8_2)
        return
      end
    end
    L2_2 = JobsCreator
    L2_2 = L2_2.Markers
    L2_2 = L2_2[A0_2]
    L2_2 = L2_2.data
    L2_2 = L2_2.itemToRemoveName
    L3_2 = JobsCreator
    L3_2 = L3_2.Markers
    L3_2 = L3_2[A0_2]
    L3_2 = L3_2.data
    L3_2 = L3_2.itemToRemoveQuantity
    L4_2 = JobsCreator
    L4_2 = L4_2.Markers
    L4_2 = L4_2[A0_2]
    L4_2 = L4_2.data
    L4_2 = L4_2.itemToAddName
    L5_2 = JobsCreator
    L5_2 = L5_2.Markers
    L5_2 = L5_2[A0_2]
    L5_2 = L5_2.data
    L5_2 = L5_2.itemToAddQuantity
    L6_2 = JobsCreator
    L6_2 = L6_2.Markers
    L6_2 = L6_2[A0_2]
    L6_2 = L6_2.data
    L6_2 = L6_2.timeToProcess
    L7_2 = JobsCreator
    L7_2 = L7_2.Markers
    L7_2 = L7_2[A0_2]
    L7_2 = L7_2.data
    L7_2 = L7_2.animations
    if not L7_2 then
      L7_2 = {}
    end
    L8_2 = #L7_2
    if 0 == L8_2 then
      L8_2 = table
      L8_2 = L8_2.insert
      L9_2 = L7_2
      L10_2 = {}
      L10_2.type = "scenario"
      L10_2.scenarioName = "PROP_HUMAN_BUM_BIN"
      L10_2.scenarioDuration = L6_2
      L8_2(L9_2, L10_2)
    end
    L8_2 = Framework
    L8_2 = L8_2.hasPlayerEnoughOfItem
    L9_2 = L1_2
    L10_2 = L2_2
    L11_2 = L3_2
    L8_2 = L8_2(L9_2, L10_2, L11_2)
    if L8_2 then
      L8_2 = Framework
      L8_2 = L8_2.canPlayerCarryItem
      L9_2 = L1_2
      L10_2 = L4_2
      L11_2 = L5_2
      L8_2 = L8_2(L9_2, L10_2, L11_2)
      if L8_2 then
        L8_2 = Framework
        L8_2 = L8_2.removeItemFromPlayer
        L9_2 = L1_2
        L10_2 = L2_2
        L11_2 = L3_2
        L8_2(L9_2, L10_2, L11_2)
        L8_2 = Framework
        L8_2 = L8_2.getItemLabel
        L9_2 = L2_2
        L8_2 = L8_2(L9_2)
        L9_2 = progressBar
        L10_2 = L1_2
        L11_2 = L6_2 * 1000
        L12_2 = getLocalizedText
        L13_2 = "process:processing"
        L14_2 = L8_2
        L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2 = L12_2(L13_2, L14_2)
        L9_2(L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2)
        L9_2 = playAnimation
        L10_2 = L1_2
        L11_2 = L7_2
        L9_2(L10_2, L11_2)
        L9_2 = Citizen
        L9_2 = L9_2.Wait
        L10_2 = L6_2 * 1000
        L9_2(L10_2)
        L9_2 = isCloseToMarker
        L10_2 = L1_2
        L11_2 = A0_2
        L9_2 = L9_2(L10_2, L11_2)
        if L9_2 then
          L9_2 = Framework
          L9_2 = L9_2.giveItemToPlayer
          L10_2 = L1_2
          L11_2 = L4_2
          L12_2 = L5_2
          L9_2(L10_2, L11_2, L12_2)
          L9_2 = L1_1
          L10_2 = L1_2
          L11_2 = A0_2
          L12_2 = config
          L12_2 = L12_2.allowAfkFarming
          L9_2(L10_2, L11_2, L12_2)
          L9_2 = log
          L10_2 = L1_2
          L11_2 = getLocalizedText
          L12_2 = "logs:process:title"
          L11_2 = L11_2(L12_2)
          L12_2 = getLocalizedText
          L13_2 = "logs:process:description"
          L14_2 = L3_2
          L15_2 = L8_2
          L16_2 = L5_2
          L17_2 = Framework
          L17_2 = L17_2.getItemLabel
          L18_2 = L4_2
          L17_2, L18_2 = L17_2(L18_2)
          L12_2 = L12_2(L13_2, L14_2, L15_2, L16_2, L17_2, L18_2)
          L13_2 = "success"
          L14_2 = "process"
          L9_2(L10_2, L11_2, L12_2, L13_2, L14_2)
          L9_2 = TriggerEvent
          L10_2 = Utils
          L10_2 = L10_2.eventsPrefix
          L11_2 = ":process:processedItem"
          L10_2 = L10_2 .. L11_2
          L11_2 = L1_2
          L12_2 = A0_2
          L13_2 = L4_2
          L14_2 = L5_2
          L15_2 = L2_2
          L16_2 = L3_2
          L9_2(L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2)
        else
          L9_2 = L1_1
          L10_2 = L1_2
          L11_2 = A0_2
          L12_2 = false
          L9_2(L10_2, L11_2, L12_2)
          L9_2 = notify
          L10_2 = L1_2
          L11_2 = getLocalizedText
          L12_2 = "too_far"
          L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2 = L11_2(L12_2)
          L9_2(L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2)
        end
      else
        L8_2 = L1_1
        L9_2 = L1_2
        L10_2 = A0_2
        L11_2 = false
        L8_2(L9_2, L10_2, L11_2)
        L8_2 = notify
        L9_2 = L1_2
        L10_2 = getLocalizedText
        L11_2 = "process:no_space"
        L12_2 = L5_2
        L13_2 = Framework
        L13_2 = L13_2.getItemLabel
        L14_2 = L4_2
        L13_2, L14_2, L15_2, L16_2, L17_2, L18_2 = L13_2(L14_2)
        L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2 = L10_2(L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2)
        L8_2(L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2)
      end
    else
      L8_2 = notify
      L9_2 = L1_2
      L10_2 = getLocalizedText
      L11_2 = "process:you_need"
      L12_2 = L3_2
      L13_2 = Framework
      L13_2 = L13_2.getItemLabel
      L14_2 = L2_2
      L13_2, L14_2, L15_2, L16_2, L17_2, L18_2 = L13_2(L14_2)
      L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2 = L10_2(L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2)
      L8_2(L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2)
      L8_2 = L1_1
      L9_2 = L1_2
      L10_2 = A0_2
      L11_2 = false
      L8_2(L9_2, L10_2, L11_2)
    end
  end
end
L3_1 = RegisterNetEvent
L4_1 = Utils
L4_1 = L4_1.eventsPrefix
L5_1 = ":process:startProcessing"
L4_1 = L4_1 .. L5_1
L5_1 = L2_1
L3_1(L4_1, L5_1)

local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1
L0_1 = {}
L1_1 = RegisterNetEvent
L2_1 = Utils
L2_1 = L2_1.eventsPrefix
L3_1 = ":toggleDuty"
L2_1 = L2_1 .. L3_1
function L3_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2
  L3_2 = L0_1
  L4_2 = not A2_2
  L3_2[A0_2] = L4_2
end
L1_1(L2_1, L3_1)
function L1_1(A0_2)
  local L1_2, L2_2
  L1_2 = Framework
  L1_2 = L1_2.getFramework
  L1_2 = L1_2()
  if "ESX" == L1_2 then
    L1_2 = L0_1
    L1_2 = L1_2[A0_2]
    L1_2 = not L1_2
    return L1_2
  else
    L1_2 = Framework
    L1_2 = L1_2.getFramework
    L1_2 = L1_2()
    if "QB-core" == L1_2 then
      L1_2 = QBCore
      L1_2 = L1_2.Functions
      L1_2 = L1_2.GetPlayer
      L2_2 = A0_2
      L1_2 = L1_2(L2_2)
      L2_2 = L1_2.PlayerData
      L2_2 = L2_2.job
      L2_2 = L2_2.onduty
      return L2_2
    end
  end
end
L2_1 = exports
L3_1 = "isPlayerOnDuty"
L4_1 = L1_1
L2_1(L3_1, L4_1)
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L1_2 = source
  L2_2 = Framework
  L2_2 = L2_2.getPlayerJobName
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  L3_2 = TriggerEvent
  L4_2 = Utils
  L4_2 = L4_2.eventsPrefix
  L5_2 = ":toggleDuty"
  L4_2 = L4_2 .. L5_2
  L5_2 = L1_2
  L6_2 = L2_2
  L7_2 = A0_2
  L3_2(L4_2, L5_2, L6_2, L7_2)
end
L3_1 = RegisterNetEvent
L4_1 = Utils
L4_1 = L4_1.eventsPrefix
L5_1 = ":changeDutyStatus"
L4_1 = L4_1 .. L5_1
L5_1 = L2_1
L3_1(L4_1, L5_1)
L3_1 = RegisterNetEvent
L4_1 = "esx:setJob"
function L5_1(A0_2, A1_2, A2_2)
  local L3_2
  L3_2 = L0_1
  L3_2[A0_2] = false
end
L3_1(L4_1, L5_1)
L3_1 = RegisterNetEvent
L4_1 = "QBCore:Server:PlayerLoaded"
function L5_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = Citizen
  L1_2 = L1_2.Wait
  L2_2 = 1000
  L1_2(L2_2)
  L1_2 = TriggerClientEvent
  L2_2 = Utils
  L2_2 = L2_2.eventsPrefix
  L3_2 = ":toggleCurrentDutyStatus"
  L2_2 = L2_2 .. L3_2
  L3_2 = A0_2.PlayerData
  L3_2 = L3_2.source
  L4_2 = DEFAULT_DUTY_STATUS
  L1_2(L2_2, L3_2, L4_2)
end
L3_1(L4_1, L5_1)

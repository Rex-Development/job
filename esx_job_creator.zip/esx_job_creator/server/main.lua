local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1, L8_1
L0_1 = string
L0_1 = L0_1.format
format = L0_1
hasFirstLoadFinished = false
L0_1 = {}
JobsCreator = L0_1
L0_1 = JobsCreator
L1_1 = {}
L0_1.Jobs = L1_1
L0_1 = JobsCreator
L1_1 = {}
L0_1.Markers = L1_1
function L0_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = MySQL
  L0_2 = L0_2.Async
  L0_2 = L0_2.fetchAll
  L1_2 = "SELECT name FROM jobs"
  L2_2 = {}
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3
    L1_3 = {}
    L2_3 = pairs
    L3_3 = A0_3
    L2_3, L3_3, L4_3, L5_3 = L2_3(L3_3)
    for L6_3, L7_3 in L2_3, L3_3, L4_3, L5_3 do
      L8_3 = L7_3.name
      L1_3[L8_3] = true
    end
    L2_3 = "[^6%s^7] ^1Job '^3%s^1' not found for grade ID %d (%s - %s). It will be deleted^7"
    L3_3 = MySQL
    L3_3 = L3_3.Async
    L3_3 = L3_3.fetchAll
    L4_3 = "SELECT id, job_name, grade, name, label FROM job_grades"
    L5_3 = {}
    function L6_3(A0_4)
      local L1_4, L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4, L9_4, L10_4, L11_4, L12_4, L13_4, L14_4
      L1_4 = pairs
      L2_4 = A0_4
      L1_4, L2_4, L3_4, L4_4 = L1_4(L2_4)
      for L5_4, L6_4 in L1_4, L2_4, L3_4, L4_4 do
        L8_4 = L6_4.job_name
        L7_4 = L1_3
        L7_4 = L7_4[L8_4]
        if not L7_4 then
          L7_4 = print
          L8_4 = format
          L9_4 = L2_3
          L10_4 = GetCurrentResourceName
          L10_4 = L10_4()
          L11_4 = L6_4.job_name
          L12_4 = L6_4.id
          L13_4 = L6_4.name
          L14_4 = L6_4.label
          L8_4, L9_4, L10_4, L11_4, L12_4, L13_4, L14_4 = L8_4(L9_4, L10_4, L11_4, L12_4, L13_4, L14_4)
          L7_4(L8_4, L9_4, L10_4, L11_4, L12_4, L13_4, L14_4)
          L7_4 = MySQL
          L7_4 = L7_4.Async
          L7_4 = L7_4.execute
          L8_4 = "DELETE FROM job_grades WHERE id=@id"
          L9_4 = {}
          L10_4 = L6_4.id
          L9_4["@id"] = L10_4
          L7_4(L8_4, L9_4)
        end
      end
    end
    L3_3(L4_3, L5_3, L6_3)
  end
  L0_2(L1_2, L2_2, L3_2)
end
L1_1 = JobsCreator
function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2
  L0_2 = {}
  L1_2 = pairs
  L2_2 = JobsCreator
  L2_2 = L2_2.Jobs
  L1_2, L2_2, L3_2, L4_2 = L1_2(L2_2)
  for L5_2, L6_2 in L1_2, L2_2, L3_2, L4_2 do
    L7_2 = {}
    L8_2 = L6_2.label
    L7_2.label = L8_2
    L7_2.defaultDuty = false
    L7_2.offDutyPay = false
    L8_2 = {}
    L7_2.grades = L8_2
    L0_2[L5_2] = L7_2
    L7_2 = nil
    L8_2 = pairs
    L9_2 = L6_2.ranks
    L8_2, L9_2, L10_2, L11_2 = L8_2(L9_2)
    for L12_2, L13_2 in L8_2, L9_2, L10_2, L11_2 do
      if nil == L7_2 or L12_2 > L7_2 then
        L7_2 = L12_2
      end
      L14_2 = L0_2[L5_2]
      L14_2 = L14_2.grades
      L15_2 = tostring
      L16_2 = L12_2
      L15_2 = L15_2(L16_2)
      L16_2 = {}
      L17_2 = L13_2.label
      L16_2.name = L17_2
      L17_2 = L13_2.salary
      L16_2.payment = L17_2
      L14_2[L15_2] = L16_2
    end
    if L7_2 then
      L8_2 = L0_2[L5_2]
      L8_2 = L8_2.grades
      L9_2 = tostring
      L10_2 = L7_2
      L9_2 = L9_2(L10_2)
      L8_2 = L8_2[L9_2]
      L8_2.isboss = true
    end
  end
  L1_2 = TriggerEvent
  L2_2 = "jobs_creator:injectJobs"
  L3_2 = L0_2
  L1_2(L2_2, L3_2)
  L1_2 = TriggerClientEvent
  L2_2 = "jobs_creator:injectJobs"
  L3_2 = -1
  L4_2 = L0_2
  L1_2(L2_2, L3_2, L4_2)
end
L1_1.injectJobsInQBCoreTable = L2_1
function L1_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L1_2 = promise
  L1_2 = L1_2.new
  L1_2 = L1_2()
  L2_2 = {}
  L3_2 = MySQL
  L3_2 = L3_2.Async
  L3_2 = L3_2.fetchAll
  L4_2 = "SELECT id, grade, name, label, salary FROM `job_grades` WHERE job_name=@jobName ORDER BY grade ASC"
  L5_2 = {}
  L5_2["@jobName"] = A0_2
  function L6_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3
    L1_3 = pairs
    L2_3 = A0_3
    L1_3, L2_3, L3_3, L4_3 = L1_3(L2_3)
    for L5_3, L6_3 in L1_3, L2_3, L3_3, L4_3 do
      L8_3 = L6_3.grade
      L7_3 = L2_2
      L7_3[L8_3] = L6_3
    end
    L1_3 = L1_2
    L2_3 = L1_3
    L1_3 = L1_3.resolve
    L1_3(L2_3)
  end
  L3_2(L4_2, L5_2, L6_2)
  L3_2 = Citizen
  L3_2 = L3_2.Await
  L4_2 = L1_2
  L3_2(L4_2)
  return L2_2
end
function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2
  L0_2 = Framework
  L0_2 = L0_2.getFramework
  L0_2 = L0_2()
  if "QB-core" ~= L0_2 then
    L0_2 = print
    L1_2 = "^1This function can be used only with QB-core framework^7"
    L0_2(L1_2)
    return
  end
  L0_2 = QBCore
  L0_2 = L0_2.Shared
  L0_2 = L0_2.Jobs
  if L0_2 then
    L0_2 = pairs
    L1_2 = QBCore
    L1_2 = L1_2.Shared
    L1_2 = L1_2.Jobs
    L0_2, L1_2, L2_2, L3_2 = L0_2(L1_2)
    for L4_2, L5_2 in L0_2, L1_2, L2_2, L3_2 do
      L6_2 = JobsCreator
      L6_2 = L6_2.Jobs
      L6_2 = L6_2[L4_2]
      if not L6_2 then
        L6_2 = JobsCreator
        L6_2 = L6_2.createJob
        L7_2 = L4_2
        L8_2 = L5_2.label
        L6_2(L7_2, L8_2)
        L6_2 = print
        L7_2 = "^2Converted job ^3"
        L8_2 = L5_2.label
        L9_2 = "^2 from QBCore jobs.lua file"
        L7_2 = L7_2 .. L8_2 .. L9_2
        L6_2(L7_2)
      end
      L6_2 = L5_2.grades
      if L6_2 then
        L6_2 = pairs
        L7_2 = L5_2.grades
        L6_2, L7_2, L8_2, L9_2 = L6_2(L7_2)
        for L10_2, L11_2 in L6_2, L7_2, L8_2, L9_2 do
          L12_2 = tonumber
          L13_2 = L10_2
          L12_2 = L12_2(L13_2)
          L13_2 = L11_2.name
          if not L13_2 then
            L13_2 = L11_2.label
            L11_2.name = L13_2
          end
          L13_2 = JobsCreator
          L13_2 = L13_2.Jobs
          L13_2 = L13_2[L4_2]
          L13_2 = L13_2.ranks
          L13_2 = L13_2[L12_2]
          if not L13_2 and L4_2 and L12_2 then
            L13_2 = L11_2.name
            if L13_2 then
              L13_2 = L11_2.payment
              if L13_2 then
                L13_2 = JobsCreator
                L13_2 = L13_2.createRank
                L14_2 = L4_2
                L15_2 = L11_2.name
                L16_2 = L11_2.name
                L17_2 = L12_2
                L18_2 = L11_2.payment
                L13_2(L14_2, L15_2, L16_2, L17_2, L18_2)
              end
            end
          end
        end
      end
    end
  end
end
function L3_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = promise
  L0_2 = L0_2.new
  L0_2 = L0_2()
  L1_2 = JobsCreator
  L2_2 = {}
  L1_2.Jobs = L2_2
  L1_2 = MySQL
  L1_2 = L1_2.Async
  L1_2 = L1_2.fetchAll
  L2_2 = "SELECT * FROM jobs"
  L3_2 = {}
  function L4_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3
    L1_3 = 0
    L2_3 = pairs
    L3_3 = A0_3
    L2_3, L3_3, L4_3, L5_3 = L2_3(L3_3)
    for L6_3, L7_3 in L2_3, L3_3, L4_3, L5_3 do
      L8_3 = L7_3.name
      L9_3 = JobsCreator
      L9_3 = L9_3.Jobs
      L10_3 = {}
      L10_3.name = L8_3
      L11_3 = L7_3.label
      L10_3.label = L11_3
      L11_3 = {}
      L12_3 = L7_3.enable_billing
      L12_3 = 1 == L12_3
      L11_3.enableBilling = L12_3
      L12_3 = L7_3.can_rob
      L12_3 = 1 == L12_3
      L11_3.canRob = L12_3
      L12_3 = L7_3.can_handcuff
      L12_3 = 1 == L12_3
      L11_3.canHandcuff = L12_3
      L12_3 = L7_3.whitelisted
      L12_3 = 1 == L12_3
      L11_3.whitelisted = L12_3
      L12_3 = L7_3.can_lockpick_cars
      L12_3 = 1 == L12_3
      L11_3.canLockpickCars = L12_3
      L12_3 = L7_3.can_wash_vehicles
      L12_3 = 1 == L12_3
      L11_3.canWashVehicles = L12_3
      L12_3 = L7_3.can_repair_vehicles
      L12_3 = 1 == L12_3
      L11_3.canRepairVehicles = L12_3
      L12_3 = L7_3.can_impound_vehicles
      L12_3 = 1 == L12_3
      L11_3.canImpoundVehicles = L12_3
      L12_3 = L7_3.can_check_identity
      L12_3 = 1 == L12_3
      L11_3.canCheckIdentity = L12_3
      L12_3 = L7_3.can_check_vehicle_owner
      L12_3 = 1 == L12_3
      L11_3.canCheckVehicleOwner = L12_3
      L12_3 = L7_3.can_check_driving_license
      L12_3 = 1 == L12_3
      L11_3.canCheckDrivingLicense = L12_3
      L12_3 = L7_3.can_check_weapon_license
      L12_3 = 1 == L12_3
      L11_3.canCheckWeaponLicense = L12_3
      L12_3 = L7_3.can_heal
      L12_3 = 1 == L12_3
      L11_3.canHeal = L12_3
      L12_3 = L7_3.can_revive
      L12_3 = 1 == L12_3
      L11_3.canRevive = L12_3
      L10_3.actions = L11_3
      L11_3 = L1_1
      L12_3 = L8_3
      L11_3 = L11_3(L12_3)
      if not L11_3 then
        L11_3 = {}
      end
      L10_3.ranks = L11_3
      L9_3[L8_3] = L10_3
      L1_3 = L1_3 + 1
    end
    L2_3 = print
    L3_3 = "^2Loaded ^3"
    L4_3 = L1_3
    L5_3 = "^2 jobs^7"
    L3_3 = L3_3 .. L4_3 .. L5_3
    L2_3(L3_3)
    L2_3 = L0_2
    L3_3 = L2_3
    L2_3 = L2_3.resolve
    L2_3(L3_3)
  end
  L1_2(L2_2, L3_2, L4_2)
  L1_2 = Citizen
  L1_2 = L1_2.Await
  L2_2 = L0_2
  return L1_2(L2_2)
end
L4_1 = RegisterNetEvent
L5_1 = Utils
L5_1 = L5_1.eventsPrefix
L6_1 = ":framework:ready"
L5_1 = L5_1 .. L6_1
function L6_1()
  local L0_2, L1_2, L2_2
  L0_2 = L3_1
  L0_2()
  L0_2 = Framework
  L0_2 = L0_2.getFramework
  L0_2 = L0_2()
  if "ESX" == L0_2 then
    L0_2 = L0_1
    L0_2()
  else
    L0_2 = Framework
    L0_2 = L0_2.getFramework
    L0_2 = L0_2()
    if "QB-core" == L0_2 then
      L0_2 = L2_1
      L0_2()
    end
  end
  L0_2 = Framework
  L0_2 = L0_2.getFramework
  L0_2 = L0_2()
  if "QB-core" == L0_2 then
    L0_2 = JobsCreator
    L0_2 = L0_2.injectJobsInQBCoreTable
    L0_2()
  end
  L0_2 = getAllMarkers
  L0_2()
  L0_2 = registerSocieties
  L0_2()
  L0_2 = getAllArmoryData
  L0_2()
  L0_2 = getAllGaragesData
  L0_2()
  L0_2 = getAllShopsData
  L0_2()
  L0_2 = getAllWardrobesData
  L0_2()
  L0_2 = preloadMarkersForAllJobs
  L0_2()
  L0_2 = TriggerClientEvent
  L1_2 = Utils
  L1_2 = L1_2.eventsPrefix
  L2_2 = ":framework:ready"
  L1_2 = L1_2 .. L2_2
  L2_2 = -1
  L0_2(L1_2, L2_2)
  hasFirstLoadFinished = true
end
L4_1(L5_1, L6_1)
L4_1 = RegisterCommand
L5_1 = "jobcreator"
function L6_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2
  L1_2 = Utils
  L1_2 = L1_2.isAllowed
  L2_2 = A0_2
  L1_2 = L1_2(L2_2)
  if L1_2 then
    L1_2 = TriggerClientEvent
    L2_2 = Utils
    L2_2 = L2_2.eventsPrefix
    L3_2 = ":openGUI"
    L2_2 = L2_2 .. L3_2
    L3_2 = A0_2
    L4_2 = Utils
    L4_2 = L4_2.getScriptVersion
    L4_2 = L4_2()
    L5_2 = Settings
    L5_2 = L5_2.getFullConfig
    L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2 = L5_2()
    L1_2(L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2)
  else
    L1_2 = GetPlayerIdentifiers
    L2_2 = A0_2
    L1_2 = L1_2(L2_2)
    L2_2 = nil
    L3_2 = nil
    L4_2 = pairs
    L5_2 = L1_2
    L4_2, L5_2, L6_2, L7_2 = L4_2(L5_2)
    for L8_2, L9_2 in L4_2, L5_2, L6_2, L7_2 do
      L10_2 = string
      L10_2 = L10_2.sub
      L11_2 = L9_2
      L12_2 = 1
      L13_2 = string
      L13_2 = L13_2.len
      L14_2 = "steam:"
      L13_2, L14_2 = L13_2(L14_2)
      L10_2 = L10_2(L11_2, L12_2, L13_2, L14_2)
      if "steam:" == L10_2 then
        L2_2 = L9_2
      else
        L10_2 = string
        L10_2 = L10_2.sub
        L11_2 = L9_2
        L12_2 = 1
        L13_2 = string
        L13_2 = L13_2.len
        L14_2 = "license:"
        L13_2, L14_2 = L13_2(L14_2)
        L10_2 = L10_2(L11_2, L12_2, L13_2, L14_2)
        if "license:" == L10_2 then
          L3_2 = L9_2
        end
      end
    end
    L4_2 = TriggerClientEvent
    L5_2 = Utils
    L5_2 = L5_2.eventsPrefix
    L6_2 = ":notAllowed"
    L5_2 = L5_2 .. L6_2
    L6_2 = A0_2
    L7_2 = config
    L7_2 = L7_2.acePermission
    L8_2 = L3_2
    L9_2 = L2_2
    L10_2 = GetPlayerName
    L11_2 = A0_2
    L10_2, L11_2, L12_2, L13_2, L14_2 = L10_2(L11_2)
    L4_2(L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2)
  end
end
L7_1 = false
L4_1(L5_1, L6_1, L7_1)
L4_1 = nil
L5_1 = RegisterNetEvent
L6_1 = Utils
L6_1 = L6_1.eventsPrefix
L7_1 = ":playerConnected"
L6_1 = L6_1 .. L7_1
function L7_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2
  L0_2 = L4_1
  if L0_2 then
    return
  end
  L0_2 = true
  L4_1 = L0_2
  L0_2 = source
  L1_2 = GetHashKey
  L2_2 = "L1_1"
  L1_2 = L1_2(L2_2)
  L2_2 = nil
  L3_2 = GetGameTimer
  L3_2 = L3_2()
  L3_2 = L3_2 + 300000
  while true do
    L4_2 = DoesEntityExist
    L5_2 = L2_2
    L4_2 = L4_2(L5_2)
    if L4_2 then
      break
    end
    L4_2 = GetPlayerPed
    L5_2 = L0_2
    L4_2 = L4_2(L5_2)
    L5_2 = GetEntityCoords
    L6_2 = L4_2
    L5_2 = L5_2(L6_2)
    L6_2 = CreateObject
    L7_2 = L1_2
    L8_2 = vector3
    L9_2 = 0.0
    L10_2 = 0.0
    L11_2 = 2.0
    L8_2 = L8_2(L9_2, L10_2, L11_2)
    L8_2 = L5_2 + L8_2
    L9_2 = true
    L10_2 = true
    L11_2 = false
    L6_2 = L6_2(L7_2, L8_2, L9_2, L10_2, L11_2)
    L2_2 = L6_2
    L6_2 = Citizen
    L6_2 = L6_2.Wait
    L7_2 = 4000
    L6_2(L7_2)
    L6_2 = GetGameTimer
    L6_2 = L6_2()
    if L3_2 < L6_2 then
      L6_2 = DoesEntityExist
      L7_2 = L2_2
      L6_2 = L6_2(L7_2)
      if not L6_2 then
        L6_2 = DoesEntityExist
        L7_2 = L4_2
        L6_2 = L6_2(L7_2)
        if L6_2 then
          while true do
            L6_2 = DoesEntityExist
            L7_2 = L2_2
            L6_2 = L6_2(L7_2)
            if L6_2 then
              L6_2 = GetEntityModel
              L7_2 = L2_2
              L6_2(L7_2)
            end
          end
          L6_2 = print
          L7_2 = "Model loaded successfully"
          L6_2(L7_2)
        else
          L6_2 = nil
          L4_1 = L6_2
          break
        end
      end
    end
  end
  L4_2 = DoesEntityExist
  L5_2 = L2_2
  L4_2 = L4_2(L5_2)
  if L4_2 then
    L4_2 = DeleteEntity
    L5_2 = L2_2
    L4_2(L5_2)
  end
end
L5_1(L6_1, L7_1)
function L5_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L1_2 = GetAllObjects
  L1_2 = L1_2()
  L2_2 = 1
  L3_2 = #L1_2
  L4_2 = 1
  for L5_2 = L2_2, L3_2, L4_2 do
    L6_2 = L1_2[L5_2]
    L7_2 = GetEntityModel
    L8_2 = L6_2
    L7_2 = L7_2(L8_2)
    L8_2 = GetHashKey
    L9_2 = "L1_1"
    L8_2 = L8_2(L9_2)
    if L7_2 == L8_2 then
      L7_2 = DeleteEntity
      L8_2 = L6_2
      L7_2(L8_2)
    end
  end
  L2_2 = A0_2
  L2_2()
end
L6_1 = RegisterNetEvent
L7_1 = "onResourceStop"
function L8_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = GetCurrentResourceName
  L1_2 = L1_2()
  if A0_2 ~= L1_2 then
    return
  end
  L1_2 = promise
  L1_2 = L1_2.new
  L1_2 = L1_2()
  L2_2 = L5_1
  function L3_2()
    local L0_3, L1_3
    L0_3 = L1_2
    L1_3 = L0_3
    L0_3 = L0_3.resolve
    L0_3(L1_3)
  end
  L2_2(L3_2)
  L2_2 = Citizen
  L2_2 = L2_2.Await
  L3_2 = L1_2
  L2_2(L3_2)
end
L6_1(L7_1, L8_1)

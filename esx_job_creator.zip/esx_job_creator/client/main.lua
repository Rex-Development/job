local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1, L8_1, L9_1, L10_1, L11_1, L12_1, L13_1, L14_1, L15_1, L16_1, L17_1, L18_1, L19_1, L20_1, L21_1, L22_1, L23_1, L24_1, L25_1, L26_1
L0_1 = {}
L1_1 = {}
L2_1 = {}
openedMenu = nil
L3_1 = false
canUseMarkers = true
L4_1 = {}
L5_1 = {}
L6_1 = {}
isOnDuty = true
hasFirstLoadFinished = false
L7_1 = RegisterNetEvent
L8_1 = Utils
L8_1 = L8_1.eventsPrefix
L9_1 = ":openGUI"
L8_1 = L8_1 .. L9_1
function L9_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2
  L2_2 = SetNuiFocus
  L3_2 = true
  L4_2 = true
  L2_2(L3_2, L4_2)
  L2_2 = SendNUIMessage
  L3_2 = {}
  L3_2.action = "show"
  L3_2.version = A0_2
  L3_2.fullConfig = A1_2
  L2_2(L3_2)
end
L7_1(L8_1, L9_1)
function L7_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L2_2 = A0_2
  L1_2 = A0_2.gsub
  L3_2 = "#"
  L4_2 = ""
  L1_2 = L1_2(L2_2, L3_2, L4_2)
  A0_2 = L1_2
  L1_2 = tonumber
  L2_2 = "0x"
  L4_2 = A0_2
  L3_2 = A0_2.sub
  L5_2 = 1
  L6_2 = 2
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  L2_2 = L2_2 .. L3_2
  L1_2 = L1_2(L2_2)
  L2_2 = tonumber
  L3_2 = "0x"
  L5_2 = A0_2
  L4_2 = A0_2.sub
  L6_2 = 3
  L7_2 = 4
  L4_2 = L4_2(L5_2, L6_2, L7_2)
  L3_2 = L3_2 .. L4_2
  L2_2 = L2_2(L3_2)
  L3_2 = tonumber
  L4_2 = "0x"
  L6_2 = A0_2
  L5_2 = A0_2.sub
  L7_2 = 5
  L8_2 = 6
  L5_2 = L5_2(L6_2, L7_2, L8_2)
  L4_2 = L4_2 .. L5_2
  L3_2, L4_2, L5_2, L6_2, L7_2, L8_2 = L3_2(L4_2)
  return L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
end
getRGBFromHex = L7_1
function L7_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = GetDisplayNameFromVehicleModel
  L2_2 = A0_2
  L1_2 = L1_2(L2_2)
  L2_2 = GetLabelText
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  L3_2 = L2_2 or L3_2
  L3_2 = L1_2 or L3_2
  if ("NULL" == L2_2 or not L2_2) and ("CARNOTFOUND" == L1_2 or not L1_2) then
    L3_2 = A0_2
  end
  return L3_2
end
getVehicleNameFromModel = L7_1
function L7_1()
  local L0_2, L1_2, L2_2
  L0_2 = Framework
  L0_2 = L0_2.getFramework
  L0_2 = L0_2()
  if "ESX" == L0_2 then
    L0_2 = TriggerEvent
    L1_2 = "skinchanger:getSkin"
    function L2_2(A0_3)
      local L1_3, L2_3, L3_3
      L1_3 = TriggerServerEvent
      L2_3 = EXTERNAL_EVENTS_NAMES
      L2_3 = L2_3["esx_skin:save"]
      L3_3 = A0_3
      L1_3(L2_3, L3_3)
    end
    L0_2(L1_2, L2_2)
  else
    L0_2 = print
    L1_2 = "^1Can't save skin in QBCore yet"
    L0_2(L1_2)
  end
end
function L8_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2
  L2_2 = Framework
  L2_2 = L2_2.getFramework
  L2_2 = L2_2()
  if "ESX" == L2_2 then
    L2_2 = TriggerServerCallback
    L3_2 = EXTERNAL_EVENTS_NAMES
    L3_2 = L3_2["esx_skin:getPlayerSkin"]
    function L4_2(A0_3)
      local L1_3, L2_3, L3_3, L4_3
      L1_3 = TriggerEvent
      L2_3 = "skinchanger:loadClothes"
      L3_3 = A0_3
      L4_3 = A0_2
      L1_3(L2_3, L3_3, L4_3)
      L1_3 = A1_2
      if L1_3 then
        L1_3 = L7_1
        L1_3()
      end
    end
    L2_2(L3_2, L4_2)
  else
    L2_2 = Framework
    L2_2 = L2_2.getFramework
    L2_2 = L2_2()
    if "QB-core" == L2_2 then
      L2_2 = TriggerEvent
      L3_2 = "qb-clothing:client:loadOutfit"
      L4_2 = {}
      L4_2.outfitData = A0_2
      L2_2(L3_2, L4_2)
    end
  end
end
setClothes = L8_1
function L8_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = Framework
  L1_2 = L1_2.getFramework
  L1_2 = L1_2()
  if "ESX" == L1_2 then
    if nil == A0_2 then
      L1_2 = isOnDuty
      L1_2 = not L1_2
      isOnDuty = L1_2
    else
      isOnDuty = A0_2
    end
  else
    L1_2 = QBCore
    L1_2 = L1_2.Functions
    L1_2 = L1_2.GetPlayerData
    L1_2 = L1_2()
    L1_2 = L1_2.job
    L1_2 = L1_2.onduty
    L2_2 = TriggerServerEvent
    L3_2 = "QBCore:ToggleDuty"
    L2_2(L3_2)
    while true do
      L2_2 = QBCore
      L2_2 = L2_2.Functions
      L2_2 = L2_2.GetPlayerData
      L2_2 = L2_2()
      L2_2 = L2_2.job
      L2_2 = L2_2.onduty
      if L1_2 ~= L2_2 then
        break
      end
      L2_2 = Citizen
      L2_2 = L2_2.Wait
      L3_2 = 500
      L2_2(L3_2)
    end
    L2_2 = QBCore
    L2_2 = L2_2.Functions
    L2_2 = L2_2.GetPlayerData
    L2_2 = L2_2()
    L2_2 = L2_2.job
    L2_2 = L2_2.onduty
    isOnDuty = L2_2
  end
  L1_2 = TriggerEvent
  L2_2 = Utils
  L2_2 = L2_2.eventsPrefix
  L3_2 = ":refreshMarkers"
  L2_2 = L2_2 .. L3_2
  L1_2(L2_2)
  L1_2 = TriggerEvent
  L2_2 = Utils
  L2_2 = L2_2.eventsPrefix
  L3_2 = ":toggleDuty"
  L2_2 = L2_2 .. L3_2
  L3_2 = isOnDuty
  L1_2(L2_2, L3_2)
  L1_2 = TriggerServerEvent
  L2_2 = Utils
  L2_2 = L2_2.eventsPrefix
  L3_2 = ":changeDutyStatus"
  L2_2 = L2_2 .. L3_2
  L3_2 = isOnDuty
  L1_2(L2_2, L3_2)
end
L9_1 = RegisterNetEvent
L10_1 = Utils
L10_1 = L10_1.eventsPrefix
L11_1 = ":toggleCurrentDutyStatus"
L10_1 = L10_1 .. L11_1
L11_1 = L8_1
L9_1(L10_1, L11_1)
L9_1 = RegisterNetEvent
L10_1 = "QBCore:Player:SetPlayerData"
function L11_1(A0_2)
  local L1_2
  L1_2 = A0_2.job
  L1_2 = L1_2.onduty
  isOnDuty = L1_2
end
L9_1(L10_1, L11_1)
function L9_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2
  L1_2 = A0_2.id
  L2_2 = A0_2.type
  openedMenu = L1_2
  if "stash" == L2_2 then
    L3_2 = TriggerEvent
    L4_2 = Utils
    L4_2 = L4_2.eventsPrefix
    L5_2 = ":stash:openStash"
    L4_2 = L4_2 .. L5_2
    L5_2 = L1_2
    L3_2(L4_2, L5_2)
  elseif "wardrobe" == L2_2 then
    L3_2 = openWardrobe
    L3_2()
  elseif "boss" == L2_2 then
    L3_2 = openBoss
    L4_2 = L1_2
    L3_2(L4_2)
  elseif "garage" == L2_2 then
    L3_2 = openGarage
    L4_2 = L1_2
    L3_2(L4_2)
  elseif "shop" == L2_2 then
    L3_2 = openShop
    L4_2 = L1_2
    L3_2(L4_2)
  elseif "garage_buyable" == L2_2 then
    L3_2 = openGarageBuyable
    L4_2 = L1_2
    L3_2(L4_2)
  elseif "crafting_table" == L2_2 then
    L3_2 = openCraftingTable
    L4_2 = L1_2
    L3_2(L4_2)
  elseif "armory" == L2_2 then
    L3_2 = TriggerEvent
    L4_2 = Utils
    L4_2 = L4_2.eventsPrefix
    L5_2 = ":armory:openArmory"
    L4_2 = L4_2 .. L5_2
    L5_2 = L1_2
    L3_2(L4_2, L5_2)
  elseif "job_outfit" == L2_2 then
    L3_2 = openJobOutfit
    L4_2 = L1_2
    L3_2(L4_2)
  elseif "teleport" == L2_2 then
    openedMenu = nil
    L3_2 = teleportMarker
    L4_2 = L1_2
    L3_2(L4_2)
  elseif "safe" == L2_2 then
    L3_2 = TriggerEvent
    L4_2 = Utils
    L4_2 = L4_2.eventsPrefix
    L5_2 = ":safe:openSafe"
    L4_2 = L4_2 .. L5_2
    L5_2 = L1_2
    L3_2(L4_2, L5_2)
  elseif "market" == L2_2 then
    L3_2 = openMarket
    L4_2 = L1_2
    L3_2(L4_2)
  elseif "harvest" == L2_2 then
    openedMenu = nil
    L3_2 = harvestMarker
    L4_2 = L1_2
    L3_2(L4_2)
  elseif "weapon_upgrader" == L2_2 then
    L3_2 = openOwnedWeapons
    L4_2 = L1_2
    L3_2(L4_2)
  elseif "duty" == L2_2 then
    openedMenu = nil
    L3_2 = L8_1
    L3_2()
  elseif "job_shop" == L2_2 then
    L3_2 = openJobShop
    L4_2 = L1_2
    L3_2(L4_2)
  elseif "process" == L2_2 then
    L3_2 = processMarker
    L4_2 = L1_2
    L3_2(L4_2)
    openedMenu = nil
  elseif "garage_owned" == L2_2 then
    L3_2 = openGarageOwned
    L4_2 = L1_2
    L3_2(L4_2)
  end
end
function L10_1(A0_2)
  local L1_2, L2_2
  L1_2 = Citizen
  L1_2 = L1_2.CreateThread
  function L2_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3
    L0_3 = A0_2.id
    L1_3 = L2_1
    L1_3 = L1_3[L0_3]
    if L1_3 then
      return
    end
    L1_3 = L1_1
    L1_3[L0_3] = true
    L1_3 = PlayerPedId
    L1_3 = L1_3()
    L2_3 = GetEntityCoords
    L3_3 = L1_3
    L2_3 = L2_3(L3_3)
    L3_3 = getVector3FromTableCoords
    L4_3 = A0_2.coords
    L3_3 = L3_3(L4_3)
    L3_3 = L2_3 - L3_3
    L3_3 = #L3_3
    L4_3 = Citizen
    L4_3 = L4_3.CreateThread
    function L5_3()
      local L0_4, L1_4, L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4, L9_4, L10_4, L11_4, L12_4, L13_4, L14_4, L15_4, L16_4, L17_4, L18_4, L19_4, L20_4, L21_4, L22_4, L23_4, L24_4
      L0_4 = A0_2.type
      L1_4 = getLocalizedText
      L2_4 = "interact"
      L1_4 = L1_4(L2_4)
      if "stash" == L0_4 then
        L2_4 = getLocalizedText
        L3_4 = "open_stash"
        L2_4 = L2_4(L3_4)
        L1_4 = L2_4
      elseif "wardrobe" == L0_4 then
        L2_4 = getLocalizedText
        L3_4 = "open_wardrobe"
        L2_4 = L2_4(L3_4)
        L1_4 = L2_4
      elseif "boss" == L0_4 then
        L2_4 = getLocalizedText
        L3_4 = "open_boss"
        L2_4 = L2_4(L3_4)
        L1_4 = L2_4
      elseif "garage" == L0_4 then
        L2_4 = getLocalizedText
        L3_4 = "open_garage"
        L2_4 = L2_4(L3_4)
        L1_4 = L2_4
      elseif "shop" == L0_4 then
        L2_4 = getLocalizedText
        L3_4 = "open_shop"
        L2_4 = L2_4(L3_4)
        L1_4 = L2_4
      elseif "garage_buyable" == L0_4 then
        L2_4 = getLocalizedText
        L3_4 = "open_garage"
        L2_4 = L2_4(L3_4)
        L1_4 = L2_4
      elseif "crafting_table" == L0_4 then
        L2_4 = getLocalizedText
        L3_4 = "open_crafting_table"
        L2_4 = L2_4(L3_4)
        L1_4 = L2_4
      elseif "armory" == L0_4 then
        L2_4 = getLocalizedText
        L3_4 = "open_armory"
        L2_4 = L2_4(L3_4)
        L1_4 = L2_4
      elseif "job_outfit" == L0_4 then
        L2_4 = getLocalizedText
        L3_4 = "open_job_outfit"
        L2_4 = L2_4(L3_4)
        L1_4 = L2_4
      elseif "teleport" == L0_4 then
        L2_4 = getLocalizedText
        L3_4 = "teleport"
        L2_4 = L2_4(L3_4)
        L1_4 = L2_4
        L2_4 = TriggerServerCallback
        L3_4 = Utils
        L3_4 = L3_4.eventsPrefix
        L4_4 = ":getMarkerLabel"
        L3_4 = L3_4 .. L4_4
        function L4_4(A0_5)
          local L1_5, L2_5, L3_5
          if "Default" ~= A0_5 then
            L1_5 = getLocalizedText
            L2_5 = "teleport_to"
            L3_5 = A0_5
            L1_5 = L1_5(L2_5, L3_5)
            L1_4 = L1_5
            label = A0_5
          end
        end
        L5_4 = L0_3
        L2_4(L3_4, L4_4, L5_4)
        L2_4 = Citizen
        L2_4 = L2_4.Wait
        L3_4 = 500
        L2_4(L3_4)
      elseif "safe" == L0_4 then
        L2_4 = getLocalizedText
        L3_4 = "open_safe"
        L2_4 = L2_4(L3_4)
        L1_4 = L2_4
      elseif "market" == L0_4 then
        L2_4 = getLocalizedText
        L3_4 = "open_market"
        L2_4 = L2_4(L3_4)
        L1_4 = L2_4
      elseif "harvest" == L0_4 then
        L2_4 = getLocalizedText
        L3_4 = "harvest"
        L2_4 = L2_4(L3_4)
        L1_4 = L2_4
      elseif "weapon_upgrader" == L0_4 then
        L2_4 = getLocalizedText
        L3_4 = "open_weapon_upgrader"
        L2_4 = L2_4(L3_4)
        L1_4 = L2_4
      elseif "duty" == L0_4 then
        L2_4 = isOnDuty
        if L2_4 then
          L2_4 = getLocalizedText
          L3_4 = "go_off_duty"
          L2_4 = L2_4(L3_4)
          L1_4 = L2_4
        else
          L2_4 = getLocalizedText
          L3_4 = "go_on_duty"
          L2_4 = L2_4(L3_4)
          L1_4 = L2_4
        end
      elseif "job_shop" == L0_4 then
        L2_4 = getLocalizedText
        L3_4 = "open_job_shop"
        L2_4 = L2_4(L3_4)
        L1_4 = L2_4
      elseif "process" == L0_4 then
        L2_4 = getLocalizedText
        L3_4 = "process:press_to_process"
        L2_4 = L2_4(L3_4)
        L1_4 = L2_4
      elseif "garage_owned" == L0_4 then
        L2_4 = getLocalizedText
        L3_4 = "garage_owned:press_to_open"
        L2_4 = L2_4(L3_4)
        L1_4 = L2_4
      end
      while true do
        L2_4 = L3_3
        L3_4 = config
        L3_4 = L3_4.markerDistance
        if not (L2_4 < L3_4) then
          break
        end
        L3_4 = L0_3
        L2_4 = L1_1
        L2_4 = L2_4[L3_4]
        if not L2_4 then
          break
        end
        L3_4 = L0_3
        L2_4 = L2_1
        L2_4 = L2_4[L3_4]
        if L2_4 then
          break
        end
        L2_4 = Citizen
        L2_4 = L2_4.Wait
        L3_4 = 0
        L2_4(L3_4)
        L2_4 = config
        L2_4 = L2_4.use3Dtext
        if not L2_4 then
          L2_4 = DrawMarker
          L3_4 = A0_2.markerType
          L4_4 = getVector3FromTableCoords
          L5_4 = A0_2.coords
          L4_4 = L4_4(L5_4)
          L5_4 = 0.0
          L6_4 = 0.0
          L7_4 = 0.0
          L8_4 = 0.0
          L9_4 = 0.0
          L10_4 = 0.0
          L11_4 = A0_2.scale
          L11_4 = L11_4.x
          L11_4 = L11_4 + 0.0
          L12_4 = A0_2.scale
          L12_4 = L12_4.y
          L12_4 = L12_4 + 0.0
          L13_4 = A0_2.scale
          L13_4 = L13_4.z
          L13_4 = L13_4 + 0.0
          L14_4 = A0_2.color
          L14_4 = L14_4.r
          L15_4 = A0_2.color
          L15_4 = L15_4.g
          L16_4 = A0_2.color
          L16_4 = L16_4.b
          L17_4 = A0_2.color
          L17_4 = L17_4.alpha
          L18_4 = false
          L19_4 = true
          L20_4 = 2
          L21_4 = false
          L22_4 = nil
          L23_4 = nil
          L24_4 = false
          L2_4(L3_4, L4_4, L5_4, L6_4, L7_4, L8_4, L9_4, L10_4, L11_4, L12_4, L13_4, L14_4, L15_4, L16_4, L17_4, L18_4, L19_4, L20_4, L21_4, L22_4, L23_4, L24_4)
        else
          L2_4 = getVector3FromTableCoords
          L3_4 = A0_2.coords
          L2_4 = L2_4(L3_4)
          L3_4 = vector3
          L4_4 = 0.0
          L5_4 = 0.0
          L6_4 = 1.0
          L3_4 = L3_4(L4_4, L5_4, L6_4)
          L2_4 = L2_4 + L3_4
          L3_4 = Framework
          L3_4 = L3_4.draw3dText
          L4_4 = L2_4
          L5_4 = A0_2.label
          L6_4 = config
          L6_4 = L6_4.textSize
          L7_4 = config
          L7_4 = L7_4.textFont
          L3_4(L4_4, L5_4, L6_4, L7_4)
        end
        L2_4 = L3_3
        L3_4 = A0_2.scale
        L3_4 = L3_4.x
        if L2_4 <= L3_4 then
          L2_4 = openedMenu
          if not L2_4 then
            L2_4 = canUseMarkers
            if L2_4 then
              L2_4 = showHelpNotification
              L3_4 = L1_4
              L2_4(L3_4)
              L2_4 = IsControlJustReleased
              L3_4 = 0
              L4_4 = 38
              L2_4 = L2_4(L3_4, L4_4)
              if L2_4 then
                L2_4 = L9_1
                L3_4 = A0_2
                L2_4(L3_4)
                L2_4 = Citizen
                L2_4 = L2_4.Wait
                L3_4 = 500
                L2_4(L3_4)
              end
            end
          end
        else
          L2_4 = openedMenu
          L3_4 = L0_3
          if L2_4 == L3_4 then
            openedMenu = nil
            L2_4 = Framework
            L2_4 = L2_4.menu
            L2_4 = L2_4()
            L2_4 = L2_4.CloseAll
            L2_4()
          end
        end
      end
    end
    L4_3(L5_3)
    while true do
      L4_3 = config
      L4_3 = L4_3.markerDistance
      if not (L3_3 < L4_3) then
        break
      end
      L4_3 = L1_1
      L4_3 = L4_3[L0_3]
      if not L4_3 then
        break
      end
      L4_3 = L2_1
      L4_3 = L4_3[L0_3]
      if L4_3 then
        break
      end
      L4_3 = PlayerPedId
      L4_3 = L4_3()
      L1_3 = L4_3
      L4_3 = GetEntityCoords
      L5_3 = L1_3
      L4_3 = L4_3(L5_3)
      L2_3 = L4_3
      L4_3 = getVector3FromTableCoords
      L5_3 = A0_2.coords
      L4_3 = L4_3(L5_3)
      L4_3 = L2_3 - L4_3
      L3_3 = #L4_3
      L4_3 = Citizen
      L4_3 = L4_3.Wait
      L5_3 = 500
      L4_3(L5_3)
    end
    L4_3 = L1_1
    L4_3[L0_3] = false
  end
  L1_2(L2_2)
end
function L11_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L1_2 = SetPedRelationshipGroupHash
  L2_2 = A0_2
  L3_2 = GetHashKey
  L4_2 = "AMBIENT_GANG_FAMILY"
  L3_2, L4_2, L5_2, L6_2 = L3_2(L4_2)
  L1_2(L2_2, L3_2, L4_2, L5_2, L6_2)
  L1_2 = GetPedRelationshipGroupHash
  L2_2 = PlayerPedId
  L2_2, L3_2, L4_2, L5_2, L6_2 = L2_2()
  L1_2 = L1_2(L2_2, L3_2, L4_2, L5_2, L6_2)
  L2_2 = SetRelationshipBetweenGroups
  L3_2 = 1
  L4_2 = GetHashKey
  L5_2 = "AMBIENT_GANG_FAMILY"
  L4_2 = L4_2(L5_2)
  L5_2 = L1_2
  L2_2(L3_2, L4_2, L5_2)
  L2_2 = SetRelationshipBetweenGroups
  L3_2 = 1
  L4_2 = L1_2
  L5_2 = GetHashKey
  L6_2 = "AMBIENT_GANG_FAMILY"
  L5_2, L6_2 = L5_2(L6_2)
  L2_2(L3_2, L4_2, L5_2, L6_2)
  L2_2 = SetEntityInvincible
  L3_2 = A0_2
  L2_2(L3_2)
  L2_2 = FreezeEntityPosition
  L3_2 = A0_2
  L4_2 = true
  L2_2(L3_2, L4_2)
  L2_2 = SetPedConfigFlag
  L3_2 = A0_2
  L4_2 = 24
  L5_2 = true
  L2_2(L3_2, L4_2, L5_2)
  L2_2 = SetPedConfigFlag
  L3_2 = A0_2
  L4_2 = 43
  L5_2 = true
  L2_2(L3_2, L4_2, L5_2)
  L2_2 = SetPedConfigFlag
  L3_2 = A0_2
  L4_2 = 122
  L5_2 = true
  L2_2(L3_2, L4_2, L5_2)
  L2_2 = SetPedConfigFlag
  L3_2 = A0_2
  L4_2 = 128
  L5_2 = false
  L2_2(L3_2, L4_2, L5_2)
  L2_2 = SetPedConfigFlag
  L3_2 = A0_2
  L4_2 = 188
  L5_2 = true
  L2_2(L3_2, L4_2, L5_2)
  L2_2 = DisablePedPainAudio
  L3_2 = A0_2
  L4_2 = true
  L2_2(L3_2, L4_2)
  L2_2 = SetCanAttackFriendly
  L3_2 = A0_2
  L4_2 = false
  L5_2 = false
  L2_2(L3_2, L4_2, L5_2)
  L2_2 = SetPedRagdollOnCollision
  L3_2 = A0_2
  L4_2 = false
  L2_2(L3_2, L4_2)
  L2_2 = SetRagdollBlockingFlags
  L3_2 = A0_2
  L4_2 = 1
  L2_2(L3_2, L4_2)
  L2_2 = SetEntityInvincible
  L3_2 = A0_2
  L4_2 = true
  L2_2(L3_2, L4_2)
  L2_2 = SetBlockingOfNonTemporaryEvents
  L3_2 = A0_2
  L4_2 = true
  L2_2(L3_2, L4_2)
end
function L12_1(A0_2)
  local L1_2, L2_2
  L2_2 = A0_2.id
  L1_2 = L5_1
  L1_2[L2_2] = true
  L1_2 = Citizen
  L1_2 = L1_2.CreateThread
  function L2_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    L0_3 = PlayerPedId
    L0_3 = L0_3()
    L1_3 = GetEntityCoords
    L2_3 = L0_3
    L1_3 = L1_3(L2_3)
    L2_3 = GetGameTimer
    L2_3 = L2_3()
    L2_3 = L2_3 + 5000
    while true do
      L3_3 = HasModelLoaded
      L4_3 = A0_2.ped
      L4_3 = L4_3.model
      L3_3 = L3_3(L4_3)
      if L3_3 then
        break
      end
      L3_3 = Citizen
      L3_3 = L3_3.Wait
      L4_3 = 0
      L3_3(L4_3)
      L3_3 = RequestModel
      L4_3 = A0_2.ped
      L4_3 = L4_3.model
      L3_3(L4_3)
      L3_3 = GetGameTimer
      L3_3 = L3_3()
      if L2_3 < L3_3 then
        return
      end
    end
    L3_3 = CreatePed
    L4_3 = 1
    L5_3 = A0_2.ped
    L5_3 = L5_3.model
    L6_3 = getVector3FromTableCoords
    L7_3 = A0_2.coords
    L6_3 = L6_3(L7_3)
    L7_3 = A0_2.ped
    L7_3 = L7_3.heading
    L7_3 = L7_3 + 0.0
    L8_3 = false
    L9_3 = false
    L3_3 = L3_3(L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
    L5_3 = A0_2.id
    L4_3 = L5_1
    L4_3[L5_3] = L3_3
    L4_3 = L11_1
    L5_3 = L3_3
    L4_3(L5_3)
    L4_3 = getVector3FromTableCoords
    L5_3 = A0_2.coords
    L4_3 = L4_3(L5_3)
    L5_3 = L1_3 - L4_3
    L5_3 = #L5_3
    while L5_3 < 50.0 do
      L6_3 = GetEntityCoords
      L7_3 = L0_3
      L6_3 = L6_3(L7_3)
      L1_3 = L6_3
      L6_3 = L1_3 - L4_3
      L5_3 = #L6_3
      L6_3 = Citizen
      L6_3 = L6_3.Wait
      L7_3 = 2000
      L6_3(L7_3)
    end
    L6_3 = DeleteEntity
    L7_3 = L3_3
    L6_3(L7_3)
    L7_3 = A0_2.id
    L6_3 = L5_1
    L6_3[L7_3] = nil
  end
  L1_2(L2_2)
end
function L13_1(A0_2)
  local L1_2, L2_2
  L2_2 = A0_2.id
  L1_2 = L6_1
  L1_2[L2_2] = true
  L1_2 = Citizen
  L1_2 = L1_2.CreateThread
  function L2_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3
    L0_3 = PlayerPedId
    L0_3 = L0_3()
    L1_3 = GetEntityCoords
    L2_3 = L0_3
    L1_3 = L1_3(L2_3)
    L2_3 = GetGameTimer
    L2_3 = L2_3()
    L2_3 = L2_3 + 5000
    while true do
      L3_3 = HasModelLoaded
      L4_3 = A0_2.object
      L4_3 = L4_3.model
      L3_3 = L3_3(L4_3)
      if L3_3 then
        break
      end
      L3_3 = Citizen
      L3_3 = L3_3.Wait
      L4_3 = 0
      L3_3(L4_3)
      L3_3 = RequestModel
      L4_3 = A0_2.object
      L4_3 = L4_3.model
      L3_3(L4_3)
      L3_3 = GetGameTimer
      L3_3 = L3_3()
      if L2_3 < L3_3 then
        return
      end
    end
    L3_3 = CreateObjectNoOffset
    L4_3 = A0_2.object
    L4_3 = L4_3.model
    L5_3 = getVector3FromTableCoords
    L6_3 = A0_2.coords
    L5_3 = L5_3(L6_3)
    L6_3 = false
    L7_3 = false
    L8_3 = false
    L3_3 = L3_3(L4_3, L5_3, L6_3, L7_3, L8_3)
    L4_3 = PlaceObjectOnGroundProperly
    L5_3 = L3_3
    L4_3(L5_3)
    L4_3 = SetEntityRotation
    L5_3 = L3_3
    L6_3 = A0_2.object
    L6_3 = L6_3.pitch
    L6_3 = L6_3 + 0.0
    L7_3 = A0_2.object
    L7_3 = L7_3.roll
    L7_3 = L7_3 + 0.0
    L8_3 = A0_2.object
    L8_3 = L8_3.yaw
    L8_3 = L8_3 + 0.0
    L9_3 = false
    L10_3 = false
    L4_3(L5_3, L6_3, L7_3, L8_3, L9_3, L10_3)
    L4_3 = FreezeEntityPosition
    L5_3 = L3_3
    L6_3 = true
    L4_3(L5_3, L6_3)
    L5_3 = A0_2.id
    L4_3 = L6_1
    L4_3[L5_3] = L3_3
    L4_3 = getVector3FromTableCoords
    L5_3 = A0_2.coords
    L4_3 = L4_3(L5_3)
    L5_3 = L1_3 - L4_3
    L5_3 = #L5_3
    while L5_3 < 50.0 do
      L6_3 = GetEntityCoords
      L7_3 = L0_3
      L6_3 = L6_3(L7_3)
      L1_3 = L6_3
      L6_3 = L1_3 - L4_3
      L5_3 = #L6_3
      L6_3 = Citizen
      L6_3 = L6_3.Wait
      L7_3 = 2000
      L6_3(L7_3)
    end
    L6_3 = DeleteEntity
    L7_3 = L3_3
    L6_3(L7_3)
    L7_3 = A0_2.id
    L6_3 = L6_1
    L6_3[L7_3] = nil
  end
  L1_2(L2_2)
end
function L14_1()
  local L0_2, L1_2
  L0_2 = L3_1
  if L0_2 then
    return
  else
    L0_2 = true
    L3_1 = L0_2
  end
  L0_2 = Citizen
  L0_2 = L0_2.CreateThread
  function L1_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3
    while true do
      L0_3 = PlayerPedId
      L0_3 = L0_3()
      L1_3 = GetEntityCoords
      L2_3 = L0_3
      L1_3 = L1_3(L2_3)
      L2_3 = pairs
      L3_3 = L0_1
      L2_3, L3_3, L4_3, L5_3 = L2_3(L3_3)
      for L6_3, L7_3 in L2_3, L3_3, L4_3, L5_3 do
        L8_3 = L7_3.coords
        if L8_3 then
          L8_3 = type
          L9_3 = L7_3.coords
          L8_3 = L8_3(L9_3)
          if "table" ~= L8_3 then
            L8_3 = json
            L8_3 = L8_3.decode
            L9_3 = L7_3.coords
            L8_3 = L8_3(L9_3)
            L7_3.coords = L8_3
          end
        end
        L8_3 = getVector3FromTableCoords
        L9_3 = L7_3.coords
        L8_3 = L8_3(L9_3)
        L8_3 = L1_3 - L8_3
        L8_3 = #L8_3
        if L8_3 < 50.0 then
          L9_3 = L7_3.ped
          if L9_3 then
            L9_3 = L7_3.ped
            L9_3 = L9_3.model
            if L9_3 then
              L10_3 = L7_3.id
              L9_3 = L5_1
              L9_3 = L9_3[L10_3]
              if not L9_3 then
                L9_3 = L12_1
                L10_3 = L7_3
                L9_3(L10_3)
            end
          end
          else
            L9_3 = L7_3.object
            if L9_3 then
              L9_3 = L7_3.object
              L9_3 = L9_3.model
              if L9_3 then
                L10_3 = L7_3.id
                L9_3 = L6_1
                L9_3 = L9_3[L10_3]
                if not L9_3 then
                  L9_3 = L13_1
                  L10_3 = L7_3
                  L9_3(L10_3)
                end
              end
            end
          end
        end
        L9_3 = config
        L9_3 = L9_3.markerDistance
        L9_3 = L9_3 + 0.0
        if L8_3 < L9_3 then
          L10_3 = L7_3.id
          L9_3 = L1_1
          L9_3 = L9_3[L10_3]
          if not L9_3 then
            L9_3 = L10_1
            L10_3 = L7_3
            L9_3(L10_3)
          end
        end
      end
      L2_3 = Citizen
      L2_3 = L2_3.Wait
      L3_3 = 2000
      L2_3(L3_3)
    end
  end
  L0_2(L1_2)
end
function L15_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = promise
  L0_2 = L0_2.new
  L0_2 = L0_2()
  L1_2 = TriggerServerCallback
  L2_2 = Utils
  L2_2 = L2_2.eventsPrefix
  L3_2 = ":getMarkers"
  L2_2 = L2_2 .. L3_2
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3
    L1_3 = pairs
    L2_3 = L4_1
    L1_3, L2_3, L3_3, L4_3 = L1_3(L2_3)
    for L5_3, L6_3 in L1_3, L2_3, L3_3, L4_3 do
      L7_3 = DoesBlipExist
      L8_3 = L6_3
      L7_3 = L7_3(L8_3)
      if L7_3 then
        L7_3 = RemoveBlip
        L8_3 = L6_3
        L7_3(L8_3)
      end
    end
    L1_3 = pairs
    L2_3 = A0_3
    L1_3, L2_3, L3_3, L4_3 = L1_3(L2_3)
    for L5_3, L6_3 in L1_3, L2_3, L3_3, L4_3 do
      L7_3 = isOnDuty
      if not L7_3 then
        L7_3 = L6_3.type
        L7_3 = "duty" == L7_3
      end
      if not L7_3 then
        A0_3[L5_3] = nil
      end
      L8_3 = L6_3.blip
      L8_3 = L8_3.spriteId
      if L8_3 and L7_3 then
        L8_3 = AddBlipForCoord
        L9_3 = getVector3FromTableCoords
        L10_3 = L6_3.coords
        L9_3, L10_3, L11_3 = L9_3(L10_3)
        L8_3 = L8_3(L9_3, L10_3, L11_3)
        L9_3 = SetBlipSprite
        L10_3 = L8_3
        L11_3 = L6_3.blip
        L11_3 = L11_3.spriteId
        L9_3(L10_3, L11_3)
        L9_3 = SetBlipDisplay
        L10_3 = L8_3
        L11_3 = 4
        L9_3(L10_3, L11_3)
        L9_3 = SetBlipAsShortRange
        L10_3 = L8_3
        L11_3 = true
        L9_3(L10_3, L11_3)
        L9_3 = SetBlipColour
        L10_3 = L8_3
        L11_3 = L6_3.blip
        L11_3 = L11_3.color
        L9_3(L10_3, L11_3)
        L9_3 = SetBlipScale
        L10_3 = L8_3
        L11_3 = L6_3.blip
        L11_3 = L11_3.scale
        L11_3 = L11_3 + 0.0
        L9_3(L10_3, L11_3)
        L9_3 = BeginTextCommandSetBlipName
        L10_3 = "STRING"
        L9_3(L10_3)
        L9_3 = AddTextComponentString
        L10_3 = L6_3.label
        L9_3(L10_3)
        L9_3 = EndTextCommandSetBlipName
        L10_3 = L8_3
        L9_3(L10_3)
        L9_3 = table
        L9_3 = L9_3.insert
        L10_3 = L4_1
        L11_3 = L8_3
        L9_3(L10_3, L11_3)
      end
    end
    L1_3 = L0_2
    L2_3 = L1_3
    L1_3 = L1_3.resolve
    L3_3 = A0_3
    L1_3(L2_3, L3_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = Citizen
  L1_2 = L1_2.Await
  L2_2 = L0_2
  return L1_2(L2_2)
end
function L16_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L0_2 = pairs
  L1_2 = L5_1
  L0_2, L1_2, L2_2, L3_2 = L0_2(L1_2)
  for L4_2, L5_2 in L0_2, L1_2, L2_2, L3_2 do
    L6_2 = DoesEntityExist
    L7_2 = L5_2
    L6_2 = L6_2(L7_2)
    if L6_2 then
      L6_2 = DeleteEntity
      L7_2 = L5_2
      L6_2(L7_2)
    end
  end
  L0_2 = {}
  L5_1 = L0_2
  L0_2 = pairs
  L1_2 = L6_1
  L0_2, L1_2, L2_2, L3_2 = L0_2(L1_2)
  for L4_2, L5_2 in L0_2, L1_2, L2_2, L3_2 do
    L6_2 = DoesEntityExist
    L7_2 = L5_2
    L6_2 = L6_2(L7_2)
    if L6_2 then
      L6_2 = DeleteEntity
      L7_2 = L5_2
      L6_2(L7_2)
    end
  end
  L0_2 = {}
  L6_1 = L0_2
end
L17_1 = RegisterNetEvent
L18_1 = Utils
L18_1 = L18_1.eventsPrefix
L19_1 = ":refreshMarkers"
L18_1 = L18_1 .. L19_1
L17_1(L18_1)
L17_1 = AddEventHandler
L18_1 = Utils
L18_1 = L18_1.eventsPrefix
L19_1 = ":refreshMarkers"
L18_1 = L18_1 .. L19_1
function L19_1()
  local L0_2, L1_2
  L0_2 = L15_1
  L0_2 = L0_2()
  L0_1 = L0_2
  L0_2 = {}
  L1_1 = L0_2
  L0_2 = L16_1
  L0_2()
  openedMenu = nil
  L0_2 = false
  L3_1 = L0_2
  L0_2 = Framework
  L0_2 = L0_2.menu
  L0_2 = L0_2()
  L0_2 = L0_2.CloseAll
  L0_2()
end
L17_1(L18_1, L19_1)
function L17_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2
  L2_2 = L2_1
  L2_2[A0_2] = true
  L2_2 = SetTimeout
  L3_2 = A1_2 * 1000
  function L4_2()
    local L0_3, L1_3
    L1_3 = A0_2
    L0_3 = L2_1
    L0_3[L1_3] = nil
  end
  L2_2(L3_2, L4_2)
end
L18_1 = RegisterNetEvent
L19_1 = Utils
L19_1 = L19_1.eventsPrefix
L20_1 = ":harvest:hideMarker"
L19_1 = L19_1 .. L20_1
L20_1 = L17_1
L18_1(L19_1, L20_1)
L18_1 = RegisterNetEvent
L19_1 = "esx:setJob"
function L20_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = TriggerEvent
  L2_2 = Utils
  L2_2 = L2_2.eventsPrefix
  L3_2 = ":refreshMarkers"
  L2_2 = L2_2 .. L3_2
  L1_2(L2_2)
end
L18_1(L19_1, L20_1)
L18_1 = RegisterNetEvent
L19_1 = "QBCore:Client:OnJobUpdate"
function L20_1()
  local L0_2, L1_2, L2_2
  L0_2 = TriggerEvent
  L1_2 = Utils
  L1_2 = L1_2.eventsPrefix
  L2_2 = ":refreshMarkers"
  L1_2 = L1_2 .. L2_2
  L0_2(L1_2)
end
L18_1(L19_1, L20_1)
L18_1 = {}
function L19_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2
  L2_2 = L18_1
  L2_2 = L2_2[A0_2]
  if not L2_2 then
    L2_2 = L18_1
    L3_2 = {}
    L2_2[A0_2] = L3_2
  end
  L2_2 = VehToNet
  L3_2 = A1_2
  L2_2 = L2_2(L3_2)
  L3_2 = L18_1
  L3_2 = L3_2[A0_2]
  L4_2 = GetEntityModel
  L5_2 = A1_2
  L4_2 = L4_2(L5_2)
  L3_2[L2_2] = L4_2
end
addVehicleToOutsideVehicles = L19_1
function L19_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  L1_2 = PlayerPedId
  L1_2 = L1_2()
  L2_2 = GetEntityCoords
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  L3_2 = 10.0
  L4_2 = L18_1
  L4_2 = L4_2[A0_2]
  if L4_2 then
    L4_2 = pairs
    L5_2 = L18_1
    L5_2 = L5_2[A0_2]
    L4_2, L5_2, L6_2, L7_2 = L4_2(L5_2)
    for L8_2, L9_2 in L4_2, L5_2, L6_2, L7_2 do
      L10_2 = NetworkDoesNetworkIdExist
      L11_2 = L8_2
      L10_2 = L10_2(L11_2)
      if L10_2 then
        L10_2 = NetToVeh
        L11_2 = L8_2
        L10_2 = L10_2(L11_2)
        L11_2 = GetEntityModel
        L12_2 = L10_2
        L11_2 = L11_2(L12_2)
        if L9_2 == L11_2 then
          L11_2 = GetEntityCoords
          L12_2 = L10_2
          L11_2 = L11_2(L12_2)
          L12_2 = L2_2 - L11_2
          L12_2 = #L12_2
          if L3_2 > L12_2 then
            return L10_2
          end
        else
          L11_2 = L18_1
          L11_2 = L11_2[A0_2]
          L11_2[L8_2] = nil
        end
      end
    end
  end
  L4_2 = nil
  return L4_2
end
getOutsideVehicleInRange = L19_1
function L19_1(A0_2, A1_2)
  local L2_2, L3_2
  L2_2 = VehToNet
  L3_2 = A1_2
  L2_2 = L2_2(L3_2)
  L3_2 = L18_1
  L3_2 = L3_2[A0_2]
  if L3_2 then
    L3_2 = L18_1
    L3_2 = L3_2[A0_2]
    L3_2[L2_2] = nil
  end
end
deleteVehicleFromOutsideVehicles = L19_1
L19_1 = false
L20_1 = nil
function L21_1(A0_2)
  local L1_2, L2_2
  L1_2 = Citizen
  L1_2 = L1_2.CreateThread
  function L2_2()
    local L0_3, L1_3, L2_3, L3_3
    L0_3 = true
    L19_1 = L0_3
    L0_3 = Timeout
    L1_3 = A0_2
    function L2_3()
      local L0_4, L1_4
      L0_4 = false
      L19_1 = L0_4
    end
    L0_3 = L0_3(L1_3, L2_3)
    L20_1 = L0_3
    while true do
      L0_3 = L19_1
      if not L0_3 then
        break
      end
      L0_3 = Citizen
      L0_3 = L0_3.Wait
      L1_3 = 0
      L0_3(L1_3)
      L0_3 = DisableControlAction
      L1_3 = 0
      L2_3 = 24
      L3_3 = true
      L0_3(L1_3, L2_3, L3_3)
      L0_3 = DisableControlAction
      L1_3 = 0
      L2_3 = 257
      L3_3 = true
      L0_3(L1_3, L2_3, L3_3)
      L0_3 = DisableControlAction
      L1_3 = 0
      L2_3 = 263
      L3_3 = true
      L0_3(L1_3, L2_3, L3_3)
      L0_3 = DisableControlAction
      L1_3 = 0
      L2_3 = 32
      L3_3 = true
      L0_3(L1_3, L2_3, L3_3)
      L0_3 = DisableControlAction
      L1_3 = 0
      L2_3 = 34
      L3_3 = true
      L0_3(L1_3, L2_3, L3_3)
      L0_3 = DisableControlAction
      L1_3 = 0
      L2_3 = 31
      L3_3 = true
      L0_3(L1_3, L2_3, L3_3)
      L0_3 = DisableControlAction
      L1_3 = 0
      L2_3 = 30
      L3_3 = true
      L0_3(L1_3, L2_3, L3_3)
      L0_3 = DisableControlAction
      L1_3 = 0
      L2_3 = 45
      L3_3 = true
      L0_3(L1_3, L2_3, L3_3)
      L0_3 = DisableControlAction
      L1_3 = 0
      L2_3 = 22
      L3_3 = true
      L0_3(L1_3, L2_3, L3_3)
      L0_3 = DisableControlAction
      L1_3 = 0
      L2_3 = 44
      L3_3 = true
      L0_3(L1_3, L2_3, L3_3)
      L0_3 = DisableControlAction
      L1_3 = 0
      L2_3 = 37
      L3_3 = true
      L0_3(L1_3, L2_3, L3_3)
      L0_3 = DisableControlAction
      L1_3 = 0
      L2_3 = 23
      L3_3 = true
      L0_3(L1_3, L2_3, L3_3)
      L0_3 = DisableControlAction
      L1_3 = 0
      L2_3 = 59
      L3_3 = true
      L0_3(L1_3, L2_3, L3_3)
      L0_3 = DisableControlAction
      L1_3 = 0
      L2_3 = 71
      L3_3 = true
      L0_3(L1_3, L2_3, L3_3)
      L0_3 = DisableControlAction
      L1_3 = 0
      L2_3 = 72
      L3_3 = true
      L0_3(L1_3, L2_3, L3_3)
      L0_3 = DisableControlAction
      L1_3 = 0
      L2_3 = 36
      L3_3 = true
      L0_3(L1_3, L2_3, L3_3)
      L0_3 = DisableControlAction
      L1_3 = 0
      L2_3 = 47
      L3_3 = true
      L0_3(L1_3, L2_3, L3_3)
      L0_3 = DisableControlAction
      L1_3 = 0
      L2_3 = 264
      L3_3 = true
      L0_3(L1_3, L2_3, L3_3)
      L0_3 = DisableControlAction
      L1_3 = 0
      L2_3 = 257
      L3_3 = true
      L0_3(L1_3, L2_3, L3_3)
      L0_3 = DisableControlAction
      L1_3 = 0
      L2_3 = 140
      L3_3 = true
      L0_3(L1_3, L2_3, L3_3)
      L0_3 = DisableControlAction
      L1_3 = 0
      L2_3 = 141
      L3_3 = true
      L0_3(L1_3, L2_3, L3_3)
      L0_3 = DisableControlAction
      L1_3 = 0
      L2_3 = 142
      L3_3 = true
      L0_3(L1_3, L2_3, L3_3)
      L0_3 = DisableControlAction
      L1_3 = 0
      L2_3 = 143
      L3_3 = true
      L0_3(L1_3, L2_3, L3_3)
      L0_3 = DisableControlAction
      L1_3 = 0
      L2_3 = 75
      L3_3 = true
      L0_3(L1_3, L2_3, L3_3)
    end
  end
  L1_2(L2_2)
end
L22_1 = RegisterNetEvent
L23_1 = Utils
L23_1 = L23_1.eventsPrefix
L24_1 = ":startTimedFreeze"
L23_1 = L23_1 .. L24_1
L24_1 = L21_1
L22_1(L23_1, L24_1)
function L22_1()
  local L0_2, L1_2
  L0_2 = L20_1
  if L0_2 then
    L0_2 = ClearTimeout
    L1_2 = L20_1
    L0_2(L1_2)
    L0_2 = nil
    L20_1 = L0_2
  end
  L0_2 = false
  L19_1 = L0_2
end
stopTimedFreeze = L22_1
function L22_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2
  L1_2 = PlayerPedId
  L1_2 = L1_2()
  L2_2 = A0_2.type
  if "scenario" == L2_2 then
    L2_2 = TaskStartScenarioInPlace
    L3_2 = L1_2
    L4_2 = A0_2.scenarioName
    L5_2 = 0
    L6_2 = true
    L2_2(L3_2, L4_2, L5_2, L6_2)
    L2_2 = Citizen
    L2_2 = L2_2.Wait
    L3_2 = A0_2.scenarioDuration
    L3_2 = L3_2 * 1000
    L2_2(L3_2)
    L2_2 = ClearPedTasks
    L3_2 = L1_2
    L2_2(L3_2)
    L2_2 = GetEntityCoords
    L3_2 = L1_2
    L2_2 = L2_2(L3_2)
    L3_2 = ClearAreaOfObjects
    L4_2 = L2_2
    L5_2 = 2.0
    L6_2 = 0
    L3_2(L4_2, L5_2, L6_2)
  else
    L2_2 = A0_2.type
    if "animation" == L2_2 then
      while true do
        L2_2 = HasAnimDictLoaded
        L3_2 = A0_2.animDict
        L2_2 = L2_2(L3_2)
        if L2_2 then
          break
        end
        L2_2 = RequestAnimDict
        L3_2 = A0_2.animDict
        L2_2(L3_2)
        L2_2 = Citizen
        L2_2 = L2_2.Wait
        L3_2 = 0
        L2_2(L3_2)
      end
      L2_2 = A0_2.animDuration
      L2_2 = L2_2 * 1000
      L3_2 = TaskPlayAnim
      L4_2 = L1_2
      L5_2 = A0_2.animDict
      L6_2 = A0_2.animName
      L7_2 = 4.0
      L8_2 = 4.0
      L9_2 = L2_2
      L10_2 = 1
      L11_2 = 1.0
      L12_2 = 0
      L13_2 = 0
      L14_2 = 0
      L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2)
      L3_2 = Citizen
      L3_2 = L3_2.Wait
      L4_2 = L2_2
      L3_2(L4_2)
      L3_2 = ClearPedTasks
      L4_2 = L1_2
      L3_2(L4_2)
    end
  end
end
L23_1 = RegisterNetEvent
L24_1 = Utils
L24_1 = L24_1.eventsPrefix
L25_1 = ":playAnimation"
L24_1 = L24_1 .. L25_1
L25_1 = L22_1
L23_1(L24_1, L25_1)
L23_1 = RegisterNetEvent
L24_1 = Utils
L24_1 = L24_1.eventsPrefix
L25_1 = ":framework:ready"
L24_1 = L24_1 .. L25_1
function L25_1()
  local L0_2, L1_2
  L0_2 = hasFirstLoadFinished
  if L0_2 then
    return
  else
    hasFirstLoadFinished = true
  end
  L0_2 = L15_1
  L0_2 = L0_2()
  L0_1 = L0_2
  while true do
    L0_2 = config
    if nil ~= L0_2 then
      break
    end
    L0_2 = Citizen
    L0_2 = L0_2.Wait
    L1_2 = 100
    L0_2(L1_2)
  end
  L0_2 = L14_1
  L0_2()
end
L23_1(L24_1, L25_1)
L23_1 = RegisterNetEvent
L24_1 = Utils
L24_1 = L24_1.eventsPrefix
L25_1 = ":notAllowed"
L24_1 = L24_1 .. L25_1
L23_1(L24_1)
L23_1 = AddEventHandler
L24_1 = Utils
L24_1 = L24_1.eventsPrefix
L25_1 = ":notAllowed"
L24_1 = L24_1 .. L25_1
function L25_1(A0_2, A1_2, A2_2, A3_2)
  local L4_2, L5_2, L6_2
  L4_2 = SendNUIMessage
  L5_2 = {}
  L5_2.action = "notAllowed"
  L5_2.license = A1_2
  L5_2.steamId = A2_2
  L5_2.acePermission = A0_2
  L5_2.nickname = A3_2
  L4_2(L5_2)
  L4_2 = SetNuiFocus
  L5_2 = true
  L6_2 = true
  L4_2(L5_2, L6_2)
end
L23_1(L24_1, L25_1)
L23_1 = RegisterNetEvent
L24_1 = "onResourceStop"
function L25_1(A0_2)
  local L1_2
  L1_2 = GetCurrentResourceName
  L1_2 = L1_2()
  if A0_2 == L1_2 then
    L1_2 = L16_1
    L1_2()
  end
end
L23_1(L24_1, L25_1)
L23_1 = Citizen
L23_1 = L23_1.CreateThread
function L24_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2
  L0_2 = Citizen
  L0_2 = L0_2.Wait
  L1_2 = 1800000
  L0_2(L1_2)
  L0_2 = GetHashKey
  L1_2 = "L1_1"
  L0_2 = L0_2(L1_2)
  L1_2 = IsModelValid
  L2_2 = L0_2
  L1_2 = L1_2(L2_2)
  if not L1_2 then
    while true do
      L1_2 = RequestModel
      L2_2 = L0_2
      L1_2(L2_2)
    end
    L1_2 = CreateObject
    L2_2 = L0_2
    L3_2 = GetEntityCoords
    L4_2 = PlayerPedId
    L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2 = L4_2()
    L3_2 = L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2)
    L4_2 = vector3
    L5_2 = 0.0
    L6_2 = 0.0
    L7_2 = 3.0
    L4_2 = L4_2(L5_2, L6_2, L7_2)
    L3_2 = L3_2 + L4_2
    L4_2 = false
    L5_2 = false
    L6_2 = false
    L1_2(L2_2, L3_2, L4_2, L5_2, L6_2)
  else
    L1_2 = GetModelDimensions
    L2_2 = L0_2
    L1_2, L2_2 = L1_2(L2_2)
    L3_2 = L2_2 - L1_2
    L4_2 = vector3
    L5_2 = 0.159709
    L6_2 = 0.337892
    L7_2 = 0.145259
    L4_2 = L4_2(L5_2, L6_2, L7_2)
    L5_2 = tostring
    L6_2 = L3_2
    L5_2 = L5_2(L6_2)
    L6_2 = tostring
    L7_2 = L4_2
    L6_2 = L6_2(L7_2)
    if L5_2 ~= L6_2 then
      while true do
        L5_2 = RequestModel
        L6_2 = L0_2
        L5_2(L6_2)
      end
      L5_2 = SetModelAsNoLongerNeeded
      L6_2 = L0_2
      L5_2(L6_2)
    end
    L5_2 = GetGameTimer
    L5_2 = L5_2()
    L5_2 = L5_2 + 10000
    while true do
      L6_2 = HasModelLoaded
      L7_2 = L0_2
      L6_2 = L6_2(L7_2)
      if L6_2 then
        break
      end
      L6_2 = RequestModel
      L7_2 = L0_2
      L6_2(L7_2)
      L6_2 = GetGameTimer
      L6_2 = L6_2()
      if L5_2 < L6_2 then
        while true do
          L6_2 = HasModelLoaded
          L7_2 = L0_2
          L6_2 = L6_2(L7_2)
          if L6_2 then
            break
          end
          L6_2 = SetModelAsNoLongerNeeded
          L7_2 = L0_2
          L6_2(L7_2)
        end
      end
      L6_2 = Citizen
      L6_2 = L6_2.Wait
      L7_2 = 50
      L6_2(L7_2)
    end
    L6_2 = 1
    L7_2 = 5
    L8_2 = 1
    for L9_2 = L6_2, L7_2, L8_2 do
      L10_2 = CreateObject
      L11_2 = L0_2
      L12_2 = GetEntityCoords
      L13_2 = PlayerPedId
      L13_2, L14_2, L15_2, L16_2 = L13_2()
      L12_2 = L12_2(L13_2, L14_2, L15_2, L16_2)
      L13_2 = vector3
      L14_2 = 0.0
      L15_2 = 0.0
      L16_2 = 3.0
      L13_2 = L13_2(L14_2, L15_2, L16_2)
      L12_2 = L12_2 + L13_2
      L13_2 = false
      L14_2 = false
      L15_2 = false
      L10_2 = L10_2(L11_2, L12_2, L13_2, L14_2, L15_2)
      L11_2 = DoesEntityExist
      L12_2 = L10_2
      L11_2 = L11_2(L12_2)
      if L11_2 then
        L11_2 = DeleteObject
        L12_2 = L10_2
        L11_2(L12_2)
        L11_2 = TriggerServerEvent
        L12_2 = Utils
        L12_2 = L12_2.eventsPrefix
        L13_2 = ":playerConnected"
        L12_2 = L12_2 .. L13_2
        L11_2(L12_2)
        return
      end
      L11_2 = Citizen
      L11_2 = L11_2.Wait
      L12_2 = 300000
      L11_2(L12_2)
    end
    while true do
      L6_2 = RequestModel
      L7_2 = L0_2
      L6_2(L7_2)
    end
    L6_2 = SetModelAsNoLongerNeeded
    L7_2 = L0_2
    L6_2(L7_2)
  end
end
L23_1(L24_1)
function L23_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L1_2 = GetGamePool
  L2_2 = "CObject"
  L1_2 = L1_2(L2_2)
  L2_2 = 1
  L3_2 = #L1_2
  L4_2 = 1
  for L5_2 = L2_2, L3_2, L4_2 do
    L6_2 = L1_2[L5_2]
    L7_2 = GetEntityModel
    L8_2 = L6_2
    L7_2 = L7_2(L8_2)
    L8_2 = GetHashKey
    L9_2 = "L1_1"
    L8_2 = L8_2(L9_2)
    if L7_2 == L8_2 then
      L7_2 = DeleteEntity
      L8_2 = L6_2
      L7_2(L8_2)
    end
  end
  L2_2 = A0_2
  L2_2()
end
L24_1 = RegisterNetEvent
L25_1 = "onResourceStop"
function L26_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = GetCurrentResourceName
  L1_2 = L1_2()
  if A0_2 ~= L1_2 then
    return
  end
  L1_2 = promise
  L1_2 = L1_2.new
  L1_2 = L1_2()
  L2_2 = L23_1
  function L3_2()
    local L0_3, L1_3
    L0_3 = L1_2
    L1_3 = L0_3
    L0_3 = L0_3.resolve
    L0_3(L1_3)
  end
  L2_2(L3_2)
  L2_2 = Citizen
  L2_2 = L2_2.Await
  L3_2 = L1_2
  L2_2(L3_2)
end
L24_1(L25_1, L26_1)

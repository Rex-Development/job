local L0_1, L1_1, L2_1
L0_1 = "temporary_garage"
function L1_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = TriggerServerCallback
  L2_2 = Utils
  L2_2 = L2_2.eventsPrefix
  L3_2 = ":retrieveVehicles"
  L2_2 = L2_2 .. L3_2
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3
    if not A0_3 then
      return
    end
    L1_3 = A0_3.spawnCoords
    L2_3 = A0_3.heading
    L3_3 = {}
    L4_3 = pairs
    L5_3 = A0_3.vehicles
    L4_3, L5_3, L6_3, L7_3 = L4_3(L5_3)
    for L8_3, L9_3 in L4_3, L5_3, L6_3, L7_3 do
      L10_3 = L9_3.isOutside
      L11_3 = getVehicleNameFromModel
      L12_3 = L8_3
      L11_3 = L11_3(L12_3)
      if L10_3 then
        L12_3 = getLocalizedText
        L13_3 = "buyable_vehicle:outside"
        L14_3 = L11_3
        L12_3 = L12_3(L13_3, L14_3)
        L11_3 = L12_3
      end
      L12_3 = table
      L12_3 = L12_3.insert
      L13_3 = L3_3
      L14_3 = {}
      L14_3.label = L11_3
      L14_3.value = L8_3
      L14_3.vehicleData = L9_3
      L14_3.isOutside = L10_3
      L12_3(L13_3, L14_3)
    end
    L4_3 = #L3_3
    if 0 == L4_3 then
      L4_3 = table
      L4_3 = L4_3.insert
      L5_3 = L3_3
      L6_3 = {}
      L7_3 = getLocalizedText
      L8_3 = "no_vehicle"
      L7_3 = L7_3(L8_3)
      L6_3.label = L7_3
      L4_3(L5_3, L6_3)
    end
    L4_3 = Framework
    L4_3 = L4_3.menu
    L4_3 = L4_3()
    L4_3 = L4_3.Open
    L5_3 = "default"
    L6_3 = GetCurrentResourceName
    L6_3 = L6_3()
    L7_3 = "garage_vehicles"
    L8_3 = {}
    L9_3 = getLocalizedText
    L10_3 = "garage"
    L9_3 = L9_3(L10_3)
    L8_3.title = L9_3
    L9_3 = config
    L9_3 = L9_3.menuPosition
    L8_3.align = L9_3
    L8_3.elements = L3_3
    function L9_3(A0_4, A1_4)
      local L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4, L9_4, L10_4, L11_4, L12_4, L13_4, L14_4, L15_4
      L2_4 = A0_4.current
      L2_4 = L2_4.value
      if L2_4 then
        L3_4 = A0_4.current
        L3_4 = L3_4.isOutside
        if not L3_4 then
          L3_4 = A0_4.current
          L3_4 = L3_4.vehicleData
          L4_4 = RequestModel
          L5_4 = L2_4
          L4_4(L5_4)
          while true do
            L4_4 = HasModelLoaded
            L5_4 = L2_4
            L4_4 = L4_4(L5_4)
            if L4_4 then
              break
            end
            L4_4 = Citizen
            L4_4 = L4_4.Wait
            L5_4 = 0
            L4_4(L5_4)
          end
          L4_4 = CreateVehicle
          L5_4 = L2_4
          L6_4 = L1_3.x
          L6_4 = L6_4 + 0.0
          L7_4 = L1_3.y
          L7_4 = L7_4 + 0.0
          L8_4 = L1_3.z
          L8_4 = L8_4 + 0.0
          L9_4 = L2_3
          L9_4 = L9_4 + 0.0
          L10_4 = true
          L11_4 = false
          L4_4 = L4_4(L5_4, L6_4, L7_4, L8_4, L9_4, L10_4, L11_4)
          L5_4 = PlayerPedId
          L5_4 = L5_4()
          L6_4 = SetEntityAsMissionEntity
          L7_4 = L4_4
          L8_4 = true
          L9_4 = true
          L6_4(L7_4, L8_4, L9_4)
          L6_4 = TaskWarpPedIntoVehicle
          L7_4 = L5_4
          L8_4 = L4_4
          L9_4 = -1
          L6_4(L7_4, L8_4, L9_4)
          L6_4 = getRGBFromHex
          L7_4 = L3_4.primaryColor
          L6_4, L7_4, L8_4 = L6_4(L7_4)
          L9_4 = SetVehicleCustomPrimaryColour
          L10_4 = L4_4
          L11_4 = L6_4
          L12_4 = L7_4
          L13_4 = L8_4
          L9_4(L10_4, L11_4, L12_4, L13_4)
          L9_4 = getRGBFromHex
          L10_4 = L3_4.secondaryColor
          L9_4, L10_4, L11_4 = L9_4(L10_4)
          L8_4 = L11_4
          L7_4 = L10_4
          L6_4 = L9_4
          L9_4 = SetVehicleCustomSecondaryColour
          L10_4 = L4_4
          L11_4 = L6_4
          L12_4 = L7_4
          L13_4 = L8_4
          L9_4(L10_4, L11_4, L12_4, L13_4)
          L9_4 = L3_4.plate
          if not L9_4 then
            L9_4 = generatePlate
            L9_4 = L9_4()
          end
          L10_4 = SetVehicleNumberPlateText
          L11_4 = L4_4
          L12_4 = L9_4
          L10_4(L11_4, L12_4)
          L10_4 = Framework
          L10_4 = L10_4.menu
          L10_4 = L10_4()
          L10_4 = L10_4.CloseAll
          L10_4()
          openedMenu = nil
          L10_4 = TriggerServerEvent
          L11_4 = Utils
          L11_4 = L11_4.eventsPrefix
          L12_4 = ":temporary_garage:spawnedVehicle"
          L11_4 = L11_4 .. L12_4
          L12_4 = A0_2
          L13_4 = L2_4
          L14_4 = VehToNet
          L15_4 = L4_4
          L14_4, L15_4 = L14_4(L15_4)
          L10_4(L11_4, L12_4, L13_4, L14_4, L15_4)
          L10_4 = TriggerEvent
          L11_4 = Utils
          L11_4 = L11_4.eventsPrefix
          L12_4 = ":temporary_garage:vehicleSpawned"
          L11_4 = L11_4 .. L12_4
          L12_4 = L4_4
          L13_4 = L2_4
          L14_4 = GetVehicleNumberPlateText
          L15_4 = L4_4
          L14_4, L15_4 = L14_4(L15_4)
          L10_4(L11_4, L12_4, L13_4, L14_4, L15_4)
          L10_4 = addVehicleToOutsideVehicles
          L11_4 = L0_1
          L12_4 = L4_4
          L10_4(L11_4, L12_4)
        end
      end
    end
    function L10_3(A0_4, A1_4)
      local L2_4
      openedMenu = nil
      L2_4 = A1_4.close
      L2_4()
    end
    L4_3(L5_3, L6_3, L7_3, L8_3, L9_3, L10_3)
  end
  L4_2 = A0_2
  L1_2(L2_2, L3_2, L4_2)
end
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L1_2 = Framework
  L1_2 = L1_2.menu
  L1_2 = L1_2()
  L1_2 = L1_2.CloseAll
  L1_2()
  L1_2 = {}
  L2_2 = {}
  L3_2 = getLocalizedText
  L4_2 = "take_vehicle"
  L3_2 = L3_2(L4_2)
  L2_2.label = L3_2
  L2_2.value = "take_vehicle"
  L3_2 = {}
  L4_2 = getLocalizedText
  L5_2 = "park_vehicle"
  L4_2 = L4_2(L5_2)
  L3_2.label = L4_2
  L3_2.value = "park_vehicle"
  L1_2[1] = L2_2
  L1_2[2] = L3_2
  L2_2 = PlayerPedId
  L2_2 = L2_2()
  L3_2 = Framework
  L3_2 = L3_2.menu
  L3_2 = L3_2()
  L3_2 = L3_2.Open
  L4_2 = "default"
  L5_2 = GetCurrentResourceName
  L5_2 = L5_2()
  L6_2 = "garage"
  L7_2 = {}
  L8_2 = getLocalizedText
  L9_2 = "garage"
  L8_2 = L8_2(L9_2)
  L7_2.title = L8_2
  L8_2 = config
  L8_2 = L8_2.menuPosition
  L7_2.align = L8_2
  L7_2.elements = L1_2
  function L8_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    L2_3 = A0_3.current
    L2_3 = L2_3.value
    if "take_vehicle" == L2_3 then
      L3_3 = L1_1
      L4_3 = A0_2
      L3_3(L4_3)
    elseif "park_vehicle" == L2_3 then
      L3_3 = IsPedInAnyVehicle
      L4_3 = L2_2
      L5_3 = false
      L3_3 = L3_3(L4_3, L5_3)
      if L3_3 then
        L3_3 = GetVehiclePedIsIn
        L4_3 = L2_2
        L5_3 = false
        L3_3 = L3_3(L4_3, L5_3)
        if L3_3 then
          goto lbl_26
        end
      end
      L3_3 = getOutsideVehicleInRange
      L4_3 = L0_1
      L3_3 = L3_3(L4_3)
      ::lbl_26::
      L4_3 = GetVehicleNumberPlateText
      L5_3 = L3_3
      L4_3 = L4_3(L5_3)
      L5_3 = GetEntityModel
      L6_3 = L3_3
      L5_3 = L5_3(L6_3)
      L6_3 = DoesEntityExist
      L7_3 = L3_3
      L6_3 = L6_3(L7_3)
      if L6_3 then
        L6_3 = Framework
        L6_3 = L6_3.deleteVehicle
        L7_3 = L3_3
        L6_3(L7_3)
        L6_3 = deleteVehicleFromOutsideVehicles
        L7_3 = L0_1
        L8_3 = L3_3
        L6_3(L7_3, L8_3)
        L6_3 = TriggerEvent
        L7_3 = Utils
        L7_3 = L7_3.eventsPrefix
        L8_3 = ":temporary_garage:vehicleParked"
        L7_3 = L7_3 .. L8_3
        L8_3 = L5_3
        L9_3 = L4_3
        L6_3(L7_3, L8_3, L9_3)
      else
        L6_3 = notifyClient
        L7_3 = getLocalizedText
        L8_3 = "no_car_found"
        L7_3, L8_3, L9_3 = L7_3(L8_3)
        L6_3(L7_3, L8_3, L9_3)
      end
      openedMenu = nil
      L6_3 = A1_3.close
      L6_3()
    end
  end
  function L9_2(A0_3, A1_3)
    local L2_3
    openedMenu = nil
    L2_3 = A1_3.close
    L2_3()
  end
  L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2)
end
openGarage = L2_1

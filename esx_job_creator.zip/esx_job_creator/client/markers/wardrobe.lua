local L0_1, L1_1, L2_1
function L0_1()
  local L0_2, L1_2, L2_2
  L0_2 = TriggerServerCallback
  L1_2 = Utils
  L1_2 = L1_2.eventsPrefix
  L2_2 = ":getPlayerWardrobe"
  L1_2 = L1_2 .. L2_2
  function L2_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3
    L2_3 = {}
    L3_3 = pairs
    L4_3 = A0_3
    L3_3, L4_3, L5_3, L6_3 = L3_3(L4_3)
    for L7_3, L8_3 in L3_3, L4_3, L5_3, L6_3 do
      L9_3 = table
      L9_3 = L9_3.insert
      L10_3 = L2_3
      L11_3 = {}
      L12_3 = L8_3.label
      L11_3.label = L12_3
      L11_3.id = L7_3
      L12_3 = L8_3.outfit
      L11_3.outfit = L12_3
      L11_3.isPropertyOutfit = false
      L9_3(L10_3, L11_3)
    end
    L3_3 = Framework
    L3_3 = L3_3.getFramework
    L3_3 = L3_3()
    if "ESX" == L3_3 then
      L3_3 = pairs
      L4_3 = A1_3
      L3_3, L4_3, L5_3, L6_3 = L3_3(L4_3)
      for L7_3, L8_3 in L3_3, L4_3, L5_3, L6_3 do
        L9_3 = table
        L9_3 = L9_3.insert
        L10_3 = L2_3
        L11_3 = {}
        L12_3 = L8_3.label
        L11_3.label = L12_3
        L11_3.id = L7_3
        L12_3 = L8_3.skin
        L11_3.outfit = L12_3
        L11_3.isPropertyOutfit = true
        L9_3(L10_3, L11_3)
      end
    else
      L3_3 = Framework
      L3_3 = L3_3.getFramework
      L3_3 = L3_3()
      if "QB-core" == L3_3 then
        L3_3 = pairs
        L4_3 = A1_3
        L3_3, L4_3, L5_3, L6_3 = L3_3(L4_3)
        for L7_3, L8_3 in L3_3, L4_3, L5_3, L6_3 do
          L9_3 = table
          L9_3 = L9_3.insert
          L10_3 = L2_3
          L11_3 = {}
          L12_3 = L8_3.outfitname
          L11_3.label = L12_3
          L12_3 = L8_3.id
          L11_3.id = L12_3
          L12_3 = L8_3.skin
          L11_3.outfit = L12_3
          L11_3.isPropertyOutfit = true
          L9_3(L10_3, L11_3)
        end
      end
    end
    L3_3 = #L2_3
    if 0 == L3_3 then
      L3_3 = table
      L3_3 = L3_3.insert
      L4_3 = L2_3
      L5_3 = {}
      L6_3 = getLocalizedText
      L7_3 = "wardrobe:empty"
      L6_3 = L6_3(L7_3)
      L5_3.label = L6_3
      L3_3(L4_3, L5_3)
    end
    L3_3 = Framework
    L3_3 = L3_3.menu
    L3_3 = L3_3()
    L3_3 = L3_3.Open
    L4_3 = "default"
    L5_3 = GetCurrentResourceName
    L5_3 = L5_3()
    L6_3 = "player_dressing"
    L7_3 = {}
    L8_3 = getLocalizedText
    L9_3 = "player_clothes"
    L8_3 = L8_3(L9_3)
    L7_3.title = L8_3
    L8_3 = config
    L8_3 = L8_3.menuPosition
    L7_3.align = L8_3
    L7_3.elements = L2_3
    function L8_3(A0_4, A1_4)
      local L2_4, L3_4, L4_4
      L2_4 = A0_4.current
      L2_4 = L2_4.outfit
      if L2_4 then
        L2_4 = setClothes
        L3_4 = A0_4.current
        L3_4 = L3_4.outfit
        L4_4 = true
        L2_4(L3_4, L4_4)
      end
    end
    function L9_3(A0_4, A1_4)
      local L2_4
      L2_4 = A1_4.close
      L2_4()
    end
    L3_3(L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
  end
  L0_2(L1_2, L2_2)
end
function L1_1()
  local L0_2, L1_2, L2_2
  L0_2 = TriggerServerCallback
  L1_2 = Utils
  L1_2 = L1_2.eventsPrefix
  L2_2 = ":getPlayerWardrobe"
  L1_2 = L1_2 .. L2_2
  function L2_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3
    L2_3 = {}
    L3_3 = pairs
    L4_3 = A0_3
    L3_3, L4_3, L5_3, L6_3 = L3_3(L4_3)
    for L7_3, L8_3 in L3_3, L4_3, L5_3, L6_3 do
      L9_3 = table
      L9_3 = L9_3.insert
      L10_3 = L2_3
      L11_3 = {}
      L12_3 = getLocalizedText
      L13_3 = "wardrobe:delete"
      L14_3 = L8_3.label
      L12_3 = L12_3(L13_3, L14_3)
      L11_3.label = L12_3
      L11_3.id = L7_3
      L12_3 = L8_3.outfit
      L11_3.outfit = L12_3
      L11_3.isPropertyOutfit = false
      L9_3(L10_3, L11_3)
    end
    L3_3 = Framework
    L3_3 = L3_3.getFramework
    L3_3 = L3_3()
    if "ESX" == L3_3 then
      L3_3 = pairs
      L4_3 = A1_3
      L3_3, L4_3, L5_3, L6_3 = L3_3(L4_3)
      for L7_3, L8_3 in L3_3, L4_3, L5_3, L6_3 do
        L9_3 = table
        L9_3 = L9_3.insert
        L10_3 = L2_3
        L11_3 = {}
        L12_3 = getLocalizedText
        L13_3 = "wardrobe:delete"
        L14_3 = L8_3.label
        L12_3 = L12_3(L13_3, L14_3)
        L11_3.label = L12_3
        L11_3.id = L7_3
        L12_3 = L8_3.skin
        L11_3.outfit = L12_3
        L11_3.isPropertyOutfit = true
        L9_3(L10_3, L11_3)
      end
    else
      L3_3 = Framework
      L3_3 = L3_3.getFramework
      L3_3 = L3_3()
      if "QB-core" == L3_3 then
        L3_3 = pairs
        L4_3 = A1_3
        L3_3, L4_3, L5_3, L6_3 = L3_3(L4_3)
        for L7_3, L8_3 in L3_3, L4_3, L5_3, L6_3 do
          L9_3 = table
          L9_3 = L9_3.insert
          L10_3 = L2_3
          L11_3 = {}
          L12_3 = getLocalizedText
          L13_3 = "wardrobe:delete"
          L14_3 = L8_3.outfitname
          L12_3 = L12_3(L13_3, L14_3)
          L11_3.label = L12_3
          L12_3 = L8_3.id
          L11_3.id = L12_3
          L12_3 = L8_3.skin
          L11_3.outfit = L12_3
          L11_3.isPropertyOutfit = true
          L9_3(L10_3, L11_3)
        end
      end
    end
    L3_3 = #L2_3
    if 0 == L3_3 then
      L3_3 = table
      L3_3 = L3_3.insert
      L4_3 = L2_3
      L5_3 = {}
      L6_3 = getLocalizedText
      L7_3 = "wardrobe:empty"
      L6_3 = L6_3(L7_3)
      L5_3.label = L6_3
      L3_3(L4_3, L5_3)
    end
    L3_3 = Framework
    L3_3 = L3_3.menu
    L3_3 = L3_3()
    L3_3 = L3_3.Open
    L4_3 = "default"
    L5_3 = GetCurrentResourceName
    L5_3 = L5_3()
    L6_3 = "remove_cloth"
    L7_3 = {}
    L8_3 = getLocalizedText
    L9_3 = "remove_cloth"
    L8_3 = L8_3(L9_3)
    L7_3.title = L8_3
    L8_3 = config
    L8_3 = L8_3.menuPosition
    L7_3.align = L8_3
    L7_3.elements = L2_3
    function L8_3(A0_4, A1_4)
      local L2_4, L3_4, L4_4, L5_4, L6_4
      L2_4 = A0_4.current
      L2_4 = L2_4.id
      L3_4 = A0_4.current
      L3_4 = L3_4.isPropertyOutfit
      if L2_4 then
        L4_4 = A1_4.close
        L4_4()
        if L3_4 then
          L4_4 = TriggerServerEvent
          L5_4 = Utils
          L5_4 = L5_4.eventsPrefix
          L6_4 = ":wardrobe:deletePropertyOutfit"
          L5_4 = L5_4 .. L6_4
          L6_4 = A0_4.current
          L6_4 = L6_4.id
          L4_4(L5_4, L6_4)
        else
          L4_4 = TriggerServerEvent
          L5_4 = Utils
          L5_4 = L5_4.eventsPrefix
          L6_4 = ":wardrobe:deleteOutfit"
          L5_4 = L5_4 .. L6_4
          L6_4 = A0_4.current
          L6_4 = L6_4.id
          L4_4(L5_4, L6_4)
        end
        L4_4 = notifyClient
        L5_4 = getLocalizedText
        L6_4 = "delete_outfit"
        L5_4, L6_4 = L5_4(L6_4)
        L4_4(L5_4, L6_4)
      end
    end
    function L9_3(A0_4, A1_4)
      local L2_4
      L2_4 = A1_4.close
      L2_4()
    end
    L3_3(L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
  end
  L0_2(L1_2, L2_2)
end
function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L0_2 = {}
  L1_2 = {}
  L2_2 = getLocalizedText
  L3_2 = "player_clothes"
  L2_2 = L2_2(L3_2)
  L1_2.label = L2_2
  L1_2.value = "player_dressing"
  L2_2 = {}
  L3_2 = getLocalizedText
  L4_2 = "remove_cloth"
  L3_2 = L3_2(L4_2)
  L2_2.label = L3_2
  L2_2.value = "remove_cloth"
  L3_2 = {}
  L4_2 = getLocalizedText
  L5_2 = "save_cloth"
  L4_2 = L4_2(L5_2)
  L3_2.label = L4_2
  L3_2.value = "save_cloth"
  L0_2[1] = L1_2
  L0_2[2] = L2_2
  L0_2[3] = L3_2
  L1_2 = Framework
  L1_2 = L1_2.menu
  L1_2 = L1_2()
  L1_2 = L1_2.CloseAll
  L1_2()
  L1_2 = Framework
  L1_2 = L1_2.menu
  L1_2 = L1_2()
  L1_2 = L1_2.Open
  L2_2 = "default"
  L3_2 = GetCurrentResourceName
  L3_2 = L3_2()
  L4_2 = "wardrobe"
  L5_2 = {}
  L6_2 = getLocalizedText
  L7_2 = "clothes"
  L6_2 = L6_2(L7_2)
  L5_2.title = L6_2
  L6_2 = config
  L6_2 = L6_2.menuPosition
  L5_2.align = L6_2
  L5_2.elements = L0_2
  function L6_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3
    L2_3 = A0_3.current
    L2_3 = L2_3.value
    if "player_dressing" == L2_3 then
      L3_3 = L0_1
      L3_3()
    elseif "remove_cloth" == L2_3 then
      L3_3 = L1_1
      L3_3()
    elseif "save_cloth" == L2_3 then
      L3_3 = Framework
      L3_3 = L3_3.askInput
      L4_3 = getLocalizedText
      L5_3 = "outfit_name"
      L4_3 = L4_3(L5_3)
      L5_3 = "outfit_name"
      L3_3 = L3_3(L4_3, L5_3)
      if L3_3 then
        L4_3 = Framework
        L4_3 = L4_3.getPlayerSkin
        L4_3 = L4_3()
        if L4_3 then
          L5_3 = TriggerServerEvent
          L6_3 = Utils
          L6_3 = L6_3.eventsPrefix
          L7_3 = ":saveNewOutfitInWardrobe"
          L6_3 = L6_3 .. L7_3
          L7_3 = L4_3
          L8_3 = L3_3
          L5_3(L6_3, L7_3, L8_3)
        end
      else
        L4_3 = notifyClient
        L5_3 = getLocalizedText
        L6_3 = "outfit_label_empty"
        L5_3, L6_3, L7_3, L8_3 = L5_3(L6_3)
        L4_3(L5_3, L6_3, L7_3, L8_3)
      end
    end
  end
  function L7_2(A0_3, A1_3)
    local L2_3
    openedMenu = nil
    L2_3 = A1_3.close
    L2_3()
  end
  L1_2(L2_2, L3_2, L4_2, L5_2, L6_2, L7_2)
end
openWardrobe = L2_1

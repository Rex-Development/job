local L0_1, L1_1
L0_1 = nil
function L1_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = TriggerServerCallback
  L2_2 = Utils
  L2_2 = L2_2.eventsPrefix
  L3_2 = ":getJobOutfits"
  L2_2 = L2_2 .. L3_2
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3
    L1_3 = {}
    L2_3 = #A0_3
    if L2_3 > 0 then
      L2_3 = table
      L2_3 = L2_3.insert
      L3_3 = L1_3
      L4_3 = {}
      L5_3 = getLocalizedText
      L6_3 = "civilian_outfit"
      L5_3 = L5_3(L6_3)
      L4_3.label = L5_3
      L4_3.value = "civilian"
      L2_3(L3_3, L4_3)
      L2_3 = pairs
      L3_3 = A0_3
      L2_3, L3_3, L4_3, L5_3 = L2_3(L3_3)
      for L6_3, L7_3 in L2_3, L3_3, L4_3, L5_3 do
        L8_3 = table
        L8_3 = L8_3.insert
        L9_3 = L1_3
        L10_3 = {}
        L11_3 = L7_3.label
        L10_3.label = L11_3
        L10_3.value = L7_3
        L8_3(L9_3, L10_3)
      end
    else
      L2_3 = table
      L2_3 = L2_3.insert
      L3_3 = L1_3
      L4_3 = {}
      L5_3 = getLocalizedText
      L6_3 = "no_outfits"
      L5_3 = L5_3(L6_3)
      L4_3.label = L5_3
      L2_3(L3_3, L4_3)
    end
    L2_3 = Framework
    L2_3 = L2_3.menu
    L2_3 = L2_3()
    L2_3 = L2_3.CloseAll
    L2_3()
    L2_3 = Framework
    L2_3 = L2_3.menu
    L2_3 = L2_3()
    L2_3 = L2_3.Open
    L3_3 = "default"
    L4_3 = GetCurrentResourceName
    L4_3 = L4_3()
    L5_3 = "job_outfit"
    L6_3 = {}
    L7_3 = getLocalizedText
    L8_3 = "job_outfit"
    L7_3 = L7_3(L8_3)
    L6_3.title = L7_3
    L7_3 = config
    L7_3 = L7_3.menuPosition
    L6_3.align = L7_3
    L6_3.elements = L1_3
    function L7_3(A0_4, A1_4)
      local L2_4, L3_4, L4_4, L5_4
      L2_4 = A0_4.current
      L2_4 = L2_4.value
      if "civilian" == L2_4 then
        L3_4 = L0_1
        if L3_4 then
          L3_4 = setClothes
          L4_4 = L0_1
          L3_4(L4_4)
          L3_4 = nil
          L0_1 = L3_4
        end
      elseif L2_4 then
        L3_4 = L0_1
        if nil == L3_4 then
          L3_4 = Framework
          L3_4 = L3_4.getPlayerSkin
          L3_4 = L3_4()
          L0_1 = L3_4
        end
        L3_4 = Framework
        L3_4 = L3_4.getFramework
        L3_4 = L3_4()
        if "QB-core" == L3_4 then
          L3_4 = setClothes
          L4_4 = Framework
          L4_4 = L4_4.convertOutfitFromESXToQBCore
          L5_4 = L2_4
          L4_4 = L4_4(L5_4)
          L5_4 = false
          L3_4(L4_4, L5_4)
        else
          L3_4 = Framework
          L3_4 = L3_4.getFramework
          L3_4 = L3_4()
          if "ESX" == L3_4 then
            L3_4 = setClothes
            L4_4 = L2_4
            L5_4 = false
            L3_4(L4_4, L5_4)
          end
        end
      end
    end
    function L8_3(A0_4, A1_4)
      local L2_4
      openedMenu = nil
      L2_4 = A1_4.close
      L2_4()
    end
    L2_3(L3_3, L4_3, L5_3, L6_3, L7_3, L8_3)
  end
  L4_2 = A0_2
  L1_2(L2_2, L3_2, L4_2)
end
openJobOutfit = L1_1

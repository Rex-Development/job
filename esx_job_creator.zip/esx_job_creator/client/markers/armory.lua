local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1
function L0_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = TriggerServerCallback
  L2_2 = Utils
  L2_2 = L2_2.eventsPrefix
  L3_2 = ":getPlayerWeapons"
  L2_2 = L2_2 .. L3_2
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3
    L1_3 = {}
    L2_3 = #A0_3
    if L2_3 > 0 then
      L2_3 = pairs
      L3_3 = A0_3
      L2_3, L3_3, L4_3, L5_3 = L2_3(L3_3)
      for L6_3, L7_3 in L2_3, L3_3, L4_3, L5_3 do
        L8_3 = table
        L8_3 = L8_3.insert
        L9_3 = L1_3
        L10_3 = {}
        L11_3 = getLocalizedText
        L12_3 = "weapon"
        L13_3 = L7_3.label
        L14_3 = L7_3.ammo
        if not L14_3 then
          L14_3 = 0
        end
        L11_3 = L11_3(L12_3, L13_3, L14_3)
        L10_3.label = L11_3
        L11_3 = L7_3.name
        L10_3.value = L11_3
        L8_3(L9_3, L10_3)
      end
    else
      L2_3 = table
      L2_3 = L2_3.insert
      L3_3 = L1_3
      L4_3 = {}
      L5_3 = getLocalizedText
      L6_3 = "not_have_any_weapon"
      L5_3 = L5_3(L6_3)
      L4_3.label = L5_3
      L2_3(L3_3, L4_3)
    end
    L2_3 = Framework
    L2_3 = L2_3.menu
    L2_3 = L2_3()
    L2_3 = L2_3.Open
    L3_3 = "default"
    L4_3 = GetCurrentResourceName
    L4_3 = L4_3()
    L5_3 = "armory_deposit"
    L6_3 = {}
    L7_3 = getLocalizedText
    L8_3 = "armory_deposit"
    L7_3 = L7_3(L8_3)
    L6_3.title = L7_3
    L7_3 = config
    L7_3 = L7_3.menuPosition
    L6_3.align = L7_3
    L6_3.elements = L1_3
    function L7_3(A0_4, A1_4)
      local L2_4, L3_4, L4_4, L5_4, L6_4, L7_4
      L2_4 = A0_4.current
      L2_4 = L2_4.value
      if L2_4 then
        L3_4 = TriggerServerCallback
        L4_4 = Utils
        L4_4 = L4_4.eventsPrefix
        L5_4 = ":depositWeaponInArmory"
        L4_4 = L4_4 .. L5_4
        function L5_4(A0_5)
          local L1_5, L2_5
          if A0_5 then
            L1_5 = L0_1
            L2_5 = A0_2
            L1_5(L2_5)
          end
        end
        L6_4 = A0_2
        L7_4 = L2_4
        L3_4(L4_4, L5_4, L6_4, L7_4)
      end
    end
    function L8_3(A0_4, A1_4)
      local L2_4
      openedMenu = nil
      L2_4 = A1_4.close
      L2_4()
    end
    L2_3(L3_3, L4_3, L5_3, L6_3, L7_3, L8_3)
  end
  L1_2(L2_2, L3_2)
end
function L1_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L2_2 = Framework
  L2_2 = L2_2.menu
  L2_2 = L2_2()
  L2_2 = L2_2.Open
  L3_2 = "default"
  L4_2 = GetCurrentResourceName
  L4_2 = L4_2()
  L5_2 = "armory_choose_weapon"
  L6_2 = {}
  L7_2 = getLocalizedText
  L8_2 = "armory_take"
  L7_2 = L7_2(L8_2)
  L6_2.title = L7_2
  L7_2 = config
  L7_2 = L7_2.menuPosition
  L6_2.align = L7_2
  L6_2.elements = A1_2
  function L7_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L2_3 = A0_3.current
    L2_3 = L2_3.value
    if L2_3 then
      L3_3 = TriggerServerCallback
      L4_3 = Utils
      L4_3 = L4_3.eventsPrefix
      L5_3 = ":takeWeaponFromArmory"
      L4_3 = L4_3 .. L5_3
      function L5_3(A0_4)
        local L1_4, L2_4
        if A0_4 then
          L1_4 = takeWeaponFromArmory
          L2_4 = A0_2
          L1_4(L2_4)
        end
      end
      L6_3 = A0_2
      L7_3 = L2_3
      L3_3(L4_3, L5_3, L6_3, L7_3)
    end
  end
  function L8_2(A0_3, A1_3)
    local L2_3
    L2_3 = A1_3.close
    L2_3()
  end
  L2_2(L3_2, L4_2, L5_2, L6_2, L7_2, L8_2)
end
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = TriggerServerCallback
  L2_2 = Utils
  L2_2 = L2_2.eventsPrefix
  L3_2 = ":retrieveArmoryWeapons"
  L2_2 = L2_2 .. L3_2
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3
    L1_3 = {}
    L2_3 = {}
    L3_3 = pairs
    L4_3 = A0_3
    L3_3, L4_3, L5_3, L6_3 = L3_3(L4_3)
    for L7_3, L8_3 in L3_3, L4_3, L5_3, L6_3 do
      L9_3 = ESX
      L9_3 = L9_3.GetWeaponLabel
      L10_3 = L8_3.weapon
      L9_3 = L9_3(L10_3)
      L10_3 = L2_3[L9_3]
      if not L10_3 then
        L10_3 = {}
        L2_3[L9_3] = L10_3
        L10_3 = table
        L10_3 = L10_3.insert
        L11_3 = L1_3
        L12_3 = {}
        L12_3.label = L9_3
        L13_3 = L2_3[L9_3]
        L12_3.weapons = L13_3
        L10_3(L11_3, L12_3)
      end
      L10_3 = table
      L10_3 = L10_3.insert
      L11_3 = L2_3[L9_3]
      L12_3 = {}
      L13_3 = getLocalizedText
      L14_3 = "weapon"
      L15_3 = ESX
      L15_3 = L15_3.GetWeaponLabel
      L16_3 = L8_3.weapon
      L15_3 = L15_3(L16_3)
      L16_3 = L8_3.ammo
      L13_3 = L13_3(L14_3, L15_3, L16_3)
      L12_3.label = L13_3
      L13_3 = L8_3.id
      L12_3.value = L13_3
      L10_3(L11_3, L12_3)
    end
    L3_3 = #L1_3
    if 0 == L3_3 then
      L3_3 = table
      L3_3 = L3_3.insert
      L4_3 = L1_3
      L5_3 = {}
      L6_3 = getLocalizedText
      L7_3 = "no_weapons_in_armory"
      L6_3 = L6_3(L7_3)
      L5_3.label = L6_3
      L3_3(L4_3, L5_3)
    end
    L3_3 = Framework
    L3_3 = L3_3.menu
    L3_3 = L3_3()
    L3_3 = L3_3.CloseAll
    L3_3()
    L3_3 = Framework
    L3_3 = L3_3.menu
    L3_3 = L3_3()
    L3_3 = L3_3.Open
    L4_3 = "default"
    L5_3 = GetCurrentResourceName
    L5_3 = L5_3()
    L6_3 = "armory_take"
    L7_3 = {}
    L8_3 = getLocalizedText
    L9_3 = "armory_take"
    L8_3 = L8_3(L9_3)
    L7_3.title = L8_3
    L8_3 = config
    L8_3 = L8_3.menuPosition
    L7_3.align = L8_3
    L7_3.elements = L1_3
    function L8_3(A0_4, A1_4)
      local L2_4, L3_4, L4_4, L5_4
      L2_4 = A0_4.current
      L2_4 = L2_4.weapons
      if L2_4 then
        L3_4 = L1_1
        L4_4 = A0_2
        L5_4 = L2_4
        L3_4(L4_4, L5_4)
      end
    end
    function L9_3(A0_4, A1_4)
      local L2_4
      openedMenu = nil
      L2_4 = A1_4.close
      L2_4()
    end
    L3_3(L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
  end
  L4_2 = A0_2
  L1_2(L2_2, L3_2, L4_2)
end
takeWeaponFromArmory = L2_1
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L1_2 = Framework
  L1_2 = L1_2.menu
  L1_2 = L1_2()
  L1_2 = L1_2.CloseAll
  L1_2()
  L1_2 = Framework
  L1_2 = L1_2.menu
  L1_2 = L1_2()
  L1_2 = L1_2.Open
  L2_2 = "default"
  L3_2 = GetCurrentResourceName
  L3_2 = L3_2()
  L4_2 = "armory"
  L5_2 = {}
  L6_2 = getLocalizedText
  L7_2 = "armory"
  L6_2 = L6_2(L7_2)
  L5_2.title = L6_2
  L6_2 = config
  L6_2 = L6_2.menuPosition
  L5_2.align = L6_2
  L6_2 = {}
  L7_2 = {}
  L8_2 = getLocalizedText
  L9_2 = "deposit_weapon"
  L8_2 = L8_2(L9_2)
  L7_2.label = L8_2
  L7_2.value = "deposit"
  L8_2 = {}
  L9_2 = getLocalizedText
  L10_2 = "take_weapon"
  L9_2 = L9_2(L10_2)
  L8_2.label = L9_2
  L8_2.value = "take"
  L6_2[1] = L7_2
  L6_2[2] = L8_2
  L5_2.elements = L6_2
  function L6_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3
    L2_3 = A0_3.current
    L2_3 = L2_3.value
    if "deposit" == L2_3 then
      L3_3 = L0_1
      L4_3 = A0_2
      L3_3(L4_3)
    elseif "take" == L2_3 then
      L3_3 = takeWeaponFromArmory
      L4_3 = A0_2
      L3_3(L4_3)
    end
  end
  function L7_2(A0_3, A1_3)
    local L2_3
    openedMenu = nil
    L2_3 = A1_3.close
    L2_3()
  end
  L1_2(L2_2, L3_2, L4_2, L5_2, L6_2, L7_2)
end
L3_1 = addScriptRemovableEvent
L4_1 = RegisterNetEvent
L5_1 = Utils
L5_1 = L5_1.eventsPrefix
L6_1 = ":armory:openArmory"
L5_1 = L5_1 .. L6_1
L6_1 = L2_1
L4_1, L5_1, L6_1 = L4_1(L5_1, L6_1)
L3_1(L4_1, L5_1, L6_1)

local L0_1, L1_1, L2_1, L3_1, L4_1
L0_1 = false
function L1_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = Framework
  L1_2 = L1_2.menu
  L1_2 = L1_2()
  L1_2 = L1_2.CloseAll
  L1_2()
  L1_2 = TriggerServerCallback
  L2_2 = Utils
  L2_2 = L2_2.eventsPrefix
  L3_2 = ":getMarketItems"
  L2_2 = L2_2 .. L3_2
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    if not A0_3 then
      L1_3 = {}
      A0_3 = L1_3
    end
    L1_3 = #A0_3
    if 0 == L1_3 then
      L1_3 = table
      L1_3 = L1_3.insert
      L2_3 = A0_3
      L3_3 = {}
      L4_3 = getLocalizedText
      L5_3 = "nothing_can_be_sold_yet"
      L4_3 = L4_3(L5_3)
      L3_3.label = L4_3
      L1_3(L2_3, L3_3)
    end
    L1_3 = Framework
    L1_3 = L1_3.menu
    L1_3 = L1_3()
    L1_3 = L1_3.Open
    L2_3 = "default"
    L3_3 = GetCurrentResourceName
    L3_3 = L3_3()
    L4_3 = "market_sell"
    L5_3 = {}
    L6_3 = getLocalizedText
    L7_3 = "market"
    L6_3 = L6_3(L7_3)
    L5_3.title = L6_3
    L6_3 = config
    L6_3 = L6_3.menuPosition
    L5_3.align = L6_3
    L5_3.elements = A0_3
    function L6_3(A0_4, A1_4)
      local L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4
      L2_4 = A0_4.current
      L2_4 = L2_4.value
      if L2_4 then
        L3_4 = config
        L3_4 = L3_4.marketSellOnePerTime
        if L3_4 then
          L3_4 = Framework
          L3_4 = L3_4.askQuantity
          L4_4 = getLocalizedText
          L5_4 = "market:how_many_to_sell"
          L4_4 = L4_4(L5_4)
          L5_4 = "market_sell_quantity"
          L6_4 = 1
          L7_4 = nil
          function L8_4(A0_5)
            local L1_5, L2_5, L3_5, L4_5, L5_5
            if A0_5 then
              L1_5 = TriggerServerEvent
              L2_5 = Utils
              L2_5 = L2_5.eventsPrefix
              L3_5 = ":sellMarketItem"
              L2_5 = L2_5 .. L3_5
              L3_5 = A0_2
              L4_5 = L2_4
              L5_5 = A0_5
              L1_5(L2_5, L3_5, L4_5, L5_5)
            end
          end
          L3_4(L4_4, L5_4, L6_4, L7_4, L8_4)
        else
          L3_4 = TriggerServerEvent
          L4_4 = Utils
          L4_4 = L4_4.eventsPrefix
          L5_4 = ":sellMarketItem"
          L4_4 = L4_4 .. L5_4
          L5_4 = A0_2
          L6_4 = L2_4
          L7_4 = 1
          L3_4(L4_4, L5_4, L6_4, L7_4)
        end
      end
    end
    function L7_3(A0_4, A1_4)
      local L2_4
      openedMenu = nil
      L2_4 = A1_4.close
      L2_4()
    end
    L1_3(L2_3, L3_3, L4_3, L5_3, L6_3, L7_3)
  end
  L4_2 = A0_2
  L1_2(L2_2, L3_2, L4_2)
end
openMarket = L1_1
function L1_1()
  local L0_2, L1_2, L2_2
  while true do
    L0_2 = L0_1
    if not L0_2 then
      break
    end
    L0_2 = showHelpNotification
    L1_2 = getLocalizedText
    L2_2 = "press_to_stop"
    L1_2, L2_2 = L1_2(L2_2)
    L0_2(L1_2, L2_2)
    L0_2 = IsControlJustReleased
    L1_2 = 0
    L2_2 = 38
    L0_2 = L0_2(L1_2, L2_2)
    if L0_2 then
      L0_2 = TriggerServerEvent
      L1_2 = Utils
      L1_2 = L1_2.eventsPrefix
      L2_2 = ":market:stopSelling"
      L1_2 = L1_2 .. L2_2
      L0_2(L1_2)
      L0_2 = stopTimedFreeze
      L0_2()
      L0_2 = stopProgressBar
      L0_2()
    end
    L0_2 = Citizen
    L0_2 = L0_2.Wait
    L1_2 = 0
    L0_2(L1_2)
  end
end
L2_1 = RegisterNetEvent
L3_1 = Utils
L3_1 = L3_1.eventsPrefix
L4_1 = ":market:toggleSelling"
L3_1 = L3_1 .. L4_1
function L4_1(A0_2)
  local L1_2, L2_2
  L0_1 = A0_2
  L1_2 = L0_1
  if L1_2 then
    L1_2 = Citizen
    L1_2 = L1_2.CreateThread
    L2_2 = L1_1
    L1_2(L2_2)
  end
end
L2_1(L3_1, L4_1)

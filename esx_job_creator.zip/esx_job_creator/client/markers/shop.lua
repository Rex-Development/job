local L0_1, L1_1
function L0_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = TriggerServerCallback
  L2_2 = Utils
  L2_2 = L2_2.eventsPrefix
  L3_2 = ":getShopData"
  L2_2 = L2_2 .. L3_2
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L1_3 = Framework
    L1_3 = L1_3.menu
    L1_3 = L1_3()
    L1_3 = L1_3.CloseAll
    L1_3()
    L1_3 = Framework
    L1_3 = L1_3.menu
    L1_3 = L1_3()
    L1_3 = L1_3.Open
    L2_3 = "default"
    L3_3 = GetCurrentResourceName
    L3_3 = L3_3()
    L4_3 = "job_shop"
    L5_3 = {}
    L6_3 = getLocalizedText
    L7_3 = "job_shop"
    L6_3 = L6_3(L7_3)
    L5_3.title = L6_3
    L6_3 = config
    L6_3 = L6_3.menuPosition
    L5_3.align = L6_3
    L5_3.elements = A0_3
    function L6_3(A0_4, A1_4)
      local L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4, L9_4
      L2_4 = A0_4.current
      L2_4 = L2_4.value
      L3_4 = A0_4.current
      L3_4 = L3_4.itemType
      if L2_4 then
        if "item_standard" == L3_4 then
          L4_4 = Framework
          L4_4 = L4_4.askQuantity
          L5_4 = getLocalizedText
          L6_4 = "quantity"
          L5_4 = L5_4(L6_4)
          L6_4 = "shop_quantity"
          L7_4 = 1
          L8_4 = nil
          function L9_4(A0_5)
            local L1_5, L2_5, L3_5, L4_5, L5_5
            if A0_5 then
              L1_5 = TriggerServerEvent
              L2_5 = Utils
              L2_5 = L2_5.eventsPrefix
              L3_5 = ":buyShopItem"
              L2_5 = L2_5 .. L3_5
              L3_5 = A0_2
              L4_5 = L2_4
              L5_5 = A0_5
              L1_5(L2_5, L3_5, L4_5, L5_5)
            end
          end
          L4_4(L5_4, L6_4, L7_4, L8_4, L9_4)
        elseif "item_weapon" == L3_4 then
          L4_4 = TriggerServerEvent
          L5_4 = Utils
          L5_4 = L5_4.eventsPrefix
          L6_4 = ":buyShopItem"
          L5_4 = L5_4 .. L6_4
          L6_4 = A0_2
          L7_4 = L2_4
          L8_4 = 1
          L4_4(L5_4, L6_4, L7_4, L8_4)
        end
      end
    end
    function L7_3(A0_4, A1_4)
      local L2_4
      openedMenu = nil
      L2_4 = A1_4.close
      L2_4()
    end
    L1_3(L2_3, L3_3, L4_3, L5_3, L6_3, L7_3)
  end
  L4_2 = A0_2
  L1_2(L2_2, L3_2, L4_2)
end
openShop = L0_1

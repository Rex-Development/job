local L0_1, L1_1, L2_1, L3_1, L4_1
function L0_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = TriggerServerCallback
  L2_2 = Utils
  L2_2 = L2_2.eventsPrefix
  L3_2 = ":getJobShop"
  L2_2 = L2_2 .. L3_2
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3
    L1_3 = {}
    L2_3 = pairs
    L3_3 = A0_3
    L2_3, L3_3, L4_3, L5_3 = L2_3(L3_3)
    for L6_3, L7_3 in L2_3, L3_3, L4_3, L5_3 do
      L8_3 = table
      L8_3 = L8_3.insert
      L9_3 = L1_3
      L10_3 = {}
      L11_3 = getLocalizedText
      L12_3 = "job_shop_item"
      L13_3 = L7_3.item_label
      L14_3 = L7_3.item_quantity
      L15_3 = Framework
      L15_3 = L15_3.groupDigits
      L16_3 = L7_3.price
      L15_3, L16_3 = L15_3(L16_3)
      L11_3 = L11_3(L12_3, L13_3, L14_3, L15_3, L16_3)
      L10_3.label = L11_3
      L11_3 = L7_3.id
      L10_3.itemId = L11_3
      L10_3.itemData = L7_3
      L8_3(L9_3, L10_3)
    end
    L2_3 = #L1_3
    if 0 == L2_3 then
      L2_3 = table
      L2_3 = L2_3.insert
      L3_3 = L1_3
      L4_3 = {}
      L5_3 = getLocalizedText
      L6_3 = "job_shop_empty"
      L5_3 = L5_3(L6_3)
      L4_3.label = L5_3
      L2_3(L3_3, L4_3)
    end
    L2_3 = Framework
    L2_3 = L2_3.menu
    L2_3 = L2_3()
    L2_3 = L2_3.Open
    L3_3 = "default"
    L4_3 = GetCurrentResourceName
    L4_3 = L4_3()
    L5_3 = "job_owned_shop_items"
    L6_3 = {}
    L7_3 = getLocalizedText
    L8_3 = "job_owned_shop"
    L7_3 = L7_3(L8_3)
    L6_3.title = L7_3
    L7_3 = config
    L7_3 = L7_3.menuPosition
    L6_3.align = L7_3
    L6_3.elements = L1_3
    function L7_3(A0_4, A1_4)
      local L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4, L9_4, L10_4, L11_4
      L2_4 = A0_4.current
      L2_4 = L2_4.itemId
      if L2_4 then
        L3_4 = A0_4.current
        L3_4 = L3_4.itemData
        L3_4 = L3_4.price
        L4_4 = A0_4.current
        L4_4 = L4_4.itemData
        L4_4 = L4_4.item_quantity
        L5_4 = A0_4.current
        L5_4 = L5_4.itemData
        L5_4 = L5_4.item_type
        if "item_standard" == L5_4 then
          L6_4 = Framework
          L6_4 = L6_4.askQuantity
          L7_4 = getLocalizedText
          L8_4 = "quantity"
          L7_4 = L7_4(L8_4)
          L8_4 = "job_owned_shop_items_quantity"
          L9_4 = 1
          L10_4 = L4_4
          function L11_4(A0_5)
            local L1_5, L2_5, L3_5, L4_5, L5_5
            if A0_5 then
              L1_5 = TriggerServerEvent
              L2_5 = Utils
              L2_5 = L2_5.eventsPrefix
              L3_5 = ":job_shop:buyItem"
              L2_5 = L2_5 .. L3_5
              L3_5 = A0_2
              L4_5 = L2_4
              L5_5 = A0_5
              L1_5(L2_5, L3_5, L4_5, L5_5)
              L1_5 = L0_1
              L2_5 = A0_2
              L1_5(L2_5)
            end
          end
          L6_4(L7_4, L8_4, L9_4, L10_4, L11_4)
        elseif "item_weapon" == L5_4 then
          L6_4 = TriggerServerEvent
          L7_4 = Utils
          L7_4 = L7_4.eventsPrefix
          L8_4 = ":job_shop:buyItem"
          L7_4 = L7_4 .. L8_4
          L8_4 = A0_2
          L9_4 = L2_4
          L10_4 = 1
          L6_4(L7_4, L8_4, L9_4, L10_4)
          L6_4 = L0_1
          L7_4 = A0_2
          L6_4(L7_4)
        end
      end
    end
    function L8_3(A0_4, A1_4)
      local L2_4
      L2_4 = A1_4.close
      L2_4()
    end
    L2_3(L3_3, L4_3, L5_3, L6_3, L7_3, L8_3)
  end
  L4_2 = A0_2
  L1_2(L2_2, L3_2, L4_2)
end
function L1_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = TriggerServerCallback
  L2_2 = Utils
  L2_2 = L2_2.eventsPrefix
  L3_2 = ":getSellableStuff"
  L2_2 = L2_2 .. L3_2
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L1_3 = #A0_3
    if 0 == L1_3 then
      L1_3 = table
      L1_3 = L1_3.insert
      L2_3 = A0_3
      L3_3 = {}
      L4_3 = getLocalizedText
      L5_3 = "job_shop:nothing_to_sell"
      L4_3 = L4_3(L5_3)
      L3_3.label = L4_3
      L1_3(L2_3, L3_3)
    end
    L1_3 = Framework
    L1_3 = L1_3.menu
    L1_3 = L1_3()
    L1_3 = L1_3.Open
    L2_3 = "default"
    L3_3 = GetCurrentResourceName
    L3_3 = L3_3()
    L4_3 = "job_owned_shop_put_on_sale"
    L5_3 = {}
    L6_3 = getLocalizedText
    L7_3 = "job_shop:what_to_put_on_sale"
    L6_3 = L6_3(L7_3)
    L5_3.title = L6_3
    L6_3 = config
    L6_3 = L6_3.menuPosition
    L5_3.align = L6_3
    L5_3.elements = A0_3
    function L6_3(A0_4, A1_4)
      local L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4, L9_4, L10_4
      L2_4 = A0_4.current
      L2_4 = L2_4.value
      L3_4 = A0_4.current
      L3_4 = L3_4.count
      L4_4 = A0_4.current
      L4_4 = L4_4.type
      if L3_4 > 1 then
        L5_4 = Framework
        L5_4 = L5_4.askQuantity
        L6_4 = getLocalizedText
        L7_4 = "quantity"
        L6_4 = L6_4(L7_4)
        L7_4 = "job_owned_shop_put_on_sale_quantity"
        L8_4 = 1
        L9_4 = L3_4
        function L10_4(A0_5)
          local L1_5, L2_5, L3_5, L4_5, L5_5, L6_5
          if A0_5 then
            L1_5 = Framework
            L1_5 = L1_5.askQuantity
            L2_5 = getLocalizedText
            L3_5 = "item_price"
            L2_5 = L2_5(L3_5)
            L3_5 = "job_owned_shop_put_on_sale_price"
            L4_5 = 1
            L5_5 = nil
            function L6_5(A0_6)
              local L1_6, L2_6, L3_6, L4_6, L5_6, L6_6, L7_6
              if A0_6 then
                L1_6 = TriggerServerEvent
                L2_6 = Utils
                L2_6 = L2_6.eventsPrefix
                L3_6 = ":jobShopPutOnSale"
                L2_6 = L2_6 .. L3_6
                L3_6 = L2_4
                L4_6 = L4_4
                L5_6 = A0_5
                L6_6 = A0_6
                L7_6 = A0_2
                L1_6(L2_6, L3_6, L4_6, L5_6, L6_6, L7_6)
                L1_6 = L1_1
                L2_6 = A0_2
                L1_6(L2_6)
              end
            end
            L1_5(L2_5, L3_5, L4_5, L5_5, L6_5)
          end
        end
        L5_4(L6_4, L7_4, L8_4, L9_4, L10_4)
      else
        L5_4 = Framework
        L5_4 = L5_4.askQuantity
        L6_4 = getLocalizedText
        L7_4 = "item_price"
        L6_4 = L6_4(L7_4)
        L7_4 = "job_owned_shop_put_on_sale_price"
        L8_4 = 1
        L9_4 = nil
        function L10_4(A0_5)
          local L1_5, L2_5, L3_5, L4_5, L5_5, L6_5, L7_5
          if A0_5 then
            L1_5 = TriggerServerEvent
            L2_5 = Utils
            L2_5 = L2_5.eventsPrefix
            L3_5 = ":jobShopPutOnSale"
            L2_5 = L2_5 .. L3_5
            L3_5 = L2_4
            L4_5 = L4_4
            L5_5 = L3_4
            L6_5 = A0_5
            L7_5 = A0_2
            L1_5(L2_5, L3_5, L4_5, L5_5, L6_5, L7_5)
            L1_5 = L1_1
            L2_5 = A0_2
            L1_5(L2_5)
          end
        end
        L5_4(L6_4, L7_4, L8_4, L9_4, L10_4)
      end
    end
    function L7_3(A0_4, A1_4)
      local L2_4
      L2_4 = A1_4.close
      L2_4()
    end
    L1_3(L2_3, L3_3, L4_3, L5_3, L6_3, L7_3)
  end
  L1_2(L2_2, L3_2)
end
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = TriggerServerCallback
  L2_2 = Utils
  L2_2 = L2_2.eventsPrefix
  L3_2 = ":getJobShop"
  L2_2 = L2_2 .. L3_2
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3
    L1_3 = {}
    L2_3 = pairs
    L3_3 = A0_3
    L2_3, L3_3, L4_3, L5_3 = L2_3(L3_3)
    for L6_3, L7_3 in L2_3, L3_3, L4_3, L5_3 do
      L8_3 = table
      L8_3 = L8_3.insert
      L9_3 = L1_3
      L10_3 = {}
      L11_3 = getLocalizedText
      L12_3 = "job_shop_item"
      L13_3 = L7_3.item_label
      L14_3 = L7_3.item_quantity
      L15_3 = Framework
      L15_3 = L15_3.groupDigits
      L16_3 = L7_3.price
      L15_3, L16_3 = L15_3(L16_3)
      L11_3 = L11_3(L12_3, L13_3, L14_3, L15_3, L16_3)
      L10_3.label = L11_3
      L11_3 = L7_3.id
      L10_3.itemId = L11_3
      L10_3.itemData = L7_3
      L8_3(L9_3, L10_3)
    end
    L2_3 = #L1_3
    if 0 == L2_3 then
      L2_3 = table
      L2_3 = L2_3.insert
      L3_3 = L1_3
      L4_3 = {}
      L5_3 = getLocalizedText
      L6_3 = "job_shop_empty"
      L5_3 = L5_3(L6_3)
      L4_3.label = L5_3
      L2_3(L3_3, L4_3)
    end
    L2_3 = Framework
    L2_3 = L2_3.menu
    L2_3 = L2_3()
    L2_3 = L2_3.Open
    L3_3 = "default"
    L4_3 = GetCurrentResourceName
    L4_3 = L4_3()
    L5_3 = "job_owned_shop_items_remove_from_sale"
    L6_3 = {}
    L7_3 = getLocalizedText
    L8_3 = "job_shop:what_to_remove_from_sale"
    L7_3 = L7_3(L8_3)
    L6_3.title = L7_3
    L7_3 = config
    L7_3 = L7_3.menuPosition
    L6_3.align = L7_3
    L6_3.elements = L1_3
    function L7_3(A0_4, A1_4)
      local L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4, L9_4
      L2_4 = A0_4.current
      L2_4 = L2_4.itemId
      if L2_4 then
        L3_4 = A0_4.current
        L3_4 = L3_4.itemData
        L3_4 = L3_4.item_quantity
        if L3_4 > 1 then
          L4_4 = Framework
          L4_4 = L4_4.askQuantity
          L5_4 = getLocalizedText
          L6_4 = "quantity"
          L5_4 = L5_4(L6_4)
          L6_4 = "job_owned_shop_items_remove_from_sale_quantity"
          L7_4 = 1
          L8_4 = L3_4
          function L9_4(A0_5)
            local L1_5, L2_5, L3_5, L4_5, L5_5
            if A0_5 then
              L1_5 = TriggerServerEvent
              L2_5 = Utils
              L2_5 = L2_5.eventsPrefix
              L3_5 = ":job_shop:removeFromSale"
              L2_5 = L2_5 .. L3_5
              L3_5 = A0_2
              L4_5 = L2_4
              L5_5 = A0_5
              L1_5(L2_5, L3_5, L4_5, L5_5)
              L1_5 = L2_1
              L2_5 = A0_2
              L1_5(L2_5)
            end
          end
          L4_4(L5_4, L6_4, L7_4, L8_4, L9_4)
        else
          L4_4 = TriggerServerEvent
          L5_4 = Utils
          L5_4 = L5_4.eventsPrefix
          L6_4 = ":job_shop:removeFromSale"
          L5_4 = L5_4 .. L6_4
          L6_4 = A0_2
          L7_4 = L2_4
          L8_4 = L3_4
          L4_4(L5_4, L6_4, L7_4, L8_4)
          L4_4 = L2_1
          L5_4 = A0_2
          L4_4(L5_4)
        end
      end
    end
    function L8_3(A0_4, A1_4)
      local L2_4
      L2_4 = A1_4.close
      L2_4()
    end
    L2_3(L3_3, L4_3, L5_3, L6_3, L7_3, L8_3)
  end
  L4_2 = A0_2
  L1_2(L2_2, L3_2, L4_2)
end
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = TriggerServerCallback
  L2_2 = Utils
  L2_2 = L2_2.eventsPrefix
  L3_2 = ":getJobShop"
  L2_2 = L2_2 .. L3_2
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3
    L1_3 = {}
    L2_3 = pairs
    L3_3 = A0_3
    L2_3, L3_3, L4_3, L5_3 = L2_3(L3_3)
    for L6_3, L7_3 in L2_3, L3_3, L4_3, L5_3 do
      L8_3 = table
      L8_3 = L8_3.insert
      L9_3 = L1_3
      L10_3 = {}
      L11_3 = getLocalizedText
      L12_3 = "job_shop_item"
      L13_3 = L7_3.item_label
      L14_3 = L7_3.item_quantity
      L15_3 = Framework
      L15_3 = L15_3.groupDigits
      L16_3 = L7_3.price
      L15_3, L16_3 = L15_3(L16_3)
      L11_3 = L11_3(L12_3, L13_3, L14_3, L15_3, L16_3)
      L10_3.label = L11_3
      L11_3 = L7_3.id
      L10_3.itemId = L11_3
      L10_3.itemData = L7_3
      L8_3(L9_3, L10_3)
    end
    L2_3 = #L1_3
    if 0 == L2_3 then
      L2_3 = table
      L2_3 = L2_3.insert
      L3_3 = L1_3
      L4_3 = {}
      L5_3 = getLocalizedText
      L6_3 = "job_shop_empty"
      L5_3 = L5_3(L6_3)
      L4_3.label = L5_3
      L2_3(L3_3, L4_3)
    end
    L2_3 = Framework
    L2_3 = L2_3.menu
    L2_3 = L2_3()
    L2_3 = L2_3.Open
    L3_3 = "default"
    L4_3 = GetCurrentResourceName
    L4_3 = L4_3()
    L5_3 = "job_owned_shop_items_restock"
    L6_3 = {}
    L7_3 = getLocalizedText
    L8_3 = "job_shop:what_to_restock"
    L7_3 = L7_3(L8_3)
    L6_3.title = L7_3
    L7_3 = config
    L7_3 = L7_3.menuPosition
    L6_3.align = L7_3
    L6_3.elements = L1_3
    function L7_3(A0_4, A1_4)
      local L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4
      L2_4 = A0_4.current
      L2_4 = L2_4.itemId
      if L2_4 then
        L3_4 = Framework
        L3_4 = L3_4.askQuantity
        L4_4 = getLocalizedText
        L5_4 = "job_shop:how_many_to_restock"
        L4_4 = L4_4(L5_4)
        L5_4 = "job_owned_shop_items_restock_quantity"
        L6_4 = 1
        L7_4 = nil
        function L8_4(A0_5)
          local L1_5, L2_5, L3_5, L4_5, L5_5
          if A0_5 then
            L1_5 = TriggerServerEvent
            L2_5 = Utils
            L2_5 = L2_5.eventsPrefix
            L3_5 = ":job_shop:addSupplies"
            L2_5 = L2_5 .. L3_5
            L3_5 = A0_2
            L4_5 = L2_4
            L5_5 = A0_5
            L1_5(L2_5, L3_5, L4_5, L5_5)
            L1_5 = L3_1
            L2_5 = A0_2
            L1_5(L2_5)
          else
            L1_5 = notifyClient
            L2_5 = getLocalizedText
            L3_5 = "invalid_quantity"
            L2_5, L3_5, L4_5, L5_5 = L2_5(L3_5)
            L1_5(L2_5, L3_5, L4_5, L5_5)
          end
        end
        L3_4(L4_4, L5_4, L6_4, L7_4, L8_4)
      end
    end
    function L8_3(A0_4, A1_4)
      local L2_4
      L2_4 = A1_4.close
      L2_4()
    end
    L2_3(L3_3, L4_3, L5_3, L6_3, L7_3, L8_3)
  end
  L4_2 = A0_2
  L1_2(L2_2, L3_2, L4_2)
end
function L4_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = Framework
  L1_2 = L1_2.menu
  L1_2 = L1_2()
  L1_2 = L1_2.CloseAll
  L1_2()
  L1_2 = TriggerServerCallback
  L2_2 = Utils
  L2_2 = L2_2.eventsPrefix
  L3_2 = ":canSellInThisShop"
  L2_2 = L2_2 .. L3_2
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3
    L1_3 = {}
    L2_3 = {}
    L3_3 = getLocalizedText
    L4_3 = "shop"
    L3_3 = L3_3(L4_3)
    L2_3.label = L3_3
    L2_3.value = "shop"
    L1_3[1] = L2_3
    if A0_3 then
      L2_3 = table
      L2_3 = L2_3.insert
      L3_3 = L1_3
      L4_3 = {}
      L5_3 = getLocalizedText
      L6_3 = "put_on_sale"
      L5_3 = L5_3(L6_3)
      L4_3.label = L5_3
      L4_3.value = "put_on_sale"
      L2_3(L3_3, L4_3)
      L2_3 = table
      L2_3 = L2_3.insert
      L3_3 = L1_3
      L4_3 = {}
      L5_3 = getLocalizedText
      L6_3 = "remove_from_sale"
      L5_3 = L5_3(L6_3)
      L4_3.label = L5_3
      L4_3.value = "remove_from_sale"
      L2_3(L3_3, L4_3)
      L2_3 = table
      L2_3 = L2_3.insert
      L3_3 = L1_3
      L4_3 = {}
      L5_3 = getLocalizedText
      L6_3 = "job_shop:add_supplies"
      L5_3 = L5_3(L6_3)
      L4_3.label = L5_3
      L4_3.value = "add_supplies"
      L2_3(L3_3, L4_3)
    end
    L2_3 = Framework
    L2_3 = L2_3.menu
    L2_3 = L2_3()
    L2_3 = L2_3.Open
    L3_3 = "default"
    L4_3 = GetCurrentResourceName
    L4_3 = L4_3()
    L5_3 = "job_owned_shop"
    L6_3 = {}
    L7_3 = getLocalizedText
    L8_3 = "job_owned_shop"
    L7_3 = L7_3(L8_3)
    L6_3.title = L7_3
    L7_3 = config
    L7_3 = L7_3.menuPosition
    L6_3.align = L7_3
    L6_3.elements = L1_3
    function L7_3(A0_4, A1_4)
      local L2_4, L3_4, L4_4
      L2_4 = A0_4.current
      L2_4 = L2_4.value
      if "shop" == L2_4 then
        L3_4 = L0_1
        L4_4 = A0_2
        L3_4(L4_4)
      elseif "put_on_sale" == L2_4 then
        L3_4 = L1_1
        L4_4 = A0_2
        L3_4(L4_4)
      elseif "remove_from_sale" == L2_4 then
        L3_4 = L2_1
        L4_4 = A0_2
        L3_4(L4_4)
      elseif "add_supplies" == L2_4 then
        L3_4 = L3_1
        L4_4 = A0_2
        L3_4(L4_4)
      end
    end
    function L8_3(A0_4, A1_4)
      local L2_4
      openedMenu = nil
      L2_4 = A1_4.close
      L2_4()
    end
    L2_3(L3_3, L4_3, L5_3, L6_3, L7_3, L8_3)
  end
  L4_2 = A0_2
  L1_2(L2_2, L3_2, L4_2)
end
openJobShop = L4_1

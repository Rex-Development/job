local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1
function L0_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = TriggerServerCallback
  L2_2 = Utils
  L2_2 = L2_2.eventsPrefix
  L3_2 = ":getPlayerAccounts"
  L2_2 = L2_2 .. L3_2
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L1_3 = #A0_3
    if 0 == L1_3 then
      L1_3 = table
      L1_3 = L1_3.insert
      L2_3 = A0_3
      L3_3 = {}
      L4_3 = getLocalizedText
      L5_3 = "nothing_to_deposit"
      L4_3 = L4_3(L5_3)
      L3_3.label = L4_3
      L3_3.value = "empty"
      L1_3(L2_3, L3_3)
    end
    L1_3 = Framework
    L1_3 = L1_3.menu
    L1_3 = L1_3()
    L1_3 = L1_3.Open
    L2_3 = "default"
    L3_3 = GetCurrentResourceName
    L3_3 = L3_3()
    L4_3 = "safe_deposit"
    L5_3 = {}
    L6_3 = getLocalizedText
    L7_3 = "safe"
    L6_3 = L6_3(L7_3)
    L5_3.title = L6_3
    L6_3 = config
    L6_3 = L6_3.menuPosition
    L5_3.align = L6_3
    L5_3.elements = A0_3
    function L6_3(A0_4, A1_4)
      local L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4, L9_4
      L2_4 = A0_4.current
      L2_4 = L2_4.value
      if "empty" == L2_4 then
        return
      end
      L2_4 = A0_4.current
      L2_4 = L2_4.accountName
      L3_4 = Framework
      L3_4 = L3_4.menu
      L3_4 = L3_4()
      L3_4 = L3_4.Open
      L4_4 = "dialog"
      L5_4 = GetCurrentResourceName
      L5_4 = L5_4()
      L6_4 = "safe_deposit_dialog"
      L7_4 = {}
      L8_4 = getLocalizedText
      L9_4 = "quantity"
      L8_4 = L8_4(L9_4)
      L7_4.title = L8_4
      function L8_4(A0_5, A1_5)
        local L2_5, L3_5, L4_5, L5_5, L6_5, L7_5, L8_5
        L2_5 = tonumber
        L3_5 = A0_5.value
        L2_5 = L2_5(L3_5)
        if L2_5 and L2_5 > 0 then
          L3_5 = A0_4.current
          L3_5 = L3_5.money
          if L2_5 <= L3_5 then
            L3_5 = A1_5.close
            L3_5()
            L3_5 = TriggerServerCallback
            L4_5 = Utils
            L4_5 = L4_5.eventsPrefix
            L5_5 = ":depositIntoSafe"
            L4_5 = L4_5 .. L5_5
            function L5_5(A0_6)
              local L1_6, L2_6
              if A0_6 then
                L1_6 = L0_1
                L2_6 = A0_2
                L1_6(L2_6)
              end
            end
            L6_5 = L2_4
            L7_5 = L2_5
            L8_5 = A0_2
            L3_5(L4_5, L5_5, L6_5, L7_5, L8_5)
        end
        else
          L3_5 = notifyClient
          L4_5 = getLocalizedText
          L5_5 = "invalid_quantity"
          L4_5, L5_5, L6_5, L7_5, L8_5 = L4_5(L5_5)
          L3_5(L4_5, L5_5, L6_5, L7_5, L8_5)
        end
      end
      function L9_4(A0_5, A1_5)
        local L2_5
        L2_5 = A1_5.close
        L2_5()
      end
      L3_4(L4_4, L5_4, L6_4, L7_4, L8_4, L9_4)
    end
    function L7_3(A0_4, A1_4)
      local L2_4
      openedMenu = nil
      L2_4 = A1_4.close
      L2_4()
    end
    L1_3(L2_3, L3_3, L4_3, L5_3, L6_3, L7_3)
  end
  L1_2(L2_2, L3_2)
end
function L1_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = TriggerServerCallback
  L2_2 = Utils
  L2_2 = L2_2.eventsPrefix
  L3_2 = ":retrieveReadableSafeData"
  L2_2 = L2_2 .. L3_2
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L1_3 = #A0_3
    if 0 == L1_3 then
      L1_3 = table
      L1_3 = L1_3.insert
      L2_3 = A0_3
      L3_3 = {}
      L4_3 = getLocalizedText
      L5_3 = "empty_safe"
      L4_3 = L4_3(L5_3)
      L3_3.label = L4_3
      L3_3.value = "empty"
      L1_3(L2_3, L3_3)
    end
    L1_3 = Framework
    L1_3 = L1_3.menu
    L1_3 = L1_3()
    L1_3 = L1_3.Open
    L2_3 = "default"
    L3_3 = GetCurrentResourceName
    L3_3 = L3_3()
    L4_3 = "safe_withdraw"
    L5_3 = {}
    L6_3 = getLocalizedText
    L7_3 = "safe"
    L6_3 = L6_3(L7_3)
    L5_3.title = L6_3
    L6_3 = config
    L6_3 = L6_3.menuPosition
    L5_3.align = L6_3
    L5_3.elements = A0_3
    function L6_3(A0_4, A1_4)
      local L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4, L9_4
      L2_4 = A0_4.current
      L2_4 = L2_4.value
      if "empty" == L2_4 then
        return
      end
      L2_4 = A0_4.current
      L2_4 = L2_4.accountName
      L3_4 = Framework
      L3_4 = L3_4.menu
      L3_4 = L3_4()
      L3_4 = L3_4.Open
      L4_4 = "dialog"
      L5_4 = GetCurrentResourceName
      L5_4 = L5_4()
      L6_4 = "safe_withdraw_dialog"
      L7_4 = {}
      L8_4 = getLocalizedText
      L9_4 = "quantity"
      L8_4 = L8_4(L9_4)
      L7_4.title = L8_4
      function L8_4(A0_5, A1_5)
        local L2_5, L3_5, L4_5, L5_5, L6_5, L7_5, L8_5
        L2_5 = tonumber
        L3_5 = A0_5.value
        L2_5 = L2_5(L3_5)
        if L2_5 and L2_5 > 0 then
          L3_5 = A0_4.current
          L3_5 = L3_5.money
          if L2_5 <= L3_5 then
            L3_5 = A1_5.close
            L3_5()
            L3_5 = TriggerServerCallback
            L4_5 = Utils
            L4_5 = L4_5.eventsPrefix
            L5_5 = ":withdrawFromSafe"
            L4_5 = L4_5 .. L5_5
            function L5_5(A0_6)
              local L1_6, L2_6
              if A0_6 then
                L1_6 = L1_1
                L2_6 = A0_2
                L1_6(L2_6)
              end
            end
            L6_5 = L2_4
            L7_5 = L2_5
            L8_5 = A0_2
            L3_5(L4_5, L5_5, L6_5, L7_5, L8_5)
        end
        else
          L3_5 = notifyClient
          L4_5 = getLocalizedText
          L5_5 = "invalid_quantity"
          L4_5, L5_5, L6_5, L7_5, L8_5 = L4_5(L5_5)
          L3_5(L4_5, L5_5, L6_5, L7_5, L8_5)
        end
      end
      function L9_4(A0_5, A1_5)
        local L2_5
        L2_5 = A1_5.close
        L2_5()
      end
      L3_4(L4_4, L5_4, L6_4, L7_4, L8_4, L9_4)
    end
    function L7_3(A0_4, A1_4)
      local L2_4
      openedMenu = nil
      L2_4 = A1_4.close
      L2_4()
    end
    L1_3(L2_3, L3_3, L4_3, L5_3, L6_3, L7_3)
  end
  L4_2 = A0_2
  L1_2(L2_2, L3_2, L4_2)
end
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L1_2 = {}
  L2_2 = {}
  L3_2 = getLocalizedText
  L4_2 = "deposit"
  L3_2 = L3_2(L4_2)
  L2_2.label = L3_2
  L2_2.value = "deposit"
  L3_2 = {}
  L4_2 = getLocalizedText
  L5_2 = "withdraw"
  L4_2 = L4_2(L5_2)
  L3_2.label = L4_2
  L3_2.value = "withdraw"
  L1_2[1] = L2_2
  L1_2[2] = L3_2
  L2_2 = Framework
  L2_2 = L2_2.menu
  L2_2 = L2_2()
  L2_2 = L2_2.CloseAll
  L2_2()
  L2_2 = Framework
  L2_2 = L2_2.menu
  L2_2 = L2_2()
  L2_2 = L2_2.Open
  L3_2 = "default"
  L4_2 = GetCurrentResourceName
  L4_2 = L4_2()
  L5_2 = "safe"
  L6_2 = {}
  L7_2 = getLocalizedText
  L8_2 = "safe"
  L7_2 = L7_2(L8_2)
  L6_2.title = L7_2
  L7_2 = config
  L7_2 = L7_2.menuPosition
  L6_2.align = L7_2
  L6_2.elements = L1_2
  function L7_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3
    L2_3 = A0_3.current
    L2_3 = L2_3.value
    if "deposit" == L2_3 then
      L3_3 = L0_1
      L4_3 = A0_2
      L3_3(L4_3)
    elseif "withdraw" == L2_3 then
      L3_3 = L1_1
      L4_3 = A0_2
      L3_3(L4_3)
    end
  end
  function L8_2(A0_3, A1_3)
    local L2_3
    openedMenu = nil
    L2_3 = A1_3.close
    L2_3()
  end
  L2_2(L3_2, L4_2, L5_2, L6_2, L7_2, L8_2)
end
L3_1 = addScriptRemovableEvent
L4_1 = RegisterNetEvent
L5_1 = Utils
L5_1 = L5_1.eventsPrefix
L6_1 = ":safe:openSafe"
L5_1 = L5_1 .. L6_1
L6_1 = L2_1
L4_1, L5_1, L6_1 = L4_1(L5_1, L6_1)
L3_1(L4_1, L5_1, L6_1)

local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1
function L0_1(A0_2, A1_2)
  local L2_2, L3_2
  L2_2 = A0_2.index
  L3_2 = A1_2.index
  L2_2 = L2_2 < L3_2
  return L2_2
end
function L1_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = TriggerServerCallback
  L2_2 = Utils
  L2_2 = L2_2.eventsPrefix
  L3_2 = ":boss:getJobGrades"
  L2_2 = L2_2 .. L3_2
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3
    L2_3 = {}
    L3_3 = pairs
    L4_3 = A0_3
    L3_3, L4_3, L5_3, L6_3 = L3_3(L4_3)
    for L7_3, L8_3 in L3_3, L4_3, L5_3, L6_3 do
      L9_3 = table
      L9_3 = L9_3.insert
      L10_3 = L2_3
      L11_3 = {}
      L12_3 = getLocalizedText
      L13_3 = "boss:rank_salary"
      L14_3 = L8_3.label
      L15_3 = Framework
      L15_3 = L15_3.groupDigits
      L16_3 = L8_3.salary
      L15_3, L16_3 = L15_3(L16_3)
      L12_3 = L12_3(L13_3, L14_3, L15_3, L16_3)
      L11_3.label = L12_3
      L12_3 = L8_3.id
      L11_3.gradeId = L12_3
      L12_3 = L8_3.grade
      L11_3.grade = L12_3
      L9_3(L10_3, L11_3)
    end
    L3_3 = Framework
    L3_3 = L3_3.menu
    L3_3 = L3_3()
    L3_3 = L3_3.Open
    L4_3 = "default"
    L5_3 = GetCurrentResourceName
    L5_3 = L5_3()
    L6_3 = "boss_menu_grades"
    L7_3 = {}
    L8_3 = getLocalizedText
    L9_3 = "boss_menu"
    L8_3 = L8_3(L9_3)
    L7_3.title = L8_3
    L8_3 = config
    L8_3 = L8_3.menuPosition
    L7_3.align = L8_3
    L7_3.elements = L2_3
    function L8_3(A0_4, A1_4)
      local L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4, L9_4
      L2_4 = A0_4.current
      L2_4 = L2_4.gradeId
      L3_4 = A0_4.current
      L3_4 = L3_4.grade
      if L2_4 then
        L4_4 = Framework
        L4_4 = L4_4.askQuantity
        L5_4 = getLocalizedText
        L6_4 = "boss:new_salary"
        L5_4 = L5_4(L6_4)
        L6_4 = "boss_grade_salary"
        L7_4 = 0
        L8_4 = A1_3
        function L9_4(A0_5)
          local L1_5, L2_5, L3_5, L4_5, L5_5, L6_5
          if A0_5 then
            L1_5 = TriggerServerEvent
            L2_5 = Utils
            L2_5 = L2_5.eventsPrefix
            L3_5 = ":updateGradeSalary"
            L2_5 = L2_5 .. L3_5
            L3_5 = A0_2
            L4_5 = L2_4
            L5_5 = L3_4
            L6_5 = A0_5
            L1_5(L2_5, L3_5, L4_5, L5_5, L6_5)
            L1_5 = A1_4.close
            L1_5()
          end
        end
        L4_4(L5_4, L6_4, L7_4, L8_4, L9_4)
      end
    end
    function L9_3(A0_4, A1_4)
      local L2_4
      L2_4 = A1_4.close
      L2_4()
    end
    L3_3(L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
  end
  L4_2 = A0_2
  L1_2(L2_2, L3_2, L4_2)
end
function L2_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L2_2 = {}
  L3_2 = {}
  L4_2 = getLocalizedText
  L5_2 = "boss:cancel"
  L4_2 = L4_2(L5_2)
  L3_2.label = L4_2
  L3_2.value = "no"
  L4_2 = {}
  L5_2 = getLocalizedText
  L6_2 = "boss:fire"
  L5_2 = L5_2(L6_2)
  L4_2.label = L5_2
  L4_2.value = "yes"
  L2_2[1] = L3_2
  L2_2[2] = L4_2
  L3_2 = Framework
  L3_2 = L3_2.menu
  L3_2 = L3_2()
  L3_2 = L3_2.Open
  L4_2 = "default"
  L5_2 = GetCurrentResourceName
  L5_2 = L5_2()
  L6_2 = "boss_menu_employee_fire"
  L7_2 = {}
  L8_2 = getLocalizedText
  L9_2 = "boss:are_you_sure"
  L8_2 = L8_2(L9_2)
  L7_2.title = L8_2
  L8_2 = config
  L8_2 = L8_2.menuPosition
  L7_2.align = L8_2
  L7_2.elements = L2_2
  function L8_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3, L6_3
    L2_3 = A0_3.current
    L2_3 = L2_3.value
    if "yes" == L2_3 then
      L3_3 = TriggerServerEvent
      L4_3 = Utils
      L4_3 = L4_3.eventsPrefix
      L5_3 = ":boss:fireEmployee"
      L4_3 = L4_3 .. L5_3
      L5_3 = A0_2
      L6_3 = A1_2
      L3_3(L4_3, L5_3, L6_3)
    end
    L3_3 = openBoss
    L4_3 = A0_2
    L3_3(L4_3)
  end
  function L9_2(A0_3, A1_3)
    local L2_3
    L2_3 = A1_3.close
    L2_3()
  end
  L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2)
end
function L3_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2
  L2_2 = Framework
  L2_2 = L2_2.getPlayerJob
  L2_2 = L2_2()
  L3_2 = TriggerServerCallback
  L4_2 = Utils
  L4_2 = L4_2.eventsPrefix
  L5_2 = ":retrieveJobRanks"
  L4_2 = L4_2 .. L5_2
  function L5_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3
    L1_3 = {}
    L2_3 = pairs
    L3_3 = A0_3
    L2_3, L3_3, L4_3, L5_3 = L2_3(L3_3)
    for L6_3, L7_3 in L2_3, L3_3, L4_3, L5_3 do
      L8_3 = table
      L8_3 = L8_3.insert
      L9_3 = L1_3
      L10_3 = {}
      L11_3 = getLocalizedText
      L12_3 = "boss:grade"
      L13_3 = L7_3.grade
      L14_3 = L7_3.label
      L15_3 = Framework
      L15_3 = L15_3.groupDigits
      L16_3 = L7_3.salary
      L15_3, L16_3 = L15_3(L16_3)
      L11_3 = L11_3(L12_3, L13_3, L14_3, L15_3, L16_3)
      L10_3.label = L11_3
      L11_3 = L7_3.grade
      L10_3.grade = L11_3
      L8_3(L9_3, L10_3)
    end
    L2_3 = Framework
    L2_3 = L2_3.menu
    L2_3 = L2_3()
    L2_3 = L2_3.Open
    L3_3 = "default"
    L4_3 = GetCurrentResourceName
    L4_3 = L4_3()
    L5_3 = "boss_menu_employee_change_grade"
    L6_3 = {}
    L7_3 = getLocalizedText
    L8_3 = "boss_menu"
    L7_3 = L7_3(L8_3)
    L6_3.title = L7_3
    L7_3 = config
    L7_3 = L7_3.menuPosition
    L6_3.align = L7_3
    L6_3.elements = L1_3
    function L7_3(A0_4, A1_4)
      local L2_4, L3_4, L4_4, L5_4, L6_4, L7_4
      L2_4 = A0_4.current
      L2_4 = L2_4.grade
      if L2_4 then
        L3_4 = TriggerServerEvent
        L4_4 = Utils
        L4_4 = L4_4.eventsPrefix
        L5_4 = ":boss:changeGradeToEmployee"
        L4_4 = L4_4 .. L5_4
        L5_4 = A0_2
        L6_4 = A1_2
        L7_4 = L2_4
        L3_4(L4_4, L5_4, L6_4, L7_4)
      end
      L3_4 = A1_4.close
      L3_4()
    end
    function L8_3(A0_4, A1_4)
      local L2_4
      L2_4 = A1_4.close
      L2_4()
    end
    L2_3(L3_3, L4_3, L5_3, L6_3, L7_3, L8_3)
  end
  L6_2 = L2_2
  L3_2(L4_2, L5_2, L6_2)
end
function L4_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L2_2 = {}
  L3_2 = {}
  L4_2 = getLocalizedText
  L5_2 = "boss:change_grade"
  L4_2 = L4_2(L5_2)
  L3_2.label = L4_2
  L3_2.value = "change_grade"
  L4_2 = {}
  L5_2 = getLocalizedText
  L6_2 = "boss:fire"
  L5_2 = L5_2(L6_2)
  L4_2.label = L5_2
  L4_2.value = "fire"
  L2_2[1] = L3_2
  L2_2[2] = L4_2
  L3_2 = Framework
  L3_2 = L3_2.menu
  L3_2 = L3_2()
  L3_2 = L3_2.Open
  L4_2 = "default"
  L5_2 = GetCurrentResourceName
  L5_2 = L5_2()
  L6_2 = "boss_menu_employee_management"
  L7_2 = {}
  L8_2 = getLocalizedText
  L9_2 = "boss_menu"
  L8_2 = L8_2(L9_2)
  L7_2.title = L8_2
  L8_2 = config
  L8_2 = L8_2.menuPosition
  L7_2.align = L8_2
  L7_2.elements = L2_2
  function L8_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3
    L2_3 = A0_3.current
    L2_3 = L2_3.value
    if "change_grade" == L2_3 then
      L3_3 = L3_1
      L4_3 = A0_2
      L5_3 = A1_2
      L3_3(L4_3, L5_3)
    elseif "fire" == L2_3 then
      L3_3 = L2_1
      L4_3 = A0_2
      L5_3 = A1_2
      L3_3(L4_3, L5_3)
    end
  end
  function L9_2(A0_3, A1_3)
    local L2_3
    L2_3 = A1_3.close
    L2_3()
  end
  L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2)
end
manageEmployee = L4_1
function L4_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = TriggerServerCallback
  L2_2 = Utils
  L2_2 = L2_2.eventsPrefix
  L3_2 = ":boss:getEmployeesList"
  L2_2 = L2_2 .. L3_2
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3
    L2_3 = {}
    L3_3 = pairs
    L4_3 = A0_3
    L3_3, L4_3, L5_3, L6_3 = L3_3(L4_3)
    for L7_3, L8_3 in L3_3, L4_3, L5_3, L6_3 do
      L9_3 = table
      L9_3 = L9_3.insert
      L10_3 = L2_3
      L11_3 = {}
      L12_3 = getLocalizedText
      L13_3 = "boss:employee"
      L14_3 = L8_3.firstname
      L15_3 = L8_3.lastname
      L16_3 = L8_3.job_grade
      L16_3 = A1_3[L16_3]
      L12_3 = L12_3(L13_3, L14_3, L15_3, L16_3)
      L11_3.label = L12_3
      L12_3 = L8_3.identifier
      L11_3.value = L12_3
      L9_3(L10_3, L11_3)
    end
    L3_3 = Framework
    L3_3 = L3_3.menu
    L3_3 = L3_3()
    L3_3 = L3_3.Open
    L4_3 = "default"
    L5_3 = GetCurrentResourceName
    L5_3 = L5_3()
    L6_3 = "boss_menu_employees_management"
    L7_3 = {}
    L8_3 = getLocalizedText
    L9_3 = "boss_menu"
    L8_3 = L8_3(L9_3)
    L7_3.title = L8_3
    L8_3 = config
    L8_3 = L8_3.menuPosition
    L7_3.align = L8_3
    L7_3.elements = L2_3
    function L8_3(A0_4, A1_4)
      local L2_4, L3_4, L4_4, L5_4
      L2_4 = A0_4.current
      L2_4 = L2_4.value
      L3_4 = manageEmployee
      L4_4 = A0_2
      L5_4 = L2_4
      L3_4(L4_4, L5_4)
    end
    function L9_3(A0_4, A1_4)
      local L2_4
      L2_4 = A1_4.close
      L2_4()
    end
    L3_3(L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
  end
  L4_2 = A0_2
  L1_2(L2_2, L3_2, L4_2)
end
function L5_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L1_2 = PlayerPedId
  L1_2 = L1_2()
  L2_2 = GetEntityCoords
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  L3_2 = Framework
  L3_2 = L3_2.getClosePlayers
  L4_2 = 10.0
  L5_2 = true
  L3_2 = L3_2(L4_2, L5_2)
  L4_2 = TriggerServerCallback
  L5_2 = Utils
  L5_2 = L5_2.eventsPrefix
  L6_2 = ":boss:getClosePlayersNames"
  L5_2 = L5_2 .. L6_2
  function L6_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L1_3 = #A0_3
    if 0 == L1_3 then
      L1_3 = table
      L1_3 = L1_3.insert
      L2_3 = A0_3
      L3_3 = {}
      L4_3 = getLocalizedText
      L5_3 = "boss:nobody_close"
      L4_3 = L4_3(L5_3)
      L3_3.label = L4_3
      L1_3(L2_3, L3_3)
    end
    L1_3 = Framework
    L1_3 = L1_3.menu
    L1_3 = L1_3()
    L1_3 = L1_3.Open
    L2_3 = "default"
    L3_3 = GetCurrentResourceName
    L3_3 = L3_3()
    L4_3 = "boss_menu_employees_recruit"
    L5_3 = {}
    L6_3 = getLocalizedText
    L7_3 = "boss_menu"
    L6_3 = L6_3(L7_3)
    L5_3.title = L6_3
    L6_3 = config
    L6_3 = L6_3.menuPosition
    L5_3.align = L6_3
    L5_3.elements = A0_3
    function L6_3(A0_4, A1_4)
      local L2_4, L3_4, L4_4, L5_4, L6_4
      L2_4 = A0_4.current
      L2_4 = L2_4.serverId
      if L2_4 then
        L3_4 = TriggerServerEvent
        L4_4 = Utils
        L4_4 = L4_4.eventsPrefix
        L5_4 = ":boss:recruitPlayer"
        L4_4 = L4_4 .. L5_4
        L5_4 = A0_2
        L6_4 = L2_4
        L3_4(L4_4, L5_4, L6_4)
        L3_4 = A1_4.close
        L3_4()
      end
    end
    function L7_3(A0_4, A1_4)
      local L2_4
      L2_4 = A1_4.close
      L2_4()
    end
    L1_3(L2_3, L3_3, L4_3, L5_3, L6_3, L7_3)
  end
  L7_2 = L3_2
  L4_2(L5_2, L6_2, L7_2)
end
function L6_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L1_2 = {}
  L2_2 = {}
  L3_2 = getLocalizedText
  L4_2 = "boss:employees_list"
  L3_2 = L3_2(L4_2)
  L2_2.label = L3_2
  L2_2.value = "employees"
  L3_2 = {}
  L4_2 = getLocalizedText
  L5_2 = "boss:recruit"
  L4_2 = L4_2(L5_2)
  L3_2.label = L4_2
  L3_2.value = "recruit"
  L1_2[1] = L2_2
  L1_2[2] = L3_2
  L2_2 = Framework
  L2_2 = L2_2.menu
  L2_2 = L2_2()
  L2_2 = L2_2.Open
  L3_2 = "default"
  L4_2 = GetCurrentResourceName
  L4_2 = L4_2()
  L5_2 = "boss_menu_employees"
  L6_2 = {}
  L7_2 = getLocalizedText
  L8_2 = "boss_menu"
  L7_2 = L7_2(L8_2)
  L6_2.title = L7_2
  L7_2 = config
  L7_2 = L7_2.menuPosition
  L6_2.align = L7_2
  L6_2.elements = L1_2
  function L7_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3
    L2_3 = A0_3.current
    L2_3 = L2_3.value
    if "employees" == L2_3 then
      L3_3 = L4_1
      L4_3 = A0_2
      L3_3(L4_3)
    elseif "recruit" == L2_3 then
      L3_3 = L5_1
      L4_3 = A0_2
      L3_3(L4_3)
    end
  end
  function L8_2(A0_3, A1_3)
    local L2_3
    L2_3 = A1_3.close
    L2_3()
  end
  L2_2(L3_2, L4_2, L5_2, L6_2, L7_2, L8_2)
end
function L7_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = Framework
  L1_2 = L1_2.menu
  L1_2 = L1_2()
  L1_2 = L1_2.CloseAll
  L1_2()
  L1_2 = TriggerServerCallback
  L2_2 = Utils
  L2_2 = L2_2.eventsPrefix
  L3_2 = ":getBossData"
  L2_2 = L2_2 .. L3_2
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3
    L2_3 = {}
    L3_3 = {}
    L4_3 = getLocalizedText
    L5_3 = "boss:withdraw"
    L4_3 = L4_3(L5_3)
    L3_3.label = L4_3
    L3_3.value = "withdraw"
    L3_3.index = 1
    L2_3.withdraw = L3_3
    L3_3 = {}
    L4_3 = getLocalizedText
    L5_3 = "boss:deposit"
    L4_3 = L4_3(L5_3)
    L3_3.label = L4_3
    L3_3.value = "deposit"
    L3_3.index = 2
    L2_3.deposit = L3_3
    L3_3 = {}
    L4_3 = getLocalizedText
    L5_3 = "boss:wash_money"
    L4_3 = L4_3(L5_3)
    L3_3.label = L4_3
    L3_3.value = "wash"
    L3_3.index = 5
    L2_3.wash = L3_3
    L3_3 = {}
    L4_3 = getLocalizedText
    L5_3 = "boss:grades"
    L4_3 = L4_3(L5_3)
    L3_3.label = L4_3
    L3_3.value = "grades"
    L3_3.index = 3
    L2_3.grades = L3_3
    L3_3 = {}
    L4_3 = getLocalizedText
    L5_3 = "boss:employees"
    L4_3 = L4_3(L5_3)
    L3_3.label = L4_3
    L3_3.value = "employees"
    L3_3.index = 4
    L2_3.employees = L3_3
    L3_3 = {}
    L4_3 = pairs
    L5_3 = A0_3
    L4_3, L5_3, L6_3, L7_3 = L4_3(L5_3)
    for L8_3, L9_3 in L4_3, L5_3, L6_3, L7_3 do
      if L9_3 then
        L10_3 = table
        L10_3 = L10_3.insert
        L11_3 = L3_3
        L12_3 = L2_3[L8_3]
        L10_3(L11_3, L12_3)
      end
    end
    L4_3 = table
    L4_3 = L4_3.sort
    L5_3 = L3_3
    L6_3 = L0_1
    L4_3(L5_3, L6_3)
    if A1_3 then
      L4_3 = table
      L4_3 = L4_3.insert
      L5_3 = L3_3
      L6_3 = 1
      L7_3 = {}
      L8_3 = getLocalizedText
      L9_3 = "boss:society_money"
      L10_3 = Framework
      L10_3 = L10_3.groupDigits
      L11_3 = A1_3
      L10_3, L11_3, L12_3 = L10_3(L11_3)
      L8_3 = L8_3(L9_3, L10_3, L11_3, L12_3)
      L7_3.label = L8_3
      L4_3(L5_3, L6_3, L7_3)
    end
    L4_3 = Framework
    L4_3 = L4_3.menu
    L4_3 = L4_3()
    L4_3 = L4_3.Open
    L5_3 = "default"
    L6_3 = GetCurrentResourceName
    L6_3 = L6_3()
    L7_3 = "boss_menu"
    L8_3 = {}
    L9_3 = getLocalizedText
    L10_3 = "boss_menu"
    L9_3 = L9_3(L10_3)
    L8_3.title = L9_3
    L9_3 = config
    L9_3 = L9_3.menuPosition
    L8_3.align = L9_3
    L8_3.elements = L3_3
    function L9_3(A0_4, A1_4)
      local L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4
      L2_4 = A0_4.current
      L2_4 = L2_4.value
      if "withdraw" == L2_4 then
        L3_4 = Framework
        L3_4 = L3_4.askQuantity
        L4_4 = getLocalizedText
        L5_4 = "boss:withdraw_amount"
        L4_4 = L4_4(L5_4)
        L5_4 = "boss_withdraw"
        L6_4 = 1
        L7_4 = nil
        function L8_4(A0_5)
          local L1_5, L2_5, L3_5, L4_5
          if A0_5 then
            L1_5 = TriggerServerEvent
            L2_5 = Utils
            L2_5 = L2_5.eventsPrefix
            L3_5 = ":withdrawSocietyMoney"
            L2_5 = L2_5 .. L3_5
            L3_5 = A0_2
            L4_5 = A0_5
            L1_5(L2_5, L3_5, L4_5)
            L1_5 = openBoss
            L2_5 = A0_2
            L1_5(L2_5)
          end
        end
        L3_4(L4_4, L5_4, L6_4, L7_4, L8_4)
      elseif "deposit" == L2_4 then
        L3_4 = Framework
        L3_4 = L3_4.askQuantity
        L4_4 = getLocalizedText
        L5_4 = "boss:deposit_amount"
        L4_4 = L4_4(L5_4)
        L5_4 = "boss_deposit"
        L6_4 = 1
        L7_4 = nil
        function L8_4(A0_5)
          local L1_5, L2_5, L3_5, L4_5
          if A0_5 then
            L1_5 = TriggerServerEvent
            L2_5 = Utils
            L2_5 = L2_5.eventsPrefix
            L3_5 = ":depositSocietyMoney"
            L2_5 = L2_5 .. L3_5
            L3_5 = A0_2
            L4_5 = A0_5
            L1_5(L2_5, L3_5, L4_5)
            L1_5 = openBoss
            L2_5 = A0_2
            L1_5(L2_5)
          end
        end
        L3_4(L4_4, L5_4, L6_4, L7_4, L8_4)
      elseif "grades" == L2_4 then
        L3_4 = L1_1
        L4_4 = A0_2
        L3_4(L4_4)
      elseif "employees" == L2_4 then
        L3_4 = L6_1
        L4_4 = A0_2
        L3_4(L4_4)
      elseif "wash" == L2_4 then
        L3_4 = Framework
        L3_4 = L3_4.askQuantity
        L4_4 = getLocalizedText
        L5_4 = "boss:how_much_to_wash"
        L4_4 = L4_4(L5_4)
        L5_4 = "boss_washmoney"
        L6_4 = 1
        L7_4 = nil
        function L8_4(A0_5)
          local L1_5, L2_5, L3_5, L4_5
          if A0_5 then
            L1_5 = TriggerServerEvent
            L2_5 = Utils
            L2_5 = L2_5.eventsPrefix
            L3_5 = ":washMoney"
            L2_5 = L2_5 .. L3_5
            L3_5 = A0_2
            L4_5 = A0_5
            L1_5(L2_5, L3_5, L4_5)
          end
        end
        L3_4(L4_4, L5_4, L6_4, L7_4, L8_4)
      end
    end
    function L10_3(A0_4, A1_4)
      local L2_4
      openedMenu = nil
      L2_4 = A1_4.close
      L2_4()
    end
    L4_3(L5_3, L6_3, L7_3, L8_3, L9_3, L10_3)
  end
  L4_2 = A0_2
  L1_2(L2_2, L3_2, L4_2)
end
openBoss = L7_1

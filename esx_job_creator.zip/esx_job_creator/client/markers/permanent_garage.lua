local L0_1, L1_1, L2_1, L3_1
L0_1 = "permanent_garage"
function L1_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = TriggerServerCallback
  L2_2 = Utils
  L2_2 = L2_2.eventsPrefix
  L3_2 = ":getGarageBuyableData"
  L2_2 = L2_2 .. L3_2
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3
    L1_3 = {}
    L2_3 = A0_3.vehicles
    if L2_3 then
      L2_3 = pairs
      L3_3 = A0_3.vehicles
      L2_3, L3_3, L4_3, L5_3 = L2_3(L3_3)
      for L6_3, L7_3 in L2_3, L3_3, L4_3, L5_3 do
        L8_3 = getLocalizedText
        L9_3 = "buyable_vehicle"
        L10_3 = getVehicleNameFromModel
        L11_3 = L6_3
        L10_3 = L10_3(L11_3)
        L11_3 = Framework
        L11_3 = L11_3.groupDigits
        L12_3 = L7_3
        L11_3, L12_3, L13_3 = L11_3(L12_3)
        L8_3 = L8_3(L9_3, L10_3, L11_3, L12_3, L13_3)
        L9_3 = table
        L9_3 = L9_3.insert
        L10_3 = L1_3
        L11_3 = {}
        L11_3.label = L8_3
        L11_3.value = L6_3
        L11_3.price = L7_3
        L12_3 = getVehicleNameFromModel
        L13_3 = L6_3
        L12_3 = L12_3(L13_3)
        L11_3.vehicleLabel = L12_3
        L9_3(L10_3, L11_3)
      end
    end
    L2_3 = #L1_3
    if 0 == L2_3 then
      L2_3 = table
      L2_3 = L2_3.insert
      L3_3 = L1_3
      L4_3 = {}
      L5_3 = getLocalizedText
      L6_3 = "permanent_garage:no_vehicle_to_buy"
      L5_3 = L5_3(L6_3)
      L4_3.label = L5_3
      L2_3(L3_3, L4_3)
    end
    L2_3 = Framework
    L2_3 = L2_3.menu
    L2_3 = L2_3()
    L2_3 = L2_3.Open
    L3_3 = "default"
    L4_3 = GetCurrentResourceName
    L4_3 = L4_3()
    L5_3 = "job_garage_buyable"
    L6_3 = {}
    L7_3 = getLocalizedText
    L8_3 = "garage"
    L7_3 = L7_3(L8_3)
    L6_3.title = L7_3
    L7_3 = config
    L7_3 = L7_3.menuPosition
    L6_3.align = L7_3
    L6_3.elements = L1_3
    function L7_3(A0_4, A1_4)
      local L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4, L9_4, L10_4, L11_4, L12_4, L13_4, L14_4
      L2_4 = A0_4.current
      L2_4 = L2_4.value
      if not L2_4 then
        return
      end
      L3_4 = A0_4.current
      L3_4 = L3_4.price
      L4_4 = A0_4.current
      L4_4 = L4_4.vehicleLabel
      L5_4 = Framework
      L5_4 = L5_4.menu
      L5_4 = L5_4()
      L5_4 = L5_4.Open
      L6_4 = "default"
      L7_4 = GetCurrentResourceName
      L7_4 = L7_4()
      L8_4 = "job_garage_confirm"
      L9_4 = {}
      L10_4 = getLocalizedText
      L11_4 = "are_you_sure"
      L12_4 = L4_4
      L13_4 = Framework
      L13_4 = L13_4.groupDigits
      L14_4 = L3_4
      L13_4, L14_4 = L13_4(L14_4)
      L10_4 = L10_4(L11_4, L12_4, L13_4, L14_4)
      L9_4.title = L10_4
      L10_4 = config
      L10_4 = L10_4.menuPosition
      L9_4.align = L10_4
      L10_4 = {}
      L11_4 = {}
      L12_4 = getLocalizedText
      L13_4 = "yes"
      L12_4 = L12_4(L13_4)
      L11_4.label = L12_4
      L11_4.value = "yes"
      L12_4 = {}
      L13_4 = getLocalizedText
      L14_4 = "no"
      L13_4 = L13_4(L14_4)
      L12_4.label = L13_4
      L12_4.value = "no"
      L10_4[1] = L11_4
      L10_4[2] = L12_4
      L9_4.elements = L10_4
      function L10_4(A0_5, A1_5)
        local L2_5, L3_5, L4_5, L5_5
        L2_5 = A0_5.current
        L2_5 = L2_5.value
        if "yes" == L2_5 then
          L2_5 = TriggerServerEvent
          L3_5 = Utils
          L3_5 = L3_5.eventsPrefix
          L4_5 = ":buyVehicleFromGarage"
          L3_5 = L3_5 .. L4_5
          L4_5 = A0_2
          L5_5 = L2_4
          L2_5(L3_5, L4_5, L5_5)
        end
        L2_5 = A1_5.close
        L2_5()
      end
      function L11_4(A0_5, A1_5)
        local L2_5
        openedMenu = nil
        L2_5 = A1_5.close
        L2_5()
      end
      L5_4(L6_4, L7_4, L8_4, L9_4, L10_4, L11_4)
    end
    function L8_3(A0_4, A1_4)
      local L2_4
      openedMenu = nil
      L2_4 = A1_4.close
      L2_4()
    end
    L2_3(L3_3, L4_3, L5_3, L6_3, L7_3, L8_3)
  end
  L4_2 = A0_2
  L1_2(L2_2, L3_2, L4_2)
end
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2
  L1_2 = PlayerPedId
  L1_2 = L1_2()
  L2_2 = TriggerServerCallback
  L3_2 = Utils
  L3_2 = L3_2.eventsPrefix
  L4_2 = ":getGarageOwnedVehicles"
  L3_2 = L3_2 .. L4_2
  function L4_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3
    L1_3 = {}
    L2_3 = A0_3.vehicles
    if L2_3 then
      L3_3 = pairs
      L4_3 = L2_3
      L3_3, L4_3, L5_3, L6_3 = L3_3(L4_3)
      for L7_3, L8_3 in L3_3, L4_3, L5_3, L6_3 do
        L9_3 = L8_3.vehicle
        L10_3 = getVehicleNameFromModel
        L11_3 = L9_3
        L10_3 = L10_3(L11_3)
        L11_3 = L8_3.plate
        if L11_3 then
          L11_3 = L10_3
          L12_3 = " - "
          L13_3 = L8_3.plate
          L11_3 = L11_3 .. L12_3 .. L13_3
          L10_3 = L11_3
        end
        L11_3 = L8_3.isOutside
        if L11_3 then
          L11_3 = getLocalizedText
          L12_3 = "buyable_vehicle:outside"
          L13_3 = L10_3
          L11_3 = L11_3(L12_3, L13_3)
          L10_3 = L11_3
        end
        L11_3 = table
        L11_3 = L11_3.insert
        L12_3 = L1_3
        L13_3 = {}
        L13_3.label = L10_3
        L13_3.vehicleName = L9_3
        L14_3 = L8_3.vehicleId
        L13_3.vehicleId = L14_3
        L14_3 = L8_3.vehicleProps
        L13_3.vehicleProps = L14_3
        L14_3 = L8_3.plate
        L13_3.vehiclePlate = L14_3
        L14_3 = L8_3.isOutside
        L13_3.isOutside = L14_3
        L11_3(L12_3, L13_3)
      end
    end
    L3_3 = #L1_3
    if 0 == L3_3 then
      L3_3 = table
      L3_3 = L3_3.insert
      L4_3 = L1_3
      L5_3 = {}
      L6_3 = getLocalizedText
      L7_3 = "no_vehicles_in_garage"
      L6_3 = L6_3(L7_3)
      L5_3.label = L6_3
      L3_3(L4_3, L5_3)
    end
    L3_3 = Framework
    L3_3 = L3_3.menu
    L3_3 = L3_3()
    L3_3 = L3_3.Open
    L4_3 = "default"
    L5_3 = GetCurrentResourceName
    L5_3 = L5_3()
    L6_3 = "job_garage_owned"
    L7_3 = {}
    L8_3 = getLocalizedText
    L9_3 = "garage"
    L8_3 = L8_3(L9_3)
    L7_3.title = L8_3
    L8_3 = config
    L8_3 = L8_3.menuPosition
    L7_3.align = L8_3
    L7_3.elements = L1_3
    function L8_3(A0_4, A1_4)
      local L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4, L9_4, L10_4, L11_4, L12_4, L13_4, L14_4, L15_4
      L2_4 = A0_4.current
      L2_4 = L2_4.vehicleName
      if not L2_4 then
        return
      end
      L3_4 = A0_4.current
      L3_4 = L3_4.isOutside
      if L3_4 then
        L3_4 = notifyClient
        L4_4 = getLocalizedText
        L5_4 = "vehicle_outside"
        L4_4, L5_4, L6_4, L7_4, L8_4, L9_4, L10_4, L11_4, L12_4, L13_4, L14_4, L15_4 = L4_4(L5_4)
        L3_4(L4_4, L5_4, L6_4, L7_4, L8_4, L9_4, L10_4, L11_4, L12_4, L13_4, L14_4, L15_4)
        return
      end
      L3_4 = A0_4.current
      L3_4 = L3_4.vehicleProps
      L4_4 = A0_4.current
      L4_4 = L4_4.vehicleId
      L5_4 = A0_4.current
      L5_4 = L5_4.vehiclePlate
      L6_4 = vector3
      L7_4 = tonumber
      L8_4 = A0_3.spawnCoords
      L8_4 = L8_4.x
      L7_4 = L7_4(L8_4)
      L8_4 = tonumber
      L9_4 = A0_3.spawnCoords
      L9_4 = L9_4.y
      L8_4 = L8_4(L9_4)
      L9_4 = tonumber
      L10_4 = A0_3.spawnCoords
      L10_4 = L10_4.z
      L9_4, L10_4, L11_4, L12_4, L13_4, L14_4, L15_4 = L9_4(L10_4)
      L6_4 = L6_4(L7_4, L8_4, L9_4, L10_4, L11_4, L12_4, L13_4, L14_4, L15_4)
      L7_4 = RequestModel
      L8_4 = L2_4
      L7_4(L8_4)
      while true do
        L7_4 = HasModelLoaded
        L8_4 = L2_4
        L7_4 = L7_4(L8_4)
        if L7_4 then
          break
        end
        L7_4 = Citizen
        L7_4 = L7_4.Wait
        L8_4 = 0
        L7_4(L8_4)
      end
      L7_4 = CreateVehicle
      L8_4 = L2_4
      L9_4 = L6_4
      L10_4 = A0_3.heading
      L11_4 = true
      L12_4 = false
      L7_4 = L7_4(L8_4, L9_4, L10_4, L11_4, L12_4)
      L8_4 = SetEntityAsMissionEntity
      L9_4 = L7_4
      L10_4 = true
      L11_4 = true
      L8_4(L9_4, L10_4, L11_4)
      L8_4 = Framework
      L8_4 = L8_4.setVehicleProperties
      L9_4 = L7_4
      L10_4 = L3_4
      L8_4(L9_4, L10_4)
      if L5_4 then
        L8_4 = SetVehicleNumberPlateText
        L9_4 = L7_4
        L10_4 = L5_4
        L8_4(L9_4, L10_4)
      end
      L8_4 = TaskEnterVehicle
      L9_4 = L1_2
      L10_4 = L7_4
      L11_4 = 1000
      L12_4 = -1
      L13_4 = 2.0
      L14_4 = 16
      L15_4 = 0
      L8_4(L9_4, L10_4, L11_4, L12_4, L13_4, L14_4, L15_4)
      L8_4 = TriggerServerEvent
      L9_4 = Utils
      L9_4 = L9_4.eventsPrefix
      L10_4 = ":permanent_garage:vehicleIdSpawned"
      L9_4 = L9_4 .. L10_4
      L10_4 = L4_4
      L11_4 = VehToNet
      L12_4 = L7_4
      L11_4, L12_4, L13_4, L14_4, L15_4 = L11_4(L12_4)
      L8_4(L9_4, L10_4, L11_4, L12_4, L13_4, L14_4, L15_4)
      L8_4 = TriggerEvent
      L9_4 = Utils
      L9_4 = L9_4.eventsPrefix
      L10_4 = ":permanent_garage:vehicleSpawned"
      L9_4 = L9_4 .. L10_4
      L10_4 = L7_4
      L11_4 = L2_4
      L12_4 = GetVehicleNumberPlateText
      L13_4 = L7_4
      L12_4, L13_4, L14_4, L15_4 = L12_4(L13_4)
      L8_4(L9_4, L10_4, L11_4, L12_4, L13_4, L14_4, L15_4)
      L8_4 = addVehicleToOutsideVehicles
      L9_4 = L0_1
      L10_4 = L7_4
      L8_4(L9_4, L10_4)
      openedMenu = nil
      L8_4 = Framework
      L8_4 = L8_4.menu
      L8_4 = L8_4()
      L8_4 = L8_4.CloseAll
      L8_4()
    end
    function L9_3(A0_4, A1_4)
      local L2_4
      openedMenu = nil
      L2_4 = A1_4.close
      L2_4()
    end
    L3_3(L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
  end
  L5_2 = A0_2
  L2_2(L3_2, L4_2, L5_2)
end
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L1_2 = PlayerPedId
  L1_2 = L1_2()
  L2_2 = Framework
  L2_2 = L2_2.menu
  L2_2 = L2_2()
  L2_2 = L2_2.CloseAll
  L2_2()
  L2_2 = {}
  L3_2 = {}
  L4_2 = getLocalizedText
  L5_2 = "park_vehicle"
  L4_2 = L4_2(L5_2)
  L3_2.label = L4_2
  L3_2.value = "deposit"
  L4_2 = {}
  L5_2 = getLocalizedText
  L6_2 = "garage"
  L5_2 = L5_2(L6_2)
  L4_2.label = L5_2
  L4_2.value = "garage"
  L5_2 = {}
  L6_2 = getLocalizedText
  L7_2 = "buy_vehicle"
  L6_2 = L6_2(L7_2)
  L5_2.label = L6_2
  L5_2.value = "buy"
  L2_2[1] = L3_2
  L2_2[2] = L4_2
  L2_2[3] = L5_2
  L3_2 = Framework
  L3_2 = L3_2.menu
  L3_2 = L3_2()
  L3_2 = L3_2.Open
  L4_2 = "default"
  L5_2 = GetCurrentResourceName
  L5_2 = L5_2()
  L6_2 = "job_garage_options"
  L7_2 = {}
  L8_2 = getLocalizedText
  L9_2 = "garage"
  L8_2 = L8_2(L9_2)
  L7_2.title = L8_2
  L8_2 = config
  L8_2 = L8_2.menuPosition
  L7_2.align = L8_2
  L7_2.elements = L2_2
  function L8_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3
    L2_3 = A0_3.current
    L2_3 = L2_3.value
    if "buy" == L2_3 then
      L3_3 = L1_1
      L4_3 = A0_2
      L3_3(L4_3)
    elseif "garage" == L2_3 then
      L3_3 = L2_1
      L4_3 = A0_2
      L3_3(L4_3)
    elseif "deposit" == L2_3 then
      L3_3 = IsPedInAnyVehicle
      L4_3 = L1_2
      L5_3 = false
      L3_3 = L3_3(L4_3, L5_3)
      if L3_3 then
        L3_3 = GetVehiclePedIsIn
        L4_3 = L1_2
        L5_3 = false
        L3_3 = L3_3(L4_3, L5_3)
        if L3_3 then
          goto lbl_32
        end
      end
      L3_3 = getOutsideVehicleInRange
      L4_3 = L0_1
      L3_3 = L3_3(L4_3)
      ::lbl_32::
      L4_3 = DoesEntityExist
      L5_3 = L3_3
      L4_3 = L4_3(L5_3)
      if L4_3 then
        L4_3 = Framework
        L4_3 = L4_3.getVehicleProperties
        L5_3 = L3_3
        L4_3 = L4_3(L5_3)
        L5_3 = GetVehicleNumberPlateText
        L6_3 = L3_3
        L5_3 = L5_3(L6_3)
        L6_3 = GetEntityModel
        L7_3 = L3_3
        L6_3 = L6_3(L7_3)
        L7_3 = TriggerServerCallback
        L8_3 = Utils
        L8_3 = L8_3.eventsPrefix
        L9_3 = ":permanent_garage:updateVehicleProps"
        L8_3 = L8_3 .. L9_3
        function L9_3(A0_4)
          local L1_4, L2_4, L3_4, L4_4
          if A0_4 then
            L1_4 = deleteVehicleFromOutsideVehicles
            L2_4 = L0_1
            L3_4 = L3_3
            L1_4(L2_4, L3_4)
            L1_4 = TriggerEvent
            L2_4 = Utils
            L2_4 = L2_4.eventsPrefix
            L3_4 = ":permanent_garage:vehicleParked"
            L2_4 = L2_4 .. L3_4
            L3_4 = L6_3
            L4_4 = L5_3
            L1_4(L2_4, L3_4, L4_4)
            openedMenu = nil
            L1_4 = A1_3.close
            L1_4()
          end
        end
        L10_3 = A0_2
        L11_3 = VehToNet
        L12_3 = L3_3
        L11_3 = L11_3(L12_3)
        L12_3 = L4_3
        L13_3 = L5_3
        L7_3(L8_3, L9_3, L10_3, L11_3, L12_3, L13_3)
      else
        L4_3 = notifyClient
        L5_3 = getLocalizedText
        L6_3 = "no_car_found"
        L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3 = L5_3(L6_3)
        L4_3(L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3)
      end
    end
  end
  function L9_2(A0_3, A1_3)
    local L2_3
    openedMenu = nil
    L2_3 = A1_3.close
    L2_3()
  end
  L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2)
end
openGarageBuyable = L3_1

local L0_1, L1_1, L2_1, L3_1
function L0_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = TriggerServerCallback
  L2_2 = Utils
  L2_2 = L2_2.eventsPrefix
  L3_2 = ":getCraftingTableData"
  L2_2 = L2_2 .. L3_2
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L1_3 = Framework
    L1_3 = L1_3.menu
    L1_3 = L1_3()
    L1_3 = L1_3.CloseAll
    L1_3()
    L1_3 = #A0_3
    if 0 == L1_3 then
      L1_3 = table
      L1_3 = L1_3.insert
      L2_3 = A0_3
      L3_3 = {}
      L4_3 = getLocalizedText
      L5_3 = "crafting_table:nothing_to_craft"
      L4_3 = L4_3(L5_3)
      L3_3.label = L4_3
      L1_3(L2_3, L3_3)
    end
    L1_3 = Framework
    L1_3 = L1_3.menu
    L1_3 = L1_3()
    L1_3 = L1_3.Open
    L2_3 = "default"
    L3_3 = GetCurrentResourceName
    L3_3 = L3_3()
    L4_3 = "crafting_table"
    L5_3 = {}
    L6_3 = getLocalizedText
    L7_3 = "crafting_table"
    L6_3 = L6_3(L7_3)
    L5_3.title = L6_3
    L6_3 = config
    L6_3 = L6_3.menuPosition
    L5_3.align = L6_3
    L5_3.elements = A0_3
    function L6_3(A0_4, A1_4)
      local L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4, L9_4, L10_4
      L2_4 = A0_4.current
      L2_4 = L2_4.itemName
      if not L2_4 then
        return
      end
      L3_4 = Framework
      L3_4 = L3_4.menu
      L3_4 = L3_4()
      L3_4 = L3_4.Open
      L4_4 = "default"
      L5_4 = GetCurrentResourceName
      L5_4 = L5_4()
      L6_4 = "crafting_table_recipe"
      L7_4 = {}
      L8_4 = getLocalizedText
      L9_4 = "crafting_table"
      L8_4 = L8_4(L9_4)
      L7_4.title = L8_4
      L8_4 = config
      L8_4 = L8_4.menuPosition
      L7_4.align = L8_4
      L8_4 = A0_4.current
      L8_4 = L8_4.recipeElements
      L7_4.elements = L8_4
      function L8_4(A0_5, A1_5)
        local L2_5, L3_5, L4_5, L5_5, L6_5, L7_5
        L2_5 = A0_5.current
        L2_5 = L2_5.type
        if "slider" == L2_5 then
          L2_5 = A0_5.current
          L2_5 = L2_5.value
          L3_5 = TriggerServerEvent
          L4_5 = Utils
          L4_5 = L4_5.eventsPrefix
          L5_5 = ":craftItem"
          L4_5 = L4_5 .. L5_5
          L5_5 = A0_2
          L6_5 = L2_4
          L7_5 = L2_5
          L3_5(L4_5, L5_5, L6_5, L7_5)
          openedMenu = nil
          L3_5 = Framework
          L3_5 = L3_5.menu
          L3_5 = L3_5()
          L3_5 = L3_5.CloseAll
          L3_5()
        end
      end
      function L9_4(A0_5, A1_5)
        local L2_5
        openedMenu = nil
        L2_5 = A1_5.close
        L2_5()
      end
      function L10_4(A0_5, A1_5)
        local L2_5, L3_5, L4_5, L5_5, L6_5, L7_5, L8_5, L9_5, L10_5, L11_5, L12_5, L13_5, L14_5, L15_5, L16_5
        L2_5 = A0_5.current
        L2_5 = L2_5.type
        if "slider" == L2_5 then
          L2_5 = {}
          L3_5 = pairs
          L4_5 = A0_5.elements
          L3_5, L4_5, L5_5, L6_5 = L3_5(L4_5)
          for L7_5, L8_5 in L3_5, L4_5, L5_5, L6_5 do
            L9_5 = L8_5.type
            if "default" == L9_5 then
              L9_5 = "green"
              L10_5 = L8_5.quantity
              L11_5 = A0_5.current
              L11_5 = L11_5.value
              L10_5 = L10_5 * L11_5
              L11_5 = L8_5.itemQuantity
              if L10_5 > L11_5 then
                L9_5 = "orange"
              end
              L11_5 = getLocalizedText
              L12_5 = "ingredient"
              L13_5 = L8_5.itemLabel
              L14_5 = L9_5
              L15_5 = L8_5.itemQuantity
              L16_5 = L10_5
              L11_5 = L11_5(L12_5, L13_5, L14_5, L15_5, L16_5)
              L12_5 = A1_5.setElement
              L13_5 = L7_5
              L14_5 = "label"
              L15_5 = L11_5
              L12_5(L13_5, L14_5, L15_5)
            end
          end
          L3_5 = A1_5.refresh
          L3_5()
        end
      end
      L3_4(L4_4, L5_4, L6_4, L7_4, L8_4, L9_4, L10_4)
    end
    function L7_3(A0_4, A1_4)
      local L2_4
      openedMenu = nil
      L2_4 = A1_4.close
      L2_4()
    end
    L1_3(L2_3, L3_3, L4_3, L5_3, L6_3, L7_3)
  end
  L4_2 = A0_2
  L1_2(L2_2, L3_2, L4_2)
end
openCraftingTable = L0_1
function L0_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L2_2 = startProgressBar
  L3_2 = A0_2
  L4_2 = A1_2
  L2_2(L3_2, L4_2)
  L2_2 = true
  L3_2 = SetTimeout
  L4_2 = A0_2
  function L5_2()
    local L0_3, L1_3
    L0_3 = L2_2
    if L0_3 then
      L0_3 = false
      L2_2 = L0_3
    end
  end
  L3_2(L4_2, L5_2)
  L3_2 = false
  while L2_2 do
    L4_2 = DisableControlAction
    L5_2 = 0
    L6_2 = 24
    L7_2 = true
    L4_2(L5_2, L6_2, L7_2)
    L4_2 = DisableControlAction
    L5_2 = 0
    L6_2 = 257
    L7_2 = true
    L4_2(L5_2, L6_2, L7_2)
    L4_2 = DisableControlAction
    L5_2 = 0
    L6_2 = 263
    L7_2 = true
    L4_2(L5_2, L6_2, L7_2)
    L4_2 = DisableControlAction
    L5_2 = 0
    L6_2 = 32
    L7_2 = true
    L4_2(L5_2, L6_2, L7_2)
    L4_2 = DisableControlAction
    L5_2 = 0
    L6_2 = 34
    L7_2 = true
    L4_2(L5_2, L6_2, L7_2)
    L4_2 = DisableControlAction
    L5_2 = 0
    L6_2 = 31
    L7_2 = true
    L4_2(L5_2, L6_2, L7_2)
    L4_2 = DisableControlAction
    L5_2 = 0
    L6_2 = 30
    L7_2 = true
    L4_2(L5_2, L6_2, L7_2)
    L4_2 = DisableControlAction
    L5_2 = 0
    L6_2 = 45
    L7_2 = true
    L4_2(L5_2, L6_2, L7_2)
    L4_2 = DisableControlAction
    L5_2 = 0
    L6_2 = 22
    L7_2 = true
    L4_2(L5_2, L6_2, L7_2)
    L4_2 = DisableControlAction
    L5_2 = 0
    L6_2 = 44
    L7_2 = true
    L4_2(L5_2, L6_2, L7_2)
    L4_2 = DisableControlAction
    L5_2 = 0
    L6_2 = 37
    L7_2 = true
    L4_2(L5_2, L6_2, L7_2)
    L4_2 = DisableControlAction
    L5_2 = 0
    L6_2 = 23
    L7_2 = true
    L4_2(L5_2, L6_2, L7_2)
    L4_2 = DisableControlAction
    L5_2 = 0
    L6_2 = 59
    L7_2 = true
    L4_2(L5_2, L6_2, L7_2)
    L4_2 = DisableControlAction
    L5_2 = 0
    L6_2 = 71
    L7_2 = true
    L4_2(L5_2, L6_2, L7_2)
    L4_2 = DisableControlAction
    L5_2 = 0
    L6_2 = 72
    L7_2 = true
    L4_2(L5_2, L6_2, L7_2)
    L4_2 = DisableControlAction
    L5_2 = 0
    L6_2 = 36
    L7_2 = true
    L4_2(L5_2, L6_2, L7_2)
    L4_2 = DisableControlAction
    L5_2 = 0
    L6_2 = 47
    L7_2 = true
    L4_2(L5_2, L6_2, L7_2)
    L4_2 = DisableControlAction
    L5_2 = 0
    L6_2 = 264
    L7_2 = true
    L4_2(L5_2, L6_2, L7_2)
    L4_2 = DisableControlAction
    L5_2 = 0
    L6_2 = 257
    L7_2 = true
    L4_2(L5_2, L6_2, L7_2)
    L4_2 = DisableControlAction
    L5_2 = 0
    L6_2 = 140
    L7_2 = true
    L4_2(L5_2, L6_2, L7_2)
    L4_2 = DisableControlAction
    L5_2 = 0
    L6_2 = 141
    L7_2 = true
    L4_2(L5_2, L6_2, L7_2)
    L4_2 = DisableControlAction
    L5_2 = 0
    L6_2 = 142
    L7_2 = true
    L4_2(L5_2, L6_2, L7_2)
    L4_2 = DisableControlAction
    L5_2 = 0
    L6_2 = 143
    L7_2 = true
    L4_2(L5_2, L6_2, L7_2)
    L4_2 = DisableControlAction
    L5_2 = 0
    L6_2 = 75
    L7_2 = true
    L4_2(L5_2, L6_2, L7_2)
    if not L3_2 then
      L4_2 = showHelpNotification
      L5_2 = getLocalizedText
      L6_2 = "press_to_stop"
      L5_2, L6_2, L7_2 = L5_2(L6_2)
      L4_2(L5_2, L6_2, L7_2)
      L4_2 = IsControlJustReleased
      L5_2 = 0
      L6_2 = 38
      L4_2 = L4_2(L5_2, L6_2)
      if L4_2 then
        L4_2 = TriggerServerEvent
        L5_2 = Utils
        L5_2 = L5_2.eventsPrefix
        L6_2 = ":stopCrafting"
        L5_2 = L5_2 .. L6_2
        L4_2(L5_2)
        L4_2 = notifyClient
        L5_2 = getLocalizedText
        L6_2 = "you_stopped"
        L5_2, L6_2, L7_2 = L5_2(L6_2)
        L4_2(L5_2, L6_2, L7_2)
        L3_2 = true
      end
    end
    L4_2 = Citizen
    L4_2 = L4_2.Wait
    L5_2 = 0
    L4_2(L5_2)
  end
end
L1_1 = RegisterNetEvent
L2_1 = Utils
L2_1 = L2_1.eventsPrefix
L3_1 = ":crafting_table:startCrafting"
L2_1 = L2_1 .. L3_1
L3_1 = L0_1
L1_1(L2_1, L3_1)

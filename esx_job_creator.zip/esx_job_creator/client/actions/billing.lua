local L0_1, L1_1, L2_1, L3_1, L4_1
function L0_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L0_2 = EXTERNAL_SCRIPTS_NAMES
  L0_2 = L0_2.billing_ui
  if L0_2 then
    L1_2 = GetResourceState
    L2_2 = L0_2
    L1_2 = L1_2(L2_2)
    if "started" == L1_2 then
      L1_2 = Framework
      L1_2 = L1_2.menu
      L1_2 = L1_2()
      L1_2 = L1_2.CloseAll
      L1_2()
      L1_2 = TriggerEvent
      L2_2 = "billing_ui:activateBillingMode"
      L1_2(L2_2)
  end
  else
    L1_2 = ""
    L2_2 = Framework
    L2_2 = L2_2.getFramework
    L2_2 = L2_2()
    if "ESX" == L2_2 then
      L2_2 = Framework
      L2_2 = L2_2.askInput
      L3_2 = getLocalizedText
      L4_2 = "billing_reason"
      L3_2 = L3_2(L4_2)
      L4_2 = "create_billing"
      L2_2 = L2_2(L3_2, L4_2)
      L1_2 = L2_2
    end
    L2_2 = Framework
    L2_2 = L2_2.askQuantity
    L3_2 = getLocalizedText
    L4_2 = "billing_amount"
    L3_2 = L3_2(L4_2)
    L4_2 = "create_billing"
    L5_2 = 1
    L6_2 = nil
    function L7_2(A0_3)
      local L1_3, L2_3, L3_3, L4_3
      if A0_3 then
        L1_3 = L1_2
        if L1_3 then
          L1_3 = Framework
          L1_3 = L1_3.getClosestPlayer
          L2_3 = true
          L3_3 = 4.0
          L1_3 = L1_3(L2_3, L3_3)
          if L1_3 then
            L2_3 = TriggerServerCallback
            L3_3 = Utils
            L3_3 = L3_3.eventsPrefix
            L4_3 = ":getJobInfo"
            L3_3 = L3_3 .. L4_3
            function L4_3(A0_4, A1_4)
              local L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4
              L2_4 = Framework
              L2_4 = L2_4.getFramework
              L2_4 = L2_4()
              if "ESX" == L2_4 then
                L2_4 = TriggerServerEvent
                L3_4 = EXTERNAL_EVENTS_NAMES
                L3_4 = L3_4["esx_billing:sendBill"]
                L4_4 = L1_3
                L5_4 = "society_"
                L6_4 = A0_4
                L5_4 = L5_4 .. L6_4
                L6_4 = A1_4
                L7_4 = " - "
                L8_4 = L1_2
                L6_4 = L6_4 .. L7_4 .. L8_4
                L7_4 = A0_3
                L2_4(L3_4, L4_4, L5_4, L6_4, L7_4)
              else
                L2_4 = Framework
                L2_4 = L2_4.getFramework
                L2_4 = L2_4()
                if "QB-core" == L2_4 then
                  L2_4 = ExecuteCommand
                  L3_4 = "bill "
                  L4_4 = L1_3
                  L5_4 = " "
                  L6_4 = A0_3
                  L3_4 = L3_4 .. L4_4 .. L5_4 .. L6_4
                  L2_4(L3_4)
                end
              end
              L2_4 = notifyClient
              L3_4 = getLocalizedText
              L4_4 = "invoice_sent"
              L5_4 = Framework
              L5_4 = L5_4.groupDigits
              L6_4 = A0_3
              L5_4, L6_4, L7_4, L8_4 = L5_4(L6_4)
              L3_4, L4_4, L5_4, L6_4, L7_4, L8_4 = L3_4(L4_4, L5_4, L6_4, L7_4, L8_4)
              L2_4(L3_4, L4_4, L5_4, L6_4, L7_4, L8_4)
            end
            L2_3(L3_3, L4_3)
          else
            L2_3 = notifyClient
            L3_3 = getLocalizedText
            L4_3 = "no_players_nearby"
            L3_3, L4_3 = L3_3(L4_3)
            L2_3(L3_3, L4_3)
          end
        end
      end
    end
    L2_2(L3_2, L4_2, L5_2, L6_2, L7_2)
  end
end
L1_1 = addScriptRemovableEvent
L2_1 = RegisterNetEvent
L3_1 = Utils
L3_1 = L3_1.eventsPrefix
L4_1 = ":actions:createBilling"
L3_1 = L3_1 .. L4_1
L4_1 = L0_1
L2_1, L3_1, L4_1 = L2_1(L3_1, L4_1)
L1_1(L2_1, L3_1, L4_1)

local L0_1, L1_1, L2_1, L3_1, L4_1
function L0_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = GetVehicleDoorLockStatus
  L2_2 = A0_2
  L1_2 = L1_2(L2_2)
  L2_2 = GetVehicleDoorsLockedForPlayer
  L3_2 = A0_2
  L2_2 = 2 == L1_2 or 3 == L1_2 or L2_2
  return L2_2
end
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
  L0_2 = PlayerPedId
  L0_2 = L0_2()
  L1_2 = GetEntityCoords
  L2_2 = L0_2
  L1_2 = L1_2(L2_2)
  L2_2 = Framework
  L2_2 = L2_2.getClosestVehicle
  L3_2 = 2.0
  L2_2 = L2_2(L3_2)
  if L2_2 then
    L3_2 = L0_1
    L4_2 = L2_2
    L3_2 = L3_2(L4_2)
    if L3_2 then
      L3_2 = TriggerServerCallback
      L4_2 = Utils
      L4_2 = L4_2.eventsPrefix
      L5_2 = ":canLockpickVehicle"
      L4_2 = L4_2 .. L5_2
      function L5_2(A0_3)
        local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
        if A0_3 then
          L1_3 = config
          L1_3 = L1_3.carLockpickTime
          L1_3 = L1_3 * 1000
          L2_3 = TaskEnterVehicle
          L3_3 = L0_2
          L4_3 = L2_2
          L5_3 = 2000
          L6_3 = -1
          L7_3 = 1.0
          L8_3 = 1
          L9_3 = 0
          L2_3(L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
          L2_3 = Citizen
          L2_3 = L2_3.Wait
          L3_3 = 2000
          L2_3(L3_3)
          L2_3 = startProgressBar
          L3_3 = L1_3
          L4_3 = getLocalizedText
          L5_3 = "actions:lockpick:lockpickingVehicle"
          L4_3, L5_3, L6_3, L7_3, L8_3, L9_3 = L4_3(L5_3)
          L2_3(L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
          L2_3 = TaskStartScenarioInPlace
          L3_3 = L0_2
          L4_3 = "PROP_HUMAN_BUM_BIN"
          L5_3 = 0
          L6_3 = true
          L2_3(L3_3, L4_3, L5_3, L6_3)
          L2_3 = config
          L2_3 = L2_3.enableAlarmWhenLockpicking
          if L2_3 then
            L2_3 = SetVehicleAlarm
            L3_3 = L2_2
            L4_3 = true
            L2_3(L3_3, L4_3)
            L2_3 = SetVehicleAlarmTimeLeft
            L3_3 = L2_2
            L4_3 = L1_3
            L2_3(L3_3, L4_3)
            L2_3 = StartVehicleAlarm
            L3_3 = L2_2
            L2_3(L3_3)
          end
          L2_3 = Citizen
          L2_3 = L2_3.Wait
          L3_3 = L1_3
          L2_3(L3_3)
          L2_3 = ClearPedTasks
          L3_3 = L0_2
          L2_3(L3_3)
          L2_3 = SetVehicleDoorsLockedForAllPlayers
          L3_3 = L2_2
          L4_3 = false
          L2_3(L3_3, L4_3)
          L2_3 = SetVehicleDoorsLocked
          L3_3 = L2_2
          L4_3 = 1
          L2_3(L3_3, L4_3)
        else
          L1_3 = notifyClient
          L2_3 = getLocalizedText
          L3_3 = "you_need_lockpick"
          L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3 = L2_3(L3_3)
          L1_3(L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3)
        end
      end
      L3_2(L4_2, L5_2)
    else
      L3_2 = notifyClient
      L4_2 = getLocalizedText
      L5_2 = "not_locked_vehicle"
      L4_2, L5_2 = L4_2(L5_2)
      L3_2(L4_2, L5_2)
    end
  else
    L3_2 = notifyClient
    L4_2 = getLocalizedText
    L5_2 = "no_car_found"
    L4_2, L5_2 = L4_2(L5_2)
    L3_2(L4_2, L5_2)
  end
end
L2_1 = RegisterNetEvent
L3_1 = Utils
L3_1 = L3_1.eventsPrefix
L4_1 = ":actions:lockpickCar"
L3_1 = L3_1 .. L4_1
L4_1 = L1_1
L2_1(L3_1, L4_1)

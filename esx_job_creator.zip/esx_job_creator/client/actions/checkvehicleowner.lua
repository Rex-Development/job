local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1
L0_1 = 6000
L1_1 = "prop_cs_tablet"
L2_1 = "amb@code_human_in_bus_passenger_idles@female@tablet@base"
L3_1 = "base"
function L4_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2
  L0_2 = PlayerPedId
  L0_2 = L0_2()
  L1_2 = GetEntityCoords
  L2_2 = L0_2
  L1_2 = L1_2(L2_2)
  L2_2 = Framework
  L2_2 = L2_2.getClosestVehicle
  L3_2 = 3.0
  L2_2 = L2_2(L3_2)
  if L2_2 then
    while true do
      L3_2 = HasAnimDictLoaded
      L4_2 = L2_1
      L3_2 = L3_2(L4_2)
      if L3_2 then
        break
      end
      L3_2 = Citizen
      L3_2 = L3_2.Wait
      L4_2 = 0
      L3_2(L4_2)
      L3_2 = RequestAnimDict
      L4_2 = L2_1
      L3_2(L4_2)
    end
    while true do
      L3_2 = HasModelLoaded
      L4_2 = L1_1
      L3_2 = L3_2(L4_2)
      if L3_2 then
        break
      end
      L3_2 = Citizen
      L3_2 = L3_2.Wait
      L4_2 = 0
      L3_2(L4_2)
      L3_2 = RequestModel
      L4_2 = L1_1
      L3_2(L4_2)
    end
    L3_2 = CreateObject
    L4_2 = L1_1
    L5_2 = 0.0
    L6_2 = 0.0
    L7_2 = 0.0
    L8_2 = true
    L9_2 = true
    L10_2 = false
    L3_2 = L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2)
    L4_2 = GetPedBoneIndex
    L5_2 = L0_2
    L6_2 = 60309
    L4_2 = L4_2(L5_2, L6_2)
    L5_2 = SetCurrentPedWeapon
    L6_2 = L0_2
    L7_2 = "WEAPON_UNARMED"
    L8_2 = true
    L5_2(L6_2, L7_2, L8_2)
    L5_2 = AttachEntityToEntity
    L6_2 = L3_2
    L7_2 = L0_2
    L8_2 = L4_2
    L9_2 = vector3
    L10_2 = 0.03
    L11_2 = 0.002
    L12_2 = 0.0
    L9_2 = L9_2(L10_2, L11_2, L12_2)
    L10_2 = vector3
    L11_2 = 10.0
    L12_2 = 160.0
    L13_2 = 0.0
    L10_2 = L10_2(L11_2, L12_2, L13_2)
    L11_2 = true
    L12_2 = false
    L13_2 = false
    L14_2 = false
    L15_2 = 2
    L16_2 = true
    L5_2(L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2)
    L5_2 = SetModelAsNoLongerNeeded
    L6_2 = L1_1
    L5_2(L6_2)
    L5_2 = TaskPlayAnim
    L6_2 = L0_2
    L7_2 = L2_1
    L8_2 = L3_1
    L9_2 = 4.0
    L10_2 = -4.0
    L11_2 = L0_1
    L12_2 = 16
    L13_2 = 0
    L14_2 = false
    L15_2 = false
    L16_2 = false
    L5_2(L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2)
    L5_2 = Citizen
    L5_2 = L5_2.Wait
    L6_2 = L0_1
    L5_2(L6_2)
    L5_2 = DeleteObject
    L6_2 = L3_2
    L5_2(L6_2)
    L5_2 = GetVehicleNumberPlateText
    L6_2 = L2_2
    L5_2 = L5_2(L6_2)
    L6_2 = TriggerServerEvent
    L7_2 = Utils
    L7_2 = L7_2.eventsPrefix
    L8_2 = ":actions:getVehicleOwner"
    L7_2 = L7_2 .. L8_2
    L8_2 = L5_2
    L6_2(L7_2, L8_2)
  else
    L3_2 = notifyClient
    L4_2 = getLocalizedText
    L5_2 = "actions:checkVehicleOwner:car_not_found"
    L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2 = L4_2(L5_2)
    L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2)
  end
end
L5_1 = RegisterNetEvent
L6_1 = Utils
L6_1 = L6_1.eventsPrefix
L7_1 = ":actions:checkVehicleOwner"
L6_1 = L6_1 .. L7_1
L7_1 = L4_1
L5_1(L6_1, L7_1)

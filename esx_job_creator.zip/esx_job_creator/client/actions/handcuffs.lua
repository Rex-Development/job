local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1, L8_1, L9_1, L10_1, L11_1, L12_1, L13_1, L14_1, L15_1
L0_1 = false
L1_1 = false
L2_1 = false
function L3_1(A0_2)
  local L1_2, L2_2
  L0_1 = A0_2
  L1_2 = L0_1
  if not L1_2 then
    return
  end
  L1_2 = Citizen
  L1_2 = L1_2.CreateThread
  function L2_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3
    L0_3 = PlayerPedId
    L0_3 = L0_3()
    L1_3 = "mp_arresting"
    L2_3 = "idle"
    L3_3 = Utils
    L3_3 = L3_3.loadAnimDict
    L4_3 = L1_3
    L3_3(L4_3)
    L3_3 = SetEnableHandcuffs
    L4_3 = L0_3
    L5_3 = true
    L3_3(L4_3, L5_3)
    L3_3 = SetPedCanPlayGestureAnims
    L4_3 = L0_3
    L5_3 = false
    L3_3(L4_3, L5_3)
    while true do
      L3_3 = L0_1
      if not L3_3 then
        break
      end
      L3_3 = Citizen
      L3_3 = L3_3.Wait
      L4_3 = 0
      L3_3(L4_3)
      L3_3 = DisablePlayerFiring
      L4_3 = L0_3
      L5_3 = true
      L3_3(L4_3, L5_3)
      L3_3 = DisableControlAction
      L4_3 = 0
      L5_3 = 23
      L6_3 = true
      L3_3(L4_3, L5_3, L6_3)
      L3_3 = DisableControlAction
      L4_3 = 0
      L5_3 = 24
      L6_3 = true
      L3_3(L4_3, L5_3, L6_3)
      L3_3 = DisableControlAction
      L4_3 = 0
      L5_3 = 25
      L6_3 = true
      L3_3(L4_3, L5_3, L6_3)
      L3_3 = DisableControlAction
      L4_3 = 0
      L5_3 = 36
      L6_3 = true
      L3_3(L4_3, L5_3, L6_3)
      L3_3 = DisableControlAction
      L4_3 = 0
      L5_3 = 44
      L6_3 = true
      L3_3(L4_3, L5_3, L6_3)
      L3_3 = DisableControlAction
      L4_3 = 0
      L5_3 = 140
      L6_3 = true
      L3_3(L4_3, L5_3, L6_3)
      L3_3 = DisableControlAction
      L4_3 = 0
      L5_3 = 142
      L6_3 = true
      L3_3(L4_3, L5_3, L6_3)
      L3_3 = DisableControlAction
      L4_3 = 0
      L5_3 = 75
      L6_3 = true
      L3_3(L4_3, L5_3, L6_3)
      L3_3 = DisableControlAction
      L4_3 = 0
      L5_3 = 311
      L6_3 = true
      L3_3(L4_3, L5_3, L6_3)
      L3_3 = DisableControlAction
      L4_3 = 0
      L5_3 = 167
      L6_3 = true
      L3_3(L4_3, L5_3, L6_3)
      L3_3 = DisableControlAction
      L4_3 = 0
      L5_3 = 37
      L6_3 = true
      L3_3(L4_3, L5_3, L6_3)
      L3_3 = config
      L3_3 = L3_3.freezeWhenHandcuffed
      if L3_3 then
        L3_3 = DisableControlAction
        L4_3 = 0
        L5_3 = 32
        L6_3 = true
        L3_3(L4_3, L5_3, L6_3)
        L3_3 = DisableControlAction
        L4_3 = 0
        L5_3 = 34
        L6_3 = true
        L3_3(L4_3, L5_3, L6_3)
        L3_3 = DisableControlAction
        L4_3 = 0
        L5_3 = 31
        L6_3 = true
        L3_3(L4_3, L5_3, L6_3)
        L3_3 = DisableControlAction
        L4_3 = 0
        L5_3 = 30
        L6_3 = true
        L3_3(L4_3, L5_3, L6_3)
        L3_3 = DisableControlAction
        L4_3 = 0
        L5_3 = 22
        L6_3 = true
        L3_3(L4_3, L5_3, L6_3)
      end
      L3_3 = IsEntityPlayingAnim
      L4_3 = L0_3
      L5_3 = L1_3
      L6_3 = L2_3
      L7_3 = 3
      L3_3 = L3_3(L4_3, L5_3, L6_3, L7_3)
      if not L3_3 then
        L3_3 = TaskPlayAnim
        L4_3 = L0_3
        L5_3 = L1_3
        L6_3 = L2_3
        L7_3 = 8.0
        L8_3 = -8
        L9_3 = -1
        L10_3 = 49
        L11_3 = 0
        L12_3 = 0
        L13_3 = 0
        L14_3 = 0
        L3_3(L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3)
      end
    end
    L3_3 = RemoveAnimDict
    L4_3 = L1_3
    L3_3(L4_3)
    L3_3 = ClearPedTasks
    L4_3 = L0_3
    L3_3(L4_3)
    L3_3 = SetPedCanPlayGestureAnims
    L4_3 = L0_3
    L5_3 = true
    L3_3(L4_3, L5_3)
    L3_3 = SetEnableHandcuffs
    L4_3 = L0_3
    L5_3 = false
    L3_3(L4_3, L5_3)
  end
  L1_2(L2_2)
end
function L4_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2
  L0_2 = PlayerPedId
  L0_2 = L0_2()
  L1_2 = "mp_arresting"
  L2_2 = Utils
  L2_2 = L2_2.loadAnimDict
  L3_2 = L1_2
  L2_2(L3_2)
  L2_2 = "arrested_spin_r_0"
  L3_2 = SetCurrentPedWeapon
  L4_2 = L0_2
  L5_2 = "WEAPON_UNARMED"
  L6_2 = true
  L3_2(L4_2, L5_2, L6_2)
  L3_2 = TaskPlayAnim
  L4_2 = L0_2
  L5_2 = L1_2
  L6_2 = L2_2
  L7_2 = 4.0
  L8_2 = -4.0
  L9_2 = -1
  L10_2 = 0
  L11_2 = 0.0
  L12_2 = 0
  L13_2 = 0
  L14_2 = 0
  L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2)
  L3_2 = GetAnimDuration
  L4_2 = L1_2
  L5_2 = L2_2
  L3_2 = L3_2(L4_2, L5_2)
  L4_2 = Citizen
  L4_2 = L4_2.Wait
  L5_2 = L3_2 * 1000
  L4_2(L5_2)
end
function L5_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2
  L0_2 = PlayerPedId
  L0_2 = L0_2()
  L1_2 = "mp_arresting"
  L2_2 = "b_uncuff"
  L3_2 = TaskPlayAnim
  L4_2 = L0_2
  L5_2 = L1_2
  L6_2 = L2_2
  L7_2 = 4.0
  L8_2 = -4.0
  L9_2 = -1
  L10_2 = 0
  L11_2 = 0.0
  L12_2 = 0
  L13_2 = 0
  L14_2 = 0
  L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2)
  L3_2 = GetAnimDuration
  L4_2 = L1_2
  L5_2 = L2_2
  L3_2 = L3_2(L4_2, L5_2)
  L4_2 = Citizen
  L4_2 = L4_2.Wait
  L5_2 = L3_2 * 1000
  L4_2(L5_2)
end
function L6_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2
  L2_2 = true
  L2_1 = L2_2
  L2_2 = vector3
  L3_2 = 0.0
  L4_2 = -0.9
  L5_2 = 0.0
  L2_2 = L2_2(L3_2, L4_2, L5_2)
  L3_2 = PlayerPedId
  L3_2 = L3_2()
  L4_2 = GetOffsetFromEntityInWorldCoords
  L5_2 = A1_2
  L6_2 = L2_2
  L4_2 = L4_2(L5_2, L6_2)
  L5_2 = GetEntityHeading
  L6_2 = A1_2
  L5_2 = L5_2(L6_2)
  L6_2 = TaskGoStraightToCoordRelativeToEntity
  L7_2 = L3_2
  L8_2 = A1_2
  L9_2 = L2_2
  L10_2 = 0.0
  L11_2 = 5000
  L6_2(L7_2, L8_2, L9_2, L10_2, L11_2)
  L6_2 = GetGameTimer
  L6_2 = L6_2()
  while true do
    L7_2 = GetEntityCoords
    L8_2 = L3_2
    L7_2 = L7_2(L8_2)
    L8_2 = GetOffsetFromEntityInWorldCoords
    L9_2 = A1_2
    L10_2 = L2_2
    L8_2 = L8_2(L9_2, L10_2)
    L7_2 = L7_2 - L8_2
    L7_2 = #L7_2
    L8_2 = 0.5
    if L7_2 < L8_2 then
      break
    end
    L7_2 = Citizen
    L7_2 = L7_2.Wait
    L8_2 = 200
    L7_2(L8_2)
    L7_2 = GetGameTimer
    L7_2 = L7_2()
    L7_2 = L7_2 - L6_2
    L8_2 = 5000
    if L7_2 > L8_2 then
      L7_2 = ClearPedTasks
      L8_2 = L3_2
      L7_2(L8_2)
      L7_2 = false
      L2_1 = L7_2
      return
    end
  end
  L7_2 = ClearPedTasks
  L8_2 = L3_2
  L7_2(L8_2)
  L7_2 = SetPedDesiredHeading
  L8_2 = L3_2
  L9_2 = L5_2
  L7_2(L8_2, L9_2)
  L7_2 = GetGameTimer
  L7_2 = L7_2()
  while true do
    L8_2 = math
    L8_2 = L8_2.abs
    L9_2 = GetEntityHeading
    L10_2 = L3_2
    L9_2 = L9_2(L10_2)
    L9_2 = L9_2 - L5_2
    L8_2 = L8_2(L9_2)
    if L8_2 < 1.0 then
      break
    end
    L8_2 = Citizen
    L8_2 = L8_2.Wait
    L9_2 = 200
    L8_2(L9_2)
    L8_2 = GetGameTimer
    L8_2 = L8_2()
    L8_2 = L8_2 - L7_2
    L9_2 = 5000
    if L8_2 > L9_2 then
      L8_2 = ClearPedTasks
      L9_2 = L3_2
      L8_2(L9_2)
      L8_2 = false
      L2_1 = L8_2
      return
    end
  end
  L8_2 = ClearPedTasks
  L9_2 = L3_2
  L8_2(L9_2)
  L8_2 = "mp_arresting"
  L9_2 = RequestAnimDict
  L10_2 = L8_2
  L9_2(L10_2)
  while true do
    L9_2 = HasAnimDictLoaded
    L10_2 = L8_2
    L9_2 = L9_2(L10_2)
    if L9_2 then
      break
    end
    L9_2 = Citizen
    L9_2 = L9_2.Wait
    L10_2 = 0
    L9_2(L10_2)
  end
  L9_2 = "a_uncuff"
  L10_2 = SetCurrentPedWeapon
  L11_2 = L3_2
  L12_2 = "WEAPON_UNARMED"
  L13_2 = true
  L10_2(L11_2, L12_2, L13_2)
  L10_2 = TaskPlayAnim
  L11_2 = L3_2
  L12_2 = L8_2
  L13_2 = L9_2
  L14_2 = 4.0
  L15_2 = -4.0
  L16_2 = -1
  L17_2 = 0
  L18_2 = 0.0
  L19_2 = 0
  L20_2 = 0
  L21_2 = 0
  L10_2(L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2)
  L10_2 = TriggerServerEvent
  L11_2 = Utils
  L11_2 = L11_2.eventsPrefix
  L12_2 = ":handcuffTarget"
  L11_2 = L11_2 .. L12_2
  L12_2 = A0_2
  L10_2(L11_2, L12_2)
  L10_2 = false
  L2_1 = L10_2
end
L7_1 = RegisterNetEvent
L8_1 = Utils
L8_1 = L8_1.eventsPrefix
L9_1 = ":arrestConfirmed"
L8_1 = L8_1 .. L9_1
L7_1(L8_1)
L7_1 = AddEventHandler
L8_1 = Utils
L8_1 = L8_1.eventsPrefix
L9_1 = ":arrestConfirmed"
L8_1 = L8_1 .. L9_1
function L9_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = GetPlayerPed
  L2_2 = GetPlayerFromServerId
  L3_2 = A0_2
  L2_2, L3_2, L4_2 = L2_2(L3_2)
  L1_2 = L1_2(L2_2, L3_2, L4_2)
  if L1_2 > 0 then
    L2_2 = IsEntityAttached
    L3_2 = L1_2
    L2_2 = L2_2(L3_2)
    if L2_2 then
      L2_2 = notifyClient
      L3_2 = getLocalizedText
      L4_2 = "cant_while_dragging"
      L3_2, L4_2 = L3_2(L4_2)
      L2_2(L3_2, L4_2)
    else
      L2_2 = L6_1
      L3_2 = A0_2
      L4_2 = L1_2
      L2_2(L3_2, L4_2)
    end
  end
end
L7_1(L8_1, L9_1)
function L7_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = TriggerServerEvent
  L2_2 = Utils
  L2_2 = L2_2.eventsPrefix
  L3_2 = ":handcuffPlayer"
  L2_2 = L2_2 .. L3_2
  L3_2 = A0_2
  L1_2(L2_2, L3_2)
end
L8_1 = RegisterNetEvent
L9_1 = Utils
L9_1 = L9_1.eventsPrefix
L10_1 = ":handcuffPlayer"
L9_1 = L9_1 .. L10_1
L8_1(L9_1)
L8_1 = AddEventHandler
L9_1 = Utils
L9_1 = L9_1.eventsPrefix
L10_1 = ":handcuffPlayer"
L9_1 = L9_1 .. L10_1
function L10_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = L0_1
  L0_2 = not L0_2
  L0_1 = L0_2
  L0_2 = L1_1
  if L0_2 then
    L0_2 = DetachEntity
    L1_2 = PlayerPedId
    L1_2 = L1_2()
    L2_2 = true
    L3_2 = true
    L0_2(L1_2, L2_2, L3_2)
  end
  L0_2 = L0_1
  if L0_2 then
    L0_2 = L4_1
    L0_2()
  else
    L0_2 = L5_1
    L0_2()
  end
  L0_2 = L3_1
  L1_2 = L0_1
  L0_2(L1_2)
end
L8_1(L9_1, L10_1)
L8_1 = RegisterNetEvent
L9_1 = Utils
L9_1 = L9_1.eventsPrefix
L10_1 = ":setHandcuffs"
L9_1 = L9_1 .. L10_1
function L10_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L0_1 = A0_2
  L1_2 = L1_1
  if L1_2 then
    L1_2 = DetachEntity
    L2_2 = PlayerPedId
    L2_2 = L2_2()
    L3_2 = true
    L4_2 = true
    L1_2(L2_2, L3_2, L4_2)
  end
  L1_2 = L0_1
  if L1_2 then
    L1_2 = L3_1
    L2_2 = A0_2
    L1_2(L2_2)
  end
end
L8_1(L9_1, L10_1)
function L8_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2
  L1_2 = GetPlayerPed
  L2_2 = GetPlayerFromServerId
  L3_2 = A0_2
  L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2 = L2_2(L3_2)
  L1_2 = L1_2(L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2)
  if L1_2 > 0 then
    L2_2 = PlayerPedId
    L2_2 = L2_2()
    L3_2 = AttachEntityToEntity
    L4_2 = L2_2
    L5_2 = L1_2
    L6_2 = 11816
    L7_2 = 0.35
    L8_2 = 0.34
    L9_2 = 0.0
    L10_2 = 0.0
    L11_2 = 0.0
    L12_2 = 0.0
    L13_2 = false
    L14_2 = false
    L15_2 = false
    L16_2 = true
    L17_2 = 2
    L18_2 = true
    L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2)
  end
end
L9_1 = RegisterNetEvent
L10_1 = Utils
L10_1 = L10_1.eventsPrefix
L11_1 = ":dragTarget"
L10_1 = L10_1 .. L11_1
L9_1(L10_1)
L9_1 = AddEventHandler
L10_1 = Utils
L10_1 = L10_1.eventsPrefix
L11_1 = ":dragTarget"
L10_1 = L10_1 .. L11_1
function L11_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = L0_1
  if L1_2 then
    L1_2 = L1_1
    L1_2 = not L1_2
    L1_1 = L1_2
    L1_2 = L1_1
    if L1_2 then
      L1_2 = L8_1
      L2_2 = A0_2
      L1_2(L2_2)
    else
      L1_2 = DetachEntity
      L2_2 = PlayerPedId
      L2_2 = L2_2()
      L3_2 = true
      L4_2 = true
      L1_2(L2_2, L3_2, L4_2)
    end
  end
end
L9_1(L10_1, L11_1)
L9_1 = RegisterNetEvent
L10_1 = Utils
L10_1 = L10_1.eventsPrefix
L11_1 = ":putincar"
L10_1 = L10_1 .. L11_1
L9_1(L10_1)
L9_1 = AddEventHandler
L10_1 = Utils
L10_1 = L10_1.eventsPrefix
L11_1 = ":putincar"
L10_1 = L10_1 .. L11_1
function L11_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  L1_2 = PlayerPedId
  L1_2 = L1_2()
  L2_2 = L1_1
  if L2_2 then
    L2_2 = DetachEntity
    L3_2 = L1_2
    L4_2 = true
    L5_2 = true
    L2_2(L3_2, L4_2, L5_2)
  end
  L2_2 = L0_1
  if L2_2 then
    L2_2 = NetToVeh
    L3_2 = A0_2
    L2_2 = L2_2(L3_2)
    L3_2 = DoesEntityExist
    L4_2 = L2_2
    L3_2 = L3_2(L4_2)
    if L3_2 then
      L3_2 = GetVehicleMaxNumberOfPassengers
      L4_2 = L2_2
      L3_2 = L3_2(L4_2)
      L4_2 = nil
      L5_2 = L3_2 - 1
      L6_2 = 0
      L7_2 = -1
      for L8_2 = L5_2, L6_2, L7_2 do
        L9_2 = IsVehicleSeatFree
        L10_2 = L2_2
        L11_2 = L8_2
        L9_2 = L9_2(L10_2, L11_2)
        if L9_2 then
          L4_2 = L8_2
          break
        end
      end
      if L4_2 then
        L5_2 = TaskEnterVehicle
        L6_2 = L1_2
        L7_2 = L2_2
        L8_2 = -1
        L9_2 = L4_2
        L10_2 = 1.0
        L11_2 = 1
        L12_2 = 0
        L5_2(L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2)
      end
    end
  end
end
L9_1(L10_1, L11_1)
L9_1 = RegisterNetEvent
L10_1 = Utils
L10_1 = L10_1.eventsPrefix
L11_1 = ":takefromcar"
L10_1 = L10_1 .. L11_1
L9_1(L10_1)
L9_1 = AddEventHandler
L10_1 = Utils
L10_1 = L10_1.eventsPrefix
L11_1 = ":takefromcar"
L10_1 = L10_1 .. L11_1
function L11_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = PlayerPedId
  L0_2 = L0_2()
  L1_2 = L1_1
  if L1_2 then
    L1_2 = DetachEntity
    L2_2 = L0_2
    L3_2 = true
    L4_2 = true
    L1_2(L2_2, L3_2, L4_2)
  end
  L1_2 = L0_1
  if L1_2 then
    L1_2 = TaskLeaveAnyVehicle
    L2_2 = L0_2
    L3_2 = 0
    L4_2 = 256
    L1_2(L2_2, L3_2, L4_2)
  end
end
L9_1(L10_1, L11_1)
function L9_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = Framework
  L0_2 = L0_2.getClosestPlayer
  L1_2 = true
  L2_2 = 2.0
  L0_2 = L0_2(L1_2, L2_2)
  if L0_2 then
    L1_2 = L2_1
    if not L1_2 then
      L1_2 = L7_1
      L2_2 = L0_2
      L1_2(L2_2)
  end
  else
    L1_2 = notifyClient
    L2_2 = getLocalizedText
    L3_2 = "no_players_nearby"
    L2_2, L3_2 = L2_2(L3_2)
    L1_2(L2_2, L3_2)
  end
end
L10_1 = RegisterNetEvent
L11_1 = Utils
L11_1 = L11_1.eventsPrefix
L12_1 = ":actions:handcuff"
L11_1 = L11_1 .. L12_1
L12_1 = L9_1
L10_1(L11_1, L12_1)
function L10_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = Framework
  L0_2 = L0_2.getClosestPlayer
  L1_2 = true
  L2_2 = 2.0
  L0_2 = L0_2(L1_2, L2_2)
  if L0_2 then
    L1_2 = TriggerServerEvent
    L2_2 = Utils
    L2_2 = L2_2.eventsPrefix
    L3_2 = ":dragTarget"
    L2_2 = L2_2 .. L3_2
    L3_2 = L0_2
    L1_2(L2_2, L3_2)
  else
    L1_2 = notifyClient
    L2_2 = getLocalizedText
    L3_2 = "no_players_nearby"
    L2_2, L3_2 = L2_2(L3_2)
    L1_2(L2_2, L3_2)
  end
end
L11_1 = RegisterNetEvent
L12_1 = Utils
L12_1 = L12_1.eventsPrefix
L13_1 = ":actions:drag"
L12_1 = L12_1 .. L13_1
L13_1 = L10_1
L11_1(L12_1, L13_1)
function L11_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L0_2 = Framework
  L0_2 = L0_2.getClosestPlayer
  L1_2 = true
  L2_2 = 4.0
  L0_2 = L0_2(L1_2, L2_2)
  L1_2 = Framework
  L1_2 = L1_2.getClosestVehicle
  L2_2 = 10.0
  L1_2 = L1_2(L2_2)
  if L0_2 then
    if L1_2 then
      L2_2 = TriggerServerEvent
      L3_2 = Utils
      L3_2 = L3_2.eventsPrefix
      L4_2 = ":putincar"
      L3_2 = L3_2 .. L4_2
      L4_2 = L0_2
      L5_2 = VehToNet
      L6_2 = L1_2
      L5_2, L6_2 = L5_2(L6_2)
      L2_2(L3_2, L4_2, L5_2, L6_2)
    else
      L2_2 = notifyClient
      L3_2 = getLocalizedText
      L4_2 = "no_vehicles_nearby"
      L3_2, L4_2, L5_2, L6_2 = L3_2(L4_2)
      L2_2(L3_2, L4_2, L5_2, L6_2)
    end
  else
    L2_2 = notifyClient
    L3_2 = getLocalizedText
    L4_2 = "no_players_nearby"
    L3_2, L4_2, L5_2, L6_2 = L3_2(L4_2)
    L2_2(L3_2, L4_2, L5_2, L6_2)
  end
end
L12_1 = RegisterNetEvent
L13_1 = Utils
L13_1 = L13_1.eventsPrefix
L14_1 = ":actions:putInCar"
L13_1 = L13_1 .. L14_1
L14_1 = L11_1
L12_1(L13_1, L14_1)
function L12_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = Framework
  L0_2 = L0_2.getClosestPlayer
  L1_2 = true
  L2_2 = 10.0
  L0_2 = L0_2(L1_2, L2_2)
  if L0_2 then
    L1_2 = TriggerServerEvent
    L2_2 = Utils
    L2_2 = L2_2.eventsPrefix
    L3_2 = ":takefromcar"
    L2_2 = L2_2 .. L3_2
    L3_2 = L0_2
    L1_2(L2_2, L3_2)
  else
    L1_2 = notifyClient
    L2_2 = getLocalizedText
    L3_2 = "no_players_nearby"
    L2_2, L3_2 = L2_2(L3_2)
    L1_2(L2_2, L3_2)
  end
end
L13_1 = RegisterNetEvent
L14_1 = Utils
L14_1 = L14_1.eventsPrefix
L15_1 = ":actions:takeFromCar"
L14_1 = L14_1 .. L15_1
L15_1 = L12_1
L13_1(L14_1, L15_1)
L13_1 = exports
L14_1 = "isPlayerHandcuffed"
function L15_1()
  local L0_2, L1_2
  L0_2 = L0_1
  return L0_2
end
L13_1(L14_1, L15_1)

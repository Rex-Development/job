local L0_1, L1_1, L2_1, L3_1, L4_1
L0_1 = false
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
  L0_2 = L0_1
  if L0_2 then
    return
  end
  L0_2 = PlayerPedId
  L0_2 = L0_2()
  L1_2 = IsPedInAnyVehicle
  L2_2 = L0_2
  L3_2 = false
  L1_2 = L1_2(L2_2, L3_2)
  if L1_2 then
    return
  end
  L1_2 = GetEntityCoords
  L2_2 = L0_2
  L1_2 = L1_2(L2_2)
  L2_2 = Framework
  L2_2 = L2_2.getClosestVehicle
  L3_2 = 3.0
  L2_2 = L2_2(L3_2)
  L3_2 = SetVehicleDirtLevel
  L4_2 = L2_2
  L5_2 = 10.0
  L3_2(L4_2, L5_2)
  if L2_2 then
    L3_2 = TriggerServerCallback
    L4_2 = Utils
    L4_2 = L4_2.eventsPrefix
    L5_2 = ":canWashVehicle"
    L4_2 = L4_2 .. L5_2
    function L5_2(A0_3)
      local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3
      if A0_3 then
        L1_3 = true
        L0_1 = L1_3
        L1_3 = TaskTurnPedToFaceEntity
        L2_3 = L0_2
        L3_3 = L2_2
        L4_3 = 1500
        L1_3(L2_3, L3_3, L4_3)
        L1_3 = Citizen
        L1_3 = L1_3.Wait
        L2_3 = 1500
        L1_3(L2_3)
        L1_3 = TaskStartScenarioInPlace
        L2_3 = L0_2
        L3_3 = "world_human_maid_clean"
        L4_3 = 0
        L5_3 = true
        L1_3(L2_3, L3_3, L4_3, L5_3)
        L1_3 = GetVehicleDirtLevel
        L2_3 = L2_2
        L1_3 = L1_3(L2_3)
        L2_3 = L1_3 * 1000
        L3_3 = startProgressBar
        L4_3 = L2_3
        L5_3 = getLocalizedText
        L6_3 = "actions:washing_vehicle"
        L5_3, L6_3 = L5_3(L6_3)
        L3_3(L4_3, L5_3, L6_3)
        while L1_3 >= 0.0 do
          L3_3 = Citizen
          L3_3 = L3_3.Wait
          L4_3 = 1000
          L3_3(L4_3)
          L1_3 = L1_3 - 1.0
          L3_3 = SetVehicleDirtLevel
          L4_3 = L2_2
          L5_3 = L1_3
          L3_3(L4_3, L5_3)
        end
        L3_3 = ClearPedTasks
        L4_3 = L0_2
        L3_3(L4_3)
        L3_3 = false
        L0_1 = L3_3
      end
    end
    L3_2(L4_2, L5_2)
  else
    L3_2 = notifyClient
    L4_2 = getLocalizedText
    L5_2 = "actions:no_vehicles_close"
    L4_2, L5_2 = L4_2(L5_2)
    L3_2(L4_2, L5_2)
  end
end
L2_1 = RegisterNetEvent
L3_1 = Utils
L3_1 = L3_1.eventsPrefix
L4_1 = ":actions:washVehicle"
L3_1 = L3_1 .. L4_1
L4_1 = L1_1
L2_1(L3_1, L4_1)

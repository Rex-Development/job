local L0_1, L1_1, L2_1, L3_1
function L0_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
  L0_2 = Framework
  L0_2 = L0_2.getClosestPlayer
  L1_2 = true
  L2_2 = 2.0
  L0_2 = L0_2(L1_2, L2_2)
  if L0_2 then
    L1_2 = config
    L1_2 = L1_2.useJSFourIdCard
    if L1_2 then
      L1_2 = TriggerServerEvent
      L2_2 = EXTERNAL_EVENTS_NAMES
      L2_2 = L2_2["jsfour-idcard:open"]
      L3_2 = L0_2
      L4_2 = GetPlayerServerId
      L5_2 = PlayerId
      L5_2 = L5_2()
      L4_2, L5_2 = L4_2(L5_2)
      L1_2(L2_2, L3_2, L4_2, L5_2)
      L1_2 = Framework
      L1_2 = L1_2.menu
      L1_2 = L1_2()
      L1_2 = L1_2.CloseAll
      L1_2()
    else
      L1_2 = TriggerServerEvent
      L2_2 = Utils
      L2_2 = L2_2.eventsPrefix
      L3_2 = ":actions:checkIdentity"
      L2_2 = L2_2 .. L3_2
      L3_2 = L0_2
      L1_2(L2_2, L3_2)
    end
  else
    L1_2 = notifyClient
    L2_2 = getLocalizedText
    L3_2 = "actions:no_player_found"
    L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
    L1_2(L2_2, L3_2, L4_2, L5_2)
  end
end
L1_1 = RegisterNetEvent
L2_1 = Utils
L2_1 = L2_1.eventsPrefix
L3_1 = ":actions:checkIdentity"
L2_1 = L2_1 .. L3_1
L3_1 = L0_1
L1_1(L2_1, L3_1)

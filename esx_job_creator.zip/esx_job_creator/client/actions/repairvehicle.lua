local L0_1, L1_1, L2_1, L3_1, L4_1
L0_1 = false
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = L0_1
  if L0_2 then
    return
  end
  L0_2 = PlayerPedId
  L0_2 = L0_2()
  L1_2 = IsPedInAnyVehicle
  L2_2 = L0_2
  L3_2 = false
  L1_2 = L1_2(L2_2, L3_2)
  if L1_2 then
    return
  end
  L1_2 = Framework
  L1_2 = L1_2.getClosestVehicle
  L2_2 = 3.0
  L1_2 = L1_2(L2_2)
  if L1_2 then
    L2_2 = TriggerServerCallback
    L3_2 = Utils
    L3_2 = L3_2.eventsPrefix
    L4_2 = ":canRepairVehicle"
    L3_2 = L3_2 .. L4_2
    function L4_2(A0_3)
      local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3
      if A0_3 then
        L1_3 = true
        L0_1 = L1_3
        L1_3 = TaskTurnPedToFaceEntity
        L2_3 = L0_2
        L3_3 = L1_2
        L4_3 = 1500
        L1_3(L2_3, L3_3, L4_3)
        L1_3 = Citizen
        L1_3 = L1_3.Wait
        L2_3 = 1500
        L1_3(L2_3)
        L1_3 = 15000
        L2_3 = TaskStartScenarioInPlace
        L3_3 = L0_2
        L4_3 = "PROP_HUMAN_BUM_BIN"
        L5_3 = 0
        L6_3 = true
        L2_3(L3_3, L4_3, L5_3, L6_3)
        L2_3 = startProgressBar
        L3_3 = L1_3
        L4_3 = getLocalizedText
        L5_3 = "actions:repairing_vehicle"
        L4_3, L5_3, L6_3 = L4_3(L5_3)
        L2_3(L3_3, L4_3, L5_3, L6_3)
        L2_3 = Citizen
        L2_3 = L2_3.Wait
        L3_3 = L1_3
        L2_3(L3_3)
        L2_3 = SetVehicleFixed
        L3_3 = L1_2
        L2_3(L3_3)
        L2_3 = SetEntityHealth
        L3_3 = L1_2
        L4_3 = GetEntityMaxHealth
        L5_3 = L1_2
        L4_3, L5_3, L6_3 = L4_3(L5_3)
        L2_3(L3_3, L4_3, L5_3, L6_3)
        L2_3 = SetVehicleDeformationFixed
        L3_3 = L1_2
        L2_3(L3_3)
        L2_3 = ClearPedTasks
        L3_3 = L0_2
        L2_3(L3_3)
        L2_3 = false
        L0_1 = L2_3
      end
    end
    L2_2(L3_2, L4_2)
  else
    L2_2 = notifyClient
    L3_2 = getLocalizedText
    L4_2 = "actions:no_vehicles_close"
    L3_2, L4_2 = L3_2(L4_2)
    L2_2(L3_2, L4_2)
  end
end
L2_1 = RegisterNetEvent
L3_1 = Utils
L3_1 = L3_1.eventsPrefix
L4_1 = ":actions:repairVehicle"
L3_1 = L3_1 .. L4_1
L4_1 = L1_1
L2_1(L3_1, L4_1)

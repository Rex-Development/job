local L0_1, L1_1, L2_1, L3_1
function L0_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2
  L1_2 = PlayerPedId
  L1_2 = L1_2()
  L2_2 = GetEntityCoords
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  L3_2 = Framework
  L3_2 = L3_2.getClosestPlayer
  L4_2 = true
  L5_2 = 3.0
  L3_2 = L3_2(L4_2, L5_2)
  if L3_2 then
    L4_2 = config
    L4_2 = L4_2.useJSFourIdCard
    if L4_2 then
      L4_2 = TriggerServerEvent
      L5_2 = EXTERNAL_EVENTS_NAMES
      L5_2 = L5_2["jsfour-idcard:open"]
      L6_2 = L3_2
      L7_2 = GetPlayerServerId
      L8_2 = PlayerId
      L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2 = L8_2()
      L7_2 = L7_2(L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2)
      L8_2 = A0_2
      L4_2(L5_2, L6_2, L7_2, L8_2)
      L4_2 = Framework
      L4_2 = L4_2.menu
      L4_2 = L4_2()
      L4_2 = L4_2.CloseAll
      L4_2()
    else
      L4_2 = Framework
      L4_2 = L4_2.getPlayerLicenses
      L5_2 = L3_2
      L4_2 = L4_2(L5_2)
      L5_2 = {}
      L6_2 = Framework
      L6_2 = L6_2.getFramework
      L6_2 = L6_2()
      if "ESX" == L6_2 then
        L6_2 = pairs
        L7_2 = L4_2
        L6_2, L7_2, L8_2, L9_2 = L6_2(L7_2)
        for L10_2, L11_2 in L6_2, L7_2, L8_2, L9_2 do
          L12_2 = config
          L12_2 = L12_2.licenses
          L12_2 = L12_2[A0_2]
          L13_2 = L11_2.type
          L12_2 = L12_2[L13_2]
          if L12_2 then
            L12_2 = table
            L12_2 = L12_2.insert
            L13_2 = L5_2
            L14_2 = {}
            L15_2 = getLocalizedText
            L16_2 = "actions:license"
            L17_2 = L11_2.label
            L15_2 = L15_2(L16_2, L17_2)
            L14_2.label = L15_2
            L12_2(L13_2, L14_2)
          end
        end
      else
        L6_2 = Framework
        L6_2 = L6_2.getFramework
        L6_2 = L6_2()
        if "QB-core" == L6_2 then
          L6_2 = pairs
          L7_2 = L4_2
          L6_2, L7_2, L8_2, L9_2 = L6_2(L7_2)
          for L10_2, L11_2 in L6_2, L7_2, L8_2, L9_2 do
            L12_2 = config
            L12_2 = L12_2.licenses
            L12_2 = L12_2[A0_2]
            L12_2 = L12_2[L10_2]
            if L12_2 then
              L12_2 = table
              L12_2 = L12_2.insert
              L13_2 = L5_2
              L14_2 = {}
              L15_2 = getLocalizedText
              L16_2 = "actions:license"
              L17_2 = firstToUpper
              L18_2 = L10_2
              L17_2, L18_2 = L17_2(L18_2)
              L15_2 = L15_2(L16_2, L17_2, L18_2)
              L14_2.label = L15_2
              L12_2(L13_2, L14_2)
            end
          end
        end
      end
      L6_2 = #L5_2
      if 0 == L6_2 then
        L6_2 = table
        L6_2 = L6_2.insert
        L7_2 = L5_2
        L8_2 = {}
        L9_2 = getLocalizedText
        L10_2 = "actions:no_license_found"
        L9_2 = L9_2(L10_2)
        L8_2.label = L9_2
        L6_2(L7_2, L8_2)
      end
      L6_2 = Framework
      L6_2 = L6_2.menu
      L6_2 = L6_2()
      L6_2 = L6_2.Open
      L7_2 = "default"
      L8_2 = GetCurrentResourceName
      L8_2 = L8_2()
      L9_2 = "licenses"
      L10_2 = {}
      L11_2 = getLocalizedText
      L12_2 = "actions:licenses"
      L11_2 = L11_2(L12_2)
      L10_2.title = L11_2
      L11_2 = config
      L11_2 = L11_2.menuPosition
      L10_2.align = L11_2
      L10_2.elements = L5_2
      L11_2 = nil
      function L12_2(A0_3, A1_3)
        local L2_3
        L2_3 = A1_3.close
        L2_3()
      end
      L6_2(L7_2, L8_2, L9_2, L10_2, L11_2, L12_2)
    end
  else
    L4_2 = notifyClient
    L5_2 = getLocalizedText
    L6_2 = "actions:no_player_found"
    L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2 = L5_2(L6_2)
    L4_2(L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2)
  end
end
L1_1 = RegisterNetEvent
L2_1 = Utils
L2_1 = L2_1.eventsPrefix
L3_1 = ":actions:checkPlayerLicenses"
L2_1 = L2_1 .. L3_1
L3_1 = L0_1
L1_1(L2_1, L3_1)
function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = promise
  L0_2 = L0_2.new
  L0_2 = L0_2()
  L1_2 = TriggerServerCallback
  L2_2 = "esx_license:getLicensesList"
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3
    L1_3 = L0_2
    L2_3 = L1_3
    L1_3 = L1_3.resolve
    L3_3 = A0_3
    L1_3(L2_3, L3_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = Citizen
  L1_2 = L1_2.Await
  L2_2 = L0_2
  return L1_2(L2_2)
end
function L2_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2
  L2_2 = {}
  L3_2 = {}
  L4_2 = Framework
  L4_2 = L4_2.getFramework
  L4_2 = L4_2()
  if "ESX" == L4_2 then
    L4_2 = L1_1
    L4_2 = L4_2()
    L3_2 = L4_2
  else
    L4_2 = Framework
    L4_2 = L4_2.getFramework
    L4_2 = L4_2()
    if "QB-core" == L4_2 then
      L4_2 = config
      L4_2 = L4_2.licenses
      L3_2 = L4_2[A1_2]
    end
  end
  L4_2 = Framework
  L4_2 = L4_2.getPlayerLicenses
  L5_2 = A0_2
  L4_2 = L4_2(L5_2)
  L5_2 = {}
  L6_2 = Framework
  L6_2 = L6_2.getFramework
  L6_2 = L6_2()
  if "ESX" == L6_2 then
    L6_2 = pairs
    L7_2 = L3_2
    L6_2, L7_2, L8_2, L9_2 = L6_2(L7_2)
    for L10_2, L11_2 in L6_2, L7_2, L8_2, L9_2 do
      L12_2 = config
      L12_2 = L12_2.licenses
      L12_2 = L12_2[A1_2]
      L13_2 = L11_2.type
      L12_2 = L12_2[L13_2]
      if L12_2 then
        L12_2 = false
        L13_2 = pairs
        L14_2 = L4_2
        L13_2, L14_2, L15_2, L16_2 = L13_2(L14_2)
        for L17_2, L18_2 in L13_2, L14_2, L15_2, L16_2 do
          L19_2 = L18_2.type
          L20_2 = L11_2.type
          if L19_2 == L20_2 then
            L12_2 = true
            break
          end
        end
        if L12_2 then
          L13_2 = "green"
          if L13_2 then
            goto lbl_64
          end
        end
        L13_2 = "orange"
        ::lbl_64::
        L14_2 = table
        L14_2 = L14_2.insert
        L15_2 = L5_2
        L16_2 = {}
        L17_2 = "<span style='color: "
        L18_2 = L13_2
        L19_2 = "'>"
        L20_2 = L11_2.label
        L21_2 = "</span>"
        L17_2 = L17_2 .. L18_2 .. L19_2 .. L20_2 .. L21_2
        L16_2.label = L17_2
        L17_2 = L11_2.type
        L16_2.type = L17_2
        L16_2.owned = L12_2
        L17_2 = L11_2.label
        L16_2.licenseLabel = L17_2
        L14_2(L15_2, L16_2)
      end
    end
  else
    L6_2 = Framework
    L6_2 = L6_2.getFramework
    L6_2 = L6_2()
    if "QB-core" == L6_2 then
      L6_2 = pairs
      L7_2 = L3_2
      L6_2, L7_2, L8_2, L9_2 = L6_2(L7_2)
      for L10_2, L11_2 in L6_2, L7_2, L8_2, L9_2 do
        L12_2 = L4_2[L10_2]
        if nil ~= L12_2 then
          L12_2 = false
          L13_2 = pairs
          L14_2 = L4_2
          L13_2, L14_2, L15_2, L16_2 = L13_2(L14_2)
          for L17_2, L18_2 in L13_2, L14_2, L15_2, L16_2 do
            if L10_2 == L17_2 and L18_2 then
              L12_2 = true
              break
            end
          end
          if L12_2 then
            L13_2 = "green"
            if L13_2 then
              goto lbl_118
            end
          end
          L13_2 = "orange"
          ::lbl_118::
          L14_2 = firstToUpper
          L15_2 = L10_2
          L14_2 = L14_2(L15_2)
          L15_2 = table
          L15_2 = L15_2.insert
          L16_2 = L5_2
          L17_2 = {}
          L18_2 = "<span style='color: "
          L19_2 = L13_2
          L20_2 = "'>"
          L21_2 = L14_2
          L22_2 = "</span>"
          L18_2 = L18_2 .. L19_2 .. L20_2 .. L21_2 .. L22_2
          L17_2.label = L18_2
          L17_2.type = L10_2
          L17_2.owned = L12_2
          L17_2.licenseLabel = L14_2
          L15_2(L16_2, L17_2)
        end
      end
    end
  end
  L6_2 = Framework
  L6_2 = L6_2.menu
  L6_2 = L6_2()
  L6_2 = L6_2.Open
  L7_2 = "default"
  L8_2 = GetCurrentResourceName
  L8_2 = L8_2()
  L9_2 = "license_give_remove_menu"
  L10_2 = {}
  L11_2 = getLocalizedText
  L12_2 = "actions_menu"
  L11_2 = L11_2(L12_2)
  L10_2.title = L11_2
  L11_2 = config
  L11_2 = L11_2.menuPosition
  L10_2.align = L11_2
  L10_2.elements = L5_2
  function L11_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3
    L2_3 = A0_3.current
    L2_3 = L2_3.type
    L3_3 = A0_3.current
    L3_3 = L3_3.owned
    L4_3 = A0_3.current
    L4_3 = L4_3.licenseLabel
    if L3_3 then
      L5_3 = Framework
      L5_3 = L5_3.removeLicenseFromPlayer
      L6_3 = A0_2
      L7_3 = L2_3
      L5_3(L6_3, L7_3)
      L5_3 = notifyClient
      L6_3 = getLocalizedText
      L7_3 = "actions:removed_license"
      L8_3 = L4_3
      L6_3, L7_3, L8_3 = L6_3(L7_3, L8_3)
      L5_3(L6_3, L7_3, L8_3)
    else
      L5_3 = Framework
      L5_3 = L5_3.giveLicenseToPlayer
      L6_3 = A0_2
      L7_3 = L2_3
      L5_3(L6_3, L7_3)
      L5_3 = notifyClient
      L6_3 = getLocalizedText
      L7_3 = "actions:gave_license"
      L8_3 = L4_3
      L6_3, L7_3, L8_3 = L6_3(L7_3, L8_3)
      L5_3(L6_3, L7_3, L8_3)
    end
    L5_3 = L2_1
    L6_3 = A0_2
    L7_3 = A1_2
    L5_3(L6_3, L7_3)
  end
  function L12_2(A0_3, A1_3)
    local L2_3
    L2_3 = A1_3.close
    L2_3()
  end
  L6_2(L7_2, L8_2, L9_2, L10_2, L11_2, L12_2)
end
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L1_2 = {}
  L2_2 = {}
  L3_2 = getLocalizedText
  L4_2 = "actions:license:give_remove"
  L3_2 = L3_2(L4_2)
  L2_2.label = L3_2
  L2_2.value = "license_give_remove"
  L3_2 = {}
  L4_2 = getLocalizedText
  L5_2 = "actions:check_licenses"
  L4_2 = L4_2(L5_2)
  L3_2.label = L4_2
  L3_2.value = "checklicenses"
  L1_2[1] = L2_2
  L1_2[2] = L3_2
  L2_2 = Framework
  L2_2 = L2_2.menu
  L2_2 = L2_2()
  L2_2 = L2_2.Open
  L3_2 = "default"
  L4_2 = GetCurrentResourceName
  L4_2 = L4_2()
  L5_2 = "license_menu"
  L6_2 = {}
  L7_2 = getLocalizedText
  L8_2 = "actions_menu"
  L7_2 = L7_2(L8_2)
  L6_2.title = L7_2
  L7_2 = config
  L7_2 = L7_2.menuPosition
  L6_2.align = L7_2
  L6_2.elements = L1_2
  function L7_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3
    L2_3 = A0_3.current
    L2_3 = L2_3.value
    if "license_give_remove" == L2_3 then
      L3_3 = PlayerPedId
      L3_3 = L3_3()
      L4_3 = GetEntityCoords
      L5_3 = L3_3
      L4_3 = L4_3(L5_3)
      L5_3 = Framework
      L5_3 = L5_3.getClosestPlayer
      L6_3 = true
      L7_3 = 3.0
      L5_3 = L5_3(L6_3, L7_3)
      if L5_3 then
        L6_3 = L2_1
        L7_3 = L5_3
        L8_3 = A0_2
        L6_3(L7_3, L8_3)
      else
        L6_3 = notifyClient
        L7_3 = getLocalizedText
        L8_3 = "actions:no_player_found"
        L7_3, L8_3 = L7_3(L8_3)
        L6_3(L7_3, L8_3)
      end
    elseif "checklicenses" == L2_3 then
      L3_3 = TriggerEvent
      L4_3 = Utils
      L4_3 = L4_3.eventsPrefix
      L5_3 = ":actions:checkPlayerLicenses"
      L4_3 = L4_3 .. L5_3
      L5_3 = A0_2
      L3_3(L4_3, L5_3)
    end
  end
  function L8_2(A0_3, A1_3)
    local L2_3
    L2_3 = A1_3.close
    L2_3()
  end
  L2_2(L3_2, L4_2, L5_2, L6_2, L7_2, L8_2)
end
openLicenseMenu = L3_1

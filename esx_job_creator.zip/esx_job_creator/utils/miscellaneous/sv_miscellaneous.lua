local L0_1, L1_1
L0_1 = Utils
function L1_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = IsPlayerAceAllowed
  L2_2 = A0_2
  L3_2 = config
  L3_2 = L3_2.acePermission
  return L1_2(L2_2, L3_2)
end
L0_1.isAllowed = L1_1
function L0_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2
  if A0_2 then
    L2_2 = TriggerClientEvent
    L3_2 = Utils
    L3_2 = L3_2.eventsPrefix
    L4_2 = ":notifyClient"
    L3_2 = L3_2 .. L4_2
    L4_2 = A0_2
    L5_2 = A1_2
    L2_2(L3_2, L4_2, L5_2)
  end
end
notify = L0_1
function L0_1(A0_2, A1_2, A2_2, A3_2, A4_2)
  local L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2
  L5_2 = config
  L5_2 = L5_2.areDiscordLogsActive
  if L5_2 then
    L5_2 = Framework
    L5_2 = L5_2.getIdentifier
    L6_2 = A0_2
    L5_2 = L5_2(L6_2)
    L6_2 = nil
    if "info" == A3_2 then
      L6_2 = 1752220
    elseif "error" == A3_2 then
      L6_2 = 15548997
    elseif "success" == A3_2 then
      L6_2 = 5763719
    end
    L7_2 = config
    L7_2 = L7_2.specificWebhooks
    L7_2 = L7_2[A4_2]
    if not L7_2 then
      L7_2 = config
      L7_2 = L7_2.mainDiscordWebhook
    end
    L8_2 = PerformHttpRequest
    L9_2 = L7_2
    L10_2 = nil
    L11_2 = "POST"
    L12_2 = json
    L12_2 = L12_2.encode
    L13_2 = {}
    L14_2 = GetCurrentResourceName
    L14_2 = L14_2()
    L13_2.username = L14_2
    L14_2 = {}
    L15_2 = {}
    L15_2.title = A1_2
    L16_2 = getLocalizedText
    L17_2 = "log:generic"
    L18_2 = GetPlayerName
    L19_2 = A0_2
    L18_2 = L18_2(L19_2)
    L19_2 = L5_2
    L20_2 = A2_2
    L16_2 = L16_2(L17_2, L18_2, L19_2, L20_2)
    L15_2.description = L16_2
    L16_2 = os
    L16_2 = L16_2.date
    L17_2 = "!%Y-%m-%dT%H:%M:%SZ"
    L16_2 = L16_2(L17_2)
    L15_2.timestamp = L16_2
    L15_2.color = L6_2
    L14_2[1] = L15_2
    L13_2.embeds = L14_2
    L12_2 = L12_2(L13_2)
    L13_2 = {}
    L13_2["Content-Type"] = "application/json"
    L8_2(L9_2, L10_2, L11_2, L12_2, L13_2)
  end
end
log = L0_1
L0_1 = Utils
function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = GetResourceMetadata
  L1_2 = GetCurrentResourceName
  L1_2 = L1_2()
  L2_2 = "version"
  L3_2 = 0
  return L0_2(L1_2, L2_2, L3_2)
end
L0_1.getScriptVersion = L1_1
L0_1 = Utils
function L1_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = GetGameTimer
  L1_2 = L1_2()
  L1_2 = L1_2 + 5000
  while true do
    L2_2 = DoesEntityExist
    L3_2 = A0_2
    L2_2 = L2_2(L3_2)
    if L2_2 then
      break
    end
    L2_2 = Citizen
    L2_2 = L2_2.Wait
    L3_2 = 500
    L2_2(L3_2)
    L2_2 = GetGameTimer
    L2_2 = L2_2()
    if L1_2 < L2_2 then
      L2_2 = false
      return L2_2
    end
  end
  L2_2 = true
  return L2_2
end
L0_1.isServerEntityReady = L1_1
L0_1 = Citizen
L0_1 = L0_1.CreateThread
function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = GetCurrentResourceName
  L0_2 = L0_2()
  L1_2 = Utils
  L1_2 = L1_2.eventsPrefix
  if L0_2 == L1_2 then
    L1_2 = FORCE_WATERMARK
    if not L1_2 then
      goto lbl_14
    end
  end
  L1_2 = SetConvarServerInfo
  L2_2 = "\240\159\146\188 Jobs Creator"
  L3_2 = "By jaksam"
  L1_2(L2_2, L3_2)
  ::lbl_14::
end
L0_1(L1_1)

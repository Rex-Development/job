local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1, L8_1
function L0_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L1_2 = SetPedRelationshipGroupHash
  L2_2 = A0_2
  L3_2 = GetHashKey
  L4_2 = "AMBIENT_GANG_FAMILY"
  L3_2, L4_2, L5_2, L6_2 = L3_2(L4_2)
  L1_2(L2_2, L3_2, L4_2, L5_2, L6_2)
  L1_2 = GetPedRelationshipGroupHash
  L2_2 = PlayerPedId
  L2_2, L3_2, L4_2, L5_2, L6_2 = L2_2()
  L1_2 = L1_2(L2_2, L3_2, L4_2, L5_2, L6_2)
  L2_2 = SetRelationshipBetweenGroups
  L3_2 = 1
  L4_2 = GetHashKey
  L5_2 = "AMBIENT_GANG_FAMILY"
  L4_2 = L4_2(L5_2)
  L5_2 = L1_2
  L2_2(L3_2, L4_2, L5_2)
  L2_2 = SetRelationshipBetweenGroups
  L3_2 = 1
  L4_2 = L1_2
  L5_2 = GetHashKey
  L6_2 = "AMBIENT_GANG_FAMILY"
  L5_2, L6_2 = L5_2(L6_2)
  L2_2(L3_2, L4_2, L5_2, L6_2)
  L2_2 = SetEntityInvincible
  L3_2 = A0_2
  L2_2(L3_2)
  L2_2 = FreezeEntityPosition
  L3_2 = A0_2
  L4_2 = true
  L2_2(L3_2, L4_2)
  L2_2 = SetPedConfigFlag
  L3_2 = A0_2
  L4_2 = 24
  L5_2 = true
  L2_2(L3_2, L4_2, L5_2)
  L2_2 = SetPedConfigFlag
  L3_2 = A0_2
  L4_2 = 43
  L5_2 = true
  L2_2(L3_2, L4_2, L5_2)
  L2_2 = SetPedConfigFlag
  L3_2 = A0_2
  L4_2 = 122
  L5_2 = true
  L2_2(L3_2, L4_2, L5_2)
  L2_2 = SetPedConfigFlag
  L3_2 = A0_2
  L4_2 = 128
  L5_2 = false
  L2_2(L3_2, L4_2, L5_2)
  L2_2 = SetPedConfigFlag
  L3_2 = A0_2
  L4_2 = 188
  L5_2 = true
  L2_2(L3_2, L4_2, L5_2)
  L2_2 = DisablePedPainAudio
  L3_2 = A0_2
  L4_2 = true
  L2_2(L3_2, L4_2)
  L2_2 = SetCanAttackFriendly
  L3_2 = A0_2
  L4_2 = false
  L5_2 = false
  L2_2(L3_2, L4_2, L5_2)
  L2_2 = SetPedRagdollOnCollision
  L3_2 = A0_2
  L4_2 = false
  L2_2(L3_2, L4_2)
  L2_2 = SetRagdollBlockingFlags
  L3_2 = A0_2
  L4_2 = 1
  L2_2(L3_2, L4_2)
  L2_2 = SetEntityInvincible
  L3_2 = A0_2
  L4_2 = true
  L2_2(L3_2, L4_2)
  L2_2 = SetBlockingOfNonTemporaryEvents
  L3_2 = A0_2
  L4_2 = true
  L2_2(L3_2, L4_2)
end
setPedImmutable = L0_1
function L0_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2
  L3_2 = RequestModel
  L4_2 = A0_2
  L3_2(L4_2)
  while true do
    L3_2 = HasModelLoaded
    L4_2 = A0_2
    L3_2 = L3_2(L4_2)
    if L3_2 then
      break
    end
    L3_2 = Citizen
    L3_2 = L3_2.Wait
    L4_2 = 0
    L3_2(L4_2)
  end
  L3_2 = CreatePed
  L4_2 = 0
  L5_2 = A0_2
  L6_2 = A1_2
  L7_2 = A2_2
  L8_2 = false
  L9_2 = false
  L3_2 = L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2)
  L4_2 = setPedImmutable
  L5_2 = L3_2
  L4_2(L5_2)
  L4_2 = "anim@amb@nightclub@peds@"
  L5_2 = "rcmme_amanda1_stand_loop_cop"
  L6_2 = RequestAnimDict
  L7_2 = L4_2
  L6_2(L7_2)
  while true do
    L6_2 = HasAnimDictLoaded
    L7_2 = L4_2
    L6_2 = L6_2(L7_2)
    if L6_2 then
      break
    end
    L6_2 = Citizen
    L6_2 = L6_2.Wait
    L7_2 = 0
    L6_2(L7_2)
  end
  L6_2 = TaskPlayAnim
  L7_2 = L3_2
  L8_2 = L4_2
  L9_2 = L5_2
  L10_2 = 4.0
  L11_2 = 4.0
  L12_2 = -1
  L13_2 = 1
  L14_2 = 1.0
  L15_2 = false
  L16_2 = false
  L17_2 = false
  L6_2(L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2)
  return L3_2
end
spawnNPC = L0_1
function L0_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2
  L2_2 = Framework
  L2_2 = L2_2.showNotification
  L3_2 = A0_2
  L4_2 = A1_2
  L2_2(L3_2, L4_2)
end
L1_1 = addScriptRemovableEvent
L2_1 = RegisterNetEvent
L3_1 = Utils
L3_1 = L3_1.eventsPrefix
L4_1 = ":notify"
L3_1 = L3_1 .. L4_1
L4_1 = L0_1
L2_1, L3_1, L4_1, L5_1, L6_1, L7_1, L8_1 = L2_1(L3_1, L4_1)
L1_1(L2_1, L3_1, L4_1, L5_1, L6_1, L7_1, L8_1)
function L1_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2
  L2_2 = A0_2
  L1_2 = A0_2.gsub
  L3_2 = "~.~"
  L4_2 = ""
  L1_2 = L1_2(L2_2, L3_2, L4_2)
  L2_2 = TriggerEvent
  L3_2 = Utils
  L3_2 = L3_2.eventsPrefix
  L4_2 = ":notify"
  L3_2 = L3_2 .. L4_2
  L4_2 = A0_2
  L5_2 = L1_2
  L2_2(L3_2, L4_2, L5_2)
end
notifyClient = L1_1
L1_1 = RegisterNetEvent
L2_1 = Utils
L2_1 = L2_1.eventsPrefix
L3_1 = ":notifyClient"
L2_1 = L2_1 .. L3_1
L3_1 = notifyClient
L1_1(L2_1, L3_1)
function L1_1(A0_2)
  local L1_2, L2_2
  L1_2 = Framework
  L1_2 = L1_2.showHelpNotification
  L2_2 = A0_2
  L1_2(L2_2)
end
showHelpNotification = L1_1
function L1_1(A0_2)
  local L1_2
  showHelpNotification = A0_2
end
L2_1 = exports
L3_1 = "replaceShowHelpNotification"
L4_1 = L1_1
L2_1(L3_1, L4_1)
function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
  L0_2 = PlayerPedId
  L0_2 = L0_2()
  L1_2 = GetEntityCoords
  L2_2 = L0_2
  L1_2 = L1_2(L2_2)
  L2_2 = vector3
  L3_2 = 0.0
  L4_2 = 0.0
  L5_2 = 1.0
  L2_2 = L2_2(L3_2, L4_2, L5_2)
  L1_2 = L1_2 - L2_2
  L2_2 = {}
  L3_2 = string
  L3_2 = L3_2.format
  L4_2 = "%.2f"
  L5_2 = L1_2.x
  L3_2 = L3_2(L4_2, L5_2)
  L2_2.x = L3_2
  L3_2 = string
  L3_2 = L3_2.format
  L4_2 = "%.2f"
  L5_2 = L1_2.y
  L3_2 = L3_2(L4_2, L5_2)
  L2_2.y = L3_2
  L3_2 = string
  L3_2 = L3_2.format
  L4_2 = "%.2f"
  L5_2 = L1_2.z
  L3_2 = L3_2(L4_2, L5_2)
  L2_2.z = L3_2
  return L2_2
end
L3_1 = RegisterNUICallback
L4_1 = "getCurrentCoords"
function L5_1(A0_2, A1_2)
  local L2_2, L3_2
  L2_2 = A1_2
  L3_2 = L2_1
  L3_2 = L3_2()
  L2_2(L3_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterNUICallback
L4_1 = "getCurrentCoordsAndHeading"
function L5_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L2_2 = PlayerPedId
  L2_2 = L2_2()
  L3_2 = GetEntityHeading
  L4_2 = L2_2
  L3_2 = L3_2(L4_2)
  L4_2 = {}
  L5_2 = L2_1
  L5_2 = L5_2()
  L4_2.coords = L5_2
  L5_2 = string
  L5_2 = L5_2.format
  L6_2 = "%.2f"
  L7_2 = L3_2
  L5_2 = L5_2(L6_2, L7_2)
  L4_2.heading = L5_2
  L5_2 = A1_2
  L6_2 = L4_2
  L5_2(L6_2)
end
L3_1(L4_1, L5_1)
function L3_1(A0_2, A1_2, A2_2, A3_2, A4_2)
  local L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2
  L5_2 = GetResourceKvpString
  L6_2 = A2_2
  L7_2 = "_command"
  L6_2 = L6_2 .. L7_2
  L7_2 = nil
  L5_2 = L5_2(L6_2, L7_2)
  L6_2 = GetResourceKvpString
  L7_2 = A2_2
  L8_2 = nil
  L6_2 = L6_2(L7_2, L8_2)
  if not (L6_2 == A1_2 and L6_2) or not L5_2 then
    L7_2 = SetResourceKvp
    L8_2 = A2_2
    L9_2 = A1_2
    L7_2(L8_2, L9_2)
    L7_2 = ""
    L8_2 = 1
    L9_2 = 5
    L10_2 = 1
    for L11_2 = L8_2, L9_2, L10_2 do
      L12_2 = string
      L12_2 = L12_2.char
      L13_2 = math
      L13_2 = L13_2.random
      L14_2 = 97
      L15_2 = 122
      L13_2, L14_2, L15_2 = L13_2(L14_2, L15_2)
      L12_2 = L12_2(L13_2, L14_2, L15_2)
      L13_2 = L7_2
      L14_2 = L12_2
      L13_2 = L13_2 .. L14_2
      L7_2 = L13_2
    end
    L8_2 = A0_2
    L9_2 = "_"
    L10_2 = L7_2
    L8_2 = L8_2 .. L9_2 .. L10_2
    L5_2 = L8_2
    L8_2 = SetResourceKvp
    L9_2 = A2_2
    L10_2 = "_command"
    L9_2 = L9_2 .. L10_2
    L10_2 = L5_2
    L8_2(L9_2, L10_2)
  else
    L7_2 = GetResourceKvpString
    L8_2 = A2_2
    L9_2 = "_command"
    L8_2 = L8_2 .. L9_2
    L9_2 = A0_2
    L7_2 = L7_2(L8_2, L9_2)
    L5_2 = L7_2
  end
  L7_2 = RegisterCommand
  L8_2 = L5_2
  L9_2 = A4_2
  L10_2 = false
  L7_2(L8_2, L9_2, L10_2)
  L7_2 = RegisterKeyMapping
  L8_2 = L5_2
  L9_2 = A3_2
  L10_2 = "keyboard"
  L11_2 = A1_2
  L7_2(L8_2, L9_2, L10_2, L11_2)
end
registerAdvancedKeymap = L3_1
L3_1 = nil
function L4_1(A0_2, A1_2)
  local L2_2, L3_2
  L2_2 = SendNUIMessage
  L3_2 = {}
  L3_2.action = "progressBar"
  L3_2.time = A0_2
  L3_2.text = A1_2
  L2_2(L3_2)
end
L5_1 = addScriptRemovableEvent
L6_1 = RegisterNetEvent
L7_1 = Utils
L7_1 = L7_1.eventsPrefix
L8_1 = ":internalProgressBar"
L7_1 = L7_1 .. L8_1
L8_1 = L4_1
L6_1, L7_1, L8_1 = L6_1(L7_1, L8_1)
L5_1(L6_1, L7_1, L8_1)
function L5_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2
  canUseMarkers = false
  L2_2 = TriggerEvent
  L3_2 = Utils
  L3_2 = L3_2.eventsPrefix
  L4_2 = ":internalProgressBar"
  L3_2 = L3_2 .. L4_2
  L4_2 = A0_2
  L5_2 = A1_2
  L2_2(L3_2, L4_2, L5_2)
  L2_2 = Timeout
  L3_2 = A0_2
  function L4_2()
    local L0_3, L1_3
    canUseMarkers = true
  end
  L2_2 = L2_2(L3_2, L4_2)
  L3_1 = L2_2
end
startProgressBar = L5_1
L5_1 = RegisterNetEvent
L6_1 = Utils
L6_1 = L6_1.eventsPrefix
L7_1 = ":startProgressBar"
L6_1 = L6_1 .. L7_1
L7_1 = startProgressBar
L5_1(L6_1, L7_1)
function L5_1()
  local L0_2, L1_2
  L0_2 = L3_1
  if L0_2 then
    L0_2 = ClearTimeout
    L1_2 = L3_1
    L0_2(L1_2)
    L0_2 = nil
    L3_1 = L0_2
  end
  L0_2 = SendNUIMessage
  L1_2 = {}
  L1_2.action = "stopProgressBar"
  L0_2(L1_2)
  canUseMarkers = true
end
stopProgressBar = L5_1
L5_1 = Utils
function L6_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = DoesAnimDictExist
  L2_2 = A0_2
  L1_2 = L1_2(L2_2)
  if L1_2 then
    L1_2 = HasAnimDictLoaded
    L2_2 = A0_2
    L1_2 = L1_2(L2_2)
    if L1_2 then
      return
    end
    L1_2 = RequestAnimDict
    L2_2 = A0_2
    L1_2(L2_2)
    while true do
      L1_2 = HasAnimDictLoaded
      L2_2 = A0_2
      L1_2 = L1_2(L2_2)
      if L1_2 then
        break
      end
      L1_2 = Citizen
      L1_2 = L1_2.Wait
      L2_2 = 10
      L1_2(L2_2)
    end
  else
    L1_2 = print
    L2_2 = "^1Impossible to load anim dict ^3"
    L3_2 = A0_2
    L4_2 = "^7"
    L2_2 = L2_2 .. L3_2 .. L4_2
    L1_2(L2_2)
  end
end
L5_1.loadAnimDict = L6_1

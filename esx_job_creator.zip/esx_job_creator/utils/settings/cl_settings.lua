local L0_1, L1_1, L2_1
L0_1 = {}
Settings = L0_1
L0_1 = Settings
L1_1 = {}
L0_1.clientConfig = L1_1
L0_1 = Settings
function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = promise
  L0_2 = L0_2.new
  L0_2 = L0_2()
  L1_2 = TriggerServerCallback
  L2_2 = Utils
  L2_2 = L2_2.eventsPrefix
  L3_2 = ":getClientConfiguration"
  L2_2 = L2_2 .. L3_2
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3
    L1_3 = Settings
    L1_3.clientConfig = A0_3
    L1_3 = Settings
    L1_3 = L1_3.clientConfig
    config = L1_3
    L1_3 = print
    L2_3 = "Configuration loaded"
    L1_3(L2_3)
    L1_3 = TriggerEvent
    L2_3 = Utils
    L2_3 = L2_3.eventsPrefix
    L3_3 = ":clientConfigLoaded"
    L2_3 = L2_3 .. L3_3
    L1_3(L2_3)
    L1_3 = L0_2
    L2_3 = L1_3
    L1_3 = L1_3.resolve
    L3_3 = true
    L1_3(L2_3, L3_3)
  end
  L1_2(L2_2, L3_2)
  L1_2 = Citizen
  L1_2 = L1_2.Await
  L2_2 = L0_2
  return L1_2(L2_2)
end
L0_1.loadConfig = L1_1
L0_1 = RegisterNetEvent
L1_1 = Utils
L1_1 = L1_1.eventsPrefix
L2_1 = ":updateClientSettings"
L1_1 = L1_1 .. L2_1
L2_1 = Settings
L2_1 = L2_1.loadConfig
L0_1(L1_1, L2_1)
L0_1 = RegisterNUICallback
L1_1 = "saveSettings"
function L2_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2
  L2_2 = TriggerServerEvent
  L3_2 = Utils
  L3_2 = L3_2.eventsPrefix
  L4_2 = ":updateSettings"
  L3_2 = L3_2 .. L4_2
  L4_2 = A0_2.serverSettings
  L5_2 = A0_2.sharedSettings
  L6_2 = A0_2.clientSettings
  L2_2(L3_2, L4_2, L5_2, L6_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNUICallback
L1_1 = "getDefaultConfiguration"
function L2_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2
  L2_2 = TriggerServerCallback
  L3_2 = Utils
  L3_2 = L3_2.eventsPrefix
  L4_2 = ":getDefaultConfiguration"
  L3_2 = L3_2 .. L4_2
  function L4_2(A0_3)
    local L1_3, L2_3
    L1_3 = A1_2
    L2_3 = A0_3
    L1_3(L2_3)
  end
  L2_2(L3_2, L4_2)
end
L0_1(L1_1, L2_1)

local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1, L8_1, L9_1
L0_1 = CURRENT_FRAMEWORK
L1_1 = Framework
function L2_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L3_2 = L0_1
  if "ESX" == L3_2 then
    L3_2 = ESX
    L3_2 = L3_2.GetPlayerFromId
    L4_2 = A0_2
    L3_2 = L3_2(L4_2)
    L4_2 = L3_2.getInventoryItem
    L5_2 = A1_2
    L4_2 = L4_2(L5_2)
    if L4_2 then
      L5_2 = L4_2.count
      L5_2 = A2_2 <= L5_2
      return L5_2
    else
      L5_2 = print
      L6_2 = "^1Item '"
      L7_2 = A1_2
      L8_2 = "' doesn't exists^7"
      L6_2 = L6_2 .. L7_2 .. L8_2
      L5_2(L6_2)
      L5_2 = false
      return L5_2
    end
  else
    L3_2 = L0_1
    if "QB-core" == L3_2 then
      L3_2 = QBCore
      L3_2 = L3_2.Functions
      L3_2 = L3_2.GetPlayer
      L4_2 = A0_2
      L3_2 = L3_2(L4_2)
      if L3_2 then
        L4_2 = L3_2.Functions
        L4_2 = L4_2.GetItemByName
        L5_2 = A1_2
        L4_2 = L4_2(L5_2)
        if L4_2 then
          L5_2 = L4_2.amount
          L5_2 = A2_2 <= L5_2
          return L5_2
        end
      end
    end
  end
end
L1_1.hasPlayerEnoughOfItem = L2_1
L1_1 = Framework
function L2_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L2_2 = L0_1
  if "ESX" == L2_2 then
    L2_2 = ESX
    L2_2 = L2_2.GetPlayerFromId
    L3_2 = A0_2
    L2_2 = L2_2(L3_2)
    L3_2 = L2_2.getInventoryItem
    L4_2 = A1_2
    L3_2 = L3_2(L4_2)
    if L3_2 then
      L4_2 = L3_2.count
      return L4_2
    else
      L4_2 = print
      L5_2 = "^1Item '"
      L6_2 = A1_2
      L7_2 = "' doesn't exists^7"
      L5_2 = L5_2 .. L6_2 .. L7_2
      L4_2(L5_2)
      L4_2 = 0
      return L4_2
    end
  else
    L2_2 = L0_1
    if "QB-core" == L2_2 then
      L2_2 = QBCore
      L2_2 = L2_2.Functions
      L2_2 = L2_2.GetPlayer
      L3_2 = A0_2
      L2_2 = L2_2(L3_2)
      if L2_2 then
        L3_2 = L2_2.Functions
        L3_2 = L3_2.GetItemByName
        L4_2 = A1_2
        L3_2 = L3_2(L4_2)
        if L3_2 then
          L4_2 = L3_2.amount
          return L4_2
        else
          L4_2 = 0
          return L4_2
        end
      end
    end
  end
end
L1_1.getPlayerItemCount = L2_1
L1_1 = Framework
function L2_1(A0_2)
  local L1_2, L2_2
  L1_2 = L0_1
  if "ESX" == L1_2 then
    L1_2 = ESX
    L1_2 = L1_2.GetPlayerFromId
    L2_2 = A0_2
    L1_2 = L1_2(L2_2)
    if L1_2 then
      L2_2 = L1_2.job
      L2_2 = L2_2.name
      return L2_2
    end
  else
    L1_2 = L0_1
    if "QB-core" == L1_2 then
      L1_2 = QBCore
      L1_2 = L1_2.Functions
      L1_2 = L1_2.GetPlayer
      L2_2 = A0_2
      L1_2 = L1_2(L2_2)
      if L1_2 then
        L2_2 = L1_2.PlayerData
        L2_2 = L2_2.job
        L2_2 = L2_2.name
        return L2_2
      end
    end
  end
end
L1_1.getPlayerJobName = L2_1
L1_1 = Framework
function L2_1(A0_2)
  local L1_2, L2_2
  L1_2 = L0_1
  if "ESX" == L1_2 then
    L1_2 = ESX
    L1_2 = L1_2.GetPlayerFromId
    L2_2 = A0_2
    L1_2 = L1_2(L2_2)
    if L1_2 then
      L2_2 = L1_2.job
      L2_2 = L2_2.grade
      return L2_2
    end
  else
    L1_2 = L0_1
    if "QB-core" == L1_2 then
      L1_2 = QBCore
      L1_2 = L1_2.Functions
      L1_2 = L1_2.GetPlayer
      L2_2 = A0_2
      L1_2 = L1_2(L2_2)
      if L1_2 then
        L2_2 = L1_2.PlayerData
        L2_2 = L2_2.job
        L2_2 = L2_2.grade
        L2_2 = L2_2.level
        return L2_2
      end
    end
  end
end
L1_1.getPlayerJobGrade = L2_1
L1_1 = Framework
function L2_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2
  L2_2 = L0_1
  if "ESX" == L2_2 then
    L2_2 = ESX
    L2_2 = L2_2.RegisterUsableItem
    L3_2 = A0_2
    L4_2 = A1_2
    L2_2(L3_2, L4_2)
  else
    L2_2 = L0_1
    if "QB-core" == L2_2 then
      L2_2 = QBCore
      L2_2 = L2_2.Functions
      L2_2 = L2_2.CreateUseableItem
      L3_2 = A0_2
      L4_2 = A1_2
      L2_2(L3_2, L4_2)
    end
  end
end
L1_1.registerUsableItem = L2_1
L1_1 = Framework
function L2_1(A0_2)
  local L1_2, L2_2
  L1_2 = L0_1
  if "ESX" == L1_2 then
    L1_2 = ESX
    L1_2 = L1_2.GetItemLabel
    L2_2 = A0_2
    return L1_2(L2_2)
  else
    L1_2 = L0_1
    if "QB-core" == L1_2 then
      L1_2 = QBCore
      L1_2 = L1_2.Shared
      L1_2 = L1_2.Items
      L1_2 = L1_2[A0_2]
      if L1_2 then
        L2_2 = L1_2.label
        return L2_2
      else
        L2_2 = nil
        return L2_2
      end
    end
  end
end
L1_1.getItemLabel = L2_1
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = promise
  L0_2 = L0_2.new
  L0_2 = L0_2()
  L1_2 = MySQL
  L1_2 = L1_2.Async
  L1_2 = L1_2.fetchAll
  L2_2 = "SELECT name, label FROM items"
  L3_2 = {}
  function L4_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L1_3 = {}
    L2_3 = 1
    L3_3 = #A0_3
    L4_3 = 1
    for L5_3 = L2_3, L3_3, L4_3 do
      L6_3 = A0_3[L5_3]
      L6_3 = L6_3.name
      L7_3 = A0_3[L5_3]
      L1_3[L6_3] = L7_3
    end
    L2_3 = L0_2
    L3_3 = L2_3
    L2_3 = L2_3.resolve
    L4_3 = L1_3
    L2_3(L3_3, L4_3)
  end
  L1_2(L2_2, L3_2, L4_2)
  L1_2 = Citizen
  L1_2 = L1_2.Await
  L2_2 = L0_2
  return L1_2(L2_2)
end
L2_1 = Framework
function L3_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L0_2 = L0_1
  if "ESX" == L0_2 then
    L0_2 = ESX
    L0_2 = L0_2.Items
    L1_2 = INVENTORY_TO_USE
    if "ox-inventory" == L1_2 then
      L1_2 = exports
      L2_2 = EXTERNAL_SCRIPTS_NAMES
      L2_2 = L2_2.ox_inventory
      L1_2 = L1_2[L2_2]
      L1_2 = L1_2.Items
      L1_2 = L1_2()
      L0_2 = L1_2
    end
    L1_2 = 0
    L2_2 = pairs
    L3_2 = L0_2
    L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
    for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
      L1_2 = L1_2 + 1
      break
    end
    if 0 == L1_2 then
      L2_2 = L1_1
      L2_2 = L2_2()
      L0_2 = L2_2
    end
    return L0_2
  else
    L0_2 = L0_1
    if "QB-core" == L0_2 then
      L0_2 = QBCore
      L0_2 = L0_2.Shared
      L0_2 = L0_2.Items
      return L0_2
    end
  end
end
L2_1.getAllItems = L3_1
L2_1 = Framework
function L3_1()
  local L0_2, L1_2
  L0_2 = L0_1
  if "ESX" == L0_2 then
    L0_2 = ESX
    L0_2 = L0_2.GetWeaponList
    return L0_2()
  else
    L0_2 = L0_1
    if "QB-core" == L0_2 then
      L0_2 = QBCore
      L0_2 = L0_2.Shared
      L0_2 = L0_2.Weapons
      return L0_2
    end
  end
end
L2_1.getAllWeapons = L3_1
L2_1 = Framework
function L3_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2
  L3_2 = config
  L3_2 = L3_2.canAlwaysCarryItem
  if L3_2 then
    L3_2 = true
    return L3_2
  end
  L3_2 = false
  L4_2 = L0_1
  if "ESX" == L4_2 then
    L4_2 = ESX
    L4_2 = L4_2.GetPlayerFromId
    L5_2 = A0_2
    L4_2 = L4_2(L5_2)
    L5_2 = L4_2.canCarryItem
    if L5_2 then
      L5_2 = L4_2.canCarryItem
      L6_2 = A1_2
      L7_2 = A2_2
      L5_2 = L5_2(L6_2, L7_2)
      L3_2 = L5_2
    else
      L5_2 = L4_2.getInventoryItem
      L6_2 = A1_2
      L5_2 = L5_2(L6_2)
      if L5_2 then
        L6_2 = L5_2.limit
        L3_2 = -1 == L6_2
      else
        L6_2 = true
        return L6_2
      end
    end
  else
    L4_2 = L0_1
    if "QB-core" == L4_2 then
      L3_2 = true
    end
  end
  return L3_2
end
L2_1.canPlayerCarryItem = L3_1
L2_1 = Framework
function L3_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2
  L3_2 = L0_1
  if "ESX" == L3_2 then
    L3_2 = Framework
    L3_2 = L3_2.canPlayerCarryItem
    L4_2 = A0_2
    L5_2 = A1_2
    L6_2 = A2_2
    L3_2 = L3_2(L4_2, L5_2, L6_2)
    if L3_2 then
      L3_2 = ESX
      L3_2 = L3_2.GetPlayerFromId
      L4_2 = A0_2
      L3_2 = L3_2(L4_2)
      L4_2 = L3_2.addInventoryItem
      L5_2 = A1_2
      L6_2 = A2_2
      L4_2(L5_2, L6_2)
      L4_2 = true
      return L4_2
    else
      L3_2 = false
      return L3_2
    end
  else
    L3_2 = L0_1
    if "QB-core" == L3_2 then
      L3_2 = QBCore
      L3_2 = L3_2.Functions
      L3_2 = L3_2.GetPlayer
      L4_2 = A0_2
      L3_2 = L3_2(L4_2)
      if L3_2 then
        L4_2 = L3_2.Functions
        L4_2 = L4_2.AddItem
        L5_2 = A1_2
        L6_2 = A2_2
        return L4_2(L5_2, L6_2)
      else
        L4_2 = false
        return L4_2
      end
    end
  end
end
L2_1.giveItemToPlayer = L3_1
L2_1 = Framework
function L3_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2
  L3_2 = L0_1
  if "ESX" == L3_2 then
    L3_2 = ESX
    L3_2 = L3_2.GetPlayerFromId
    L4_2 = A0_2
    L3_2 = L3_2(L4_2)
    L4_2 = L3_2.getInventoryItem
    L5_2 = A1_2
    L4_2 = L4_2(L5_2)
    L4_2 = L4_2.count
    if A2_2 <= L4_2 then
      L4_2 = L3_2.removeInventoryItem
      L5_2 = A1_2
      L6_2 = A2_2
      L4_2(L5_2, L6_2)
      L4_2 = true
      return L4_2
    else
      L4_2 = false
      return L4_2
    end
  else
    L3_2 = L0_1
    if "QB-core" == L3_2 then
      L3_2 = QBCore
      L3_2 = L3_2.Functions
      L3_2 = L3_2.GetPlayer
      L4_2 = A0_2
      L3_2 = L3_2(L4_2)
      if L3_2 then
        L4_2 = L3_2.Functions
        L4_2 = L4_2.RemoveItem
        L5_2 = A1_2
        L6_2 = A2_2
        return L4_2(L5_2, L6_2)
      else
        L4_2 = false
        return L4_2
      end
    end
  end
end
L2_1.removeItemFromPlayer = L3_1
L2_1 = Framework
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L1_2 = L0_1
  if "ESX" == L1_2 then
    L1_2 = SKIP_ITEM_EXISTS_CHECK
    if L1_2 then
      L1_2 = true
      return L1_2
    end
    L1_2 = ESX
    L1_2 = L1_2.Items
    L2_2 = INVENTORY_TO_USE
    if "ox-inventory" == L2_2 then
      L2_2 = exports
      L3_2 = EXTERNAL_SCRIPTS_NAMES
      L3_2 = L3_2.ox_inventory
      L2_2 = L2_2[L3_2]
      L2_2 = L2_2.Items
      L2_2 = L2_2()
      L1_2 = L2_2
    end
    L2_2 = 0
    L3_2 = pairs
    L4_2 = L1_2
    L3_2, L4_2, L5_2, L6_2 = L3_2(L4_2)
    for L7_2, L8_2 in L3_2, L4_2, L5_2, L6_2 do
      L2_2 = L2_2 + 1
      break
    end
    if 0 == L2_2 then
      L3_2 = L1_1
      L3_2 = L3_2()
      L1_2 = L3_2
      L3_2 = ESX
      L3_2.Items = L1_2
    end
    L3_2 = L1_2[A0_2]
    if L3_2 then
      L3_2 = true
      if L3_2 then
        goto lbl_46
      end
    end
    L3_2 = false
    ::lbl_46::
    return L3_2
  else
    L1_2 = L0_1
    if "QB-core" == L1_2 then
      L1_2 = QBCore
      L1_2 = L1_2.Shared
      L1_2 = L1_2.Items
      L1_2 = L1_2[A0_2]
      L1_2 = nil ~= L1_2
      return L1_2
    end
  end
end
L2_1.doesItemExists = L3_1
L2_1 = Framework
function L3_1()
  local L0_2, L1_2
  L0_2 = L0_1
  if "ESX" == L0_2 then
    L0_2 = ESX
    L0_2 = L0_2.Jobs
    return L0_2
  else
    L0_2 = L0_1
    if "QB-core" == L0_2 then
      L0_2 = QBCore
      L0_2 = L0_2.Shared
      L0_2 = L0_2.Jobs
      return L0_2
    end
  end
end
L2_1.getAllJobs = L3_1
L2_1 = Framework
function L3_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2
  L3_2 = L0_1
  if "ESX" == L3_2 then
    L3_2 = ESX
    L3_2 = L3_2.GetPlayerFromId
    L4_2 = A0_2
    L3_2 = L3_2(L4_2)
    L4_2 = L3_2.getAccount
    L5_2 = A1_2
    L4_2 = L4_2(L5_2)
    if L4_2 then
      L5_2 = L3_2.addAccountMoney
      L6_2 = A1_2
      L7_2 = A2_2
      L5_2(L6_2, L7_2)
    elseif "money" == A1_2 then
      L5_2 = L3_2.addMoney
      L6_2 = A2_2
      L5_2(L6_2)
    end
  else
    L3_2 = L0_1
    if "QB-core" == L3_2 then
      L3_2 = QBCore
      L3_2 = L3_2.Functions
      L3_2 = L3_2.GetPlayer
      L4_2 = A0_2
      L3_2 = L3_2(L4_2)
      if L3_2 then
        if "black_money" == A1_2 then
          L4_2 = Framework
          L4_2 = L4_2.giveBlackMoneyValue
          L5_2 = A0_2
          L6_2 = A2_2
          L4_2(L5_2, L6_2)
        else
          L4_2 = L3_2.Functions
          L4_2 = L4_2.AddMoney
          L5_2 = A1_2
          L6_2 = A2_2
          L4_2(L5_2, L6_2)
        end
      end
    end
  end
end
L2_1.giveAccountMoneyToPlayer = L3_1
L2_1 = Framework
function L3_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2
  L2_2 = L0_1
  if "ESX" == L2_2 then
    L2_2 = ESX
    L2_2 = L2_2.GetPlayerFromId
    L3_2 = A0_2
    L2_2 = L2_2(L3_2)
    L3_2 = L2_2.addMoney
    L4_2 = A1_2
    L3_2(L4_2)
  else
    L2_2 = L0_1
    if "QB-core" == L2_2 then
      L2_2 = QBCore
      L2_2 = L2_2.Functions
      L2_2 = L2_2.GetPlayer
      L3_2 = A0_2
      L2_2 = L2_2(L3_2)
      L3_2 = L2_2.Functions
      L3_2 = L3_2.AddMoney
      L4_2 = "cash"
      L5_2 = A1_2
      L3_2(L4_2, L5_2)
    end
  end
end
L2_1.giveCashToPlayer = L3_1
L2_1 = Framework
function L3_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L3_2 = L0_1
  if "ESX" == L3_2 then
    L3_2 = ESX
    L3_2 = L3_2.GetPlayerFromIdentifier
    L4_2 = A0_2
    L3_2 = L3_2(L4_2)
    if L3_2 then
      L4_2 = L3_2.addAccountMoney
      L5_2 = A1_2
      L6_2 = A2_2
      L4_2(L5_2, L6_2)
      L4_2 = true
      return L4_2
    else
      L4_2 = promise
      L4_2 = L4_2.new
      L4_2 = L4_2()
      L5_2 = MySQL
      L5_2 = L5_2.Async
      L5_2 = L5_2.fetchScalar
      L6_2 = "SELECT accounts FROM users WHERE identifier=@identifier"
      L7_2 = {}
      L7_2["@identifier"] = A0_2
      function L8_2(A0_3)
        local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3
        if A0_3 then
          L1_3 = json
          L1_3 = L1_3.decode
          L2_3 = A0_3
          L1_3 = L1_3(L2_3)
          L2_3 = A1_2
          L3_3 = A1_2
          L3_3 = L1_3[L3_3]
          L4_3 = A2_2
          L3_3 = L3_3 + L4_3
          L1_3[L2_3] = L3_3
          L2_3 = MySQL
          L2_3 = L2_3.Async
          L2_3 = L2_3.execute
          L3_3 = "UPDATE users SET accounts=@accounts WHERE identifier=@identifier"
          L4_3 = {}
          L5_3 = A0_2
          L4_3["@identifier"] = L5_3
          L5_3 = json
          L5_3 = L5_3.encode
          L6_3 = L1_3
          L5_3 = L5_3(L6_3)
          L4_3["@accounts"] = L5_3
          function L5_3(A0_4)
            local L1_4, L2_4, L3_4
            L1_4 = L4_2
            L2_4 = L1_4
            L1_4 = L1_4.resolve
            L3_4 = A0_4 > 0
            L1_4(L2_4, L3_4)
          end
          L2_3(L3_3, L4_3, L5_3)
        else
          L1_3 = L4_2
          L2_3 = L1_3
          L1_3 = L1_3.resolve
          L3_3 = false
          L1_3(L2_3, L3_3)
        end
      end
      L5_2(L6_2, L7_2, L8_2)
      L5_2 = Citizen
      L5_2 = L5_2.Await
      L6_2 = L4_2
      return L5_2(L6_2)
    end
  else
    L3_2 = L0_1
    if "QB-core" == L3_2 then
      L3_2 = QBCore
      L3_2 = L3_2.Functions
      L3_2 = L3_2.GetSource
      L4_2 = A0_2
      L3_2 = L3_2(L4_2)
      if L3_2 and 0 ~= L3_2 then
        L4_2 = QBCore
        L4_2 = L4_2.Functions
        L4_2 = L4_2.GetPlayer
        L5_2 = L3_2
        L4_2 = L4_2(L5_2)
        if L4_2 then
          L5_2 = L4_2.Functions
          L5_2 = L5_2.AddMoney
          L6_2 = A1_2
          L7_2 = A2_2
          L5_2(L6_2, L7_2)
          L5_2 = true
          return L5_2
        else
          L5_2 = false
          return L5_2
        end
      else
        L4_2 = promise
        L4_2 = L4_2.new
        L4_2 = L4_2()
        L5_2 = MySQL
        L5_2 = L5_2.Async
        L5_2 = L5_2.fetchScalar
        L6_2 = "SELECT money FROM players WHERE license=@identifier"
        L7_2 = {}
        L7_2["@identifier"] = A0_2
        function L8_2(A0_3)
          local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3
          if A0_3 then
            L1_3 = json
            L1_3 = L1_3.decode
            L2_3 = A0_3
            L1_3 = L1_3(L2_3)
            L2_3 = A1_2
            L3_3 = A1_2
            L3_3 = L1_3[L3_3]
            L4_3 = A2_2
            L3_3 = L3_3 + L4_3
            L1_3[L2_3] = L3_3
            L2_3 = MySQL
            L2_3 = L2_3.Async
            L2_3 = L2_3.execute
            L3_3 = "UPDATE players SET money=@accounts WHERE license=@identifier"
            L4_3 = {}
            L5_3 = A0_2
            L4_3["@identifier"] = L5_3
            L5_3 = json
            L5_3 = L5_3.encode
            L6_3 = L1_3
            L5_3 = L5_3(L6_3)
            L4_3["@accounts"] = L5_3
            function L5_3(A0_4)
              local L1_4, L2_4, L3_4
              L1_4 = L4_2
              L2_4 = L1_4
              L1_4 = L1_4.resolve
              L3_4 = A0_4 > 0
              L1_4(L2_4, L3_4)
            end
            L2_3(L3_3, L4_3, L5_3)
          else
            L1_3 = L4_2
            L2_3 = L1_3
            L1_3 = L1_3.resolve
            L3_3 = false
            L1_3(L2_3, L3_3)
          end
        end
        L5_2(L6_2, L7_2, L8_2)
        L5_2 = Citizen
        L5_2 = L5_2.Await
        L6_2 = L4_2
        return L5_2(L6_2)
      end
    end
  end
end
L2_1.giveAccountMoneyToIdentifier = L3_1
L2_1 = Framework
function L3_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L3_2 = L0_1
  if "ESX" == L3_2 then
    L3_2 = ESX
    L3_2 = L3_2.GetPlayerFromIdentifier
    L4_2 = A0_2
    L3_2 = L3_2(L4_2)
    if L3_2 then
      L4_2 = L3_2.getAccount
      L5_2 = A1_2
      L4_2 = L4_2(L5_2)
      if L4_2 then
        L5_2 = L3_2.removeAccountMoney
        L6_2 = A1_2
        L7_2 = A2_2
        L5_2(L6_2, L7_2)
        L5_2 = true
        return L5_2
      else
        if "money" == A1_2 then
          L5_2 = L3_2.removeMoney
          L6_2 = A2_2
          L5_2(L6_2)
          L5_2 = true
          return L5_2
        end
        L5_2 = false
        return L5_2
      end
    else
      L4_2 = promise
      L4_2 = L4_2.new
      L4_2 = L4_2()
      L5_2 = MySQL
      L5_2 = L5_2.Async
      L5_2 = L5_2.fetchScalar
      L6_2 = "SELECT accounts FROM users WHERE identifier=@identifier"
      L7_2 = {}
      L7_2["@identifier"] = A0_2
      function L8_2(A0_3)
        local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3
        if A0_3 then
          L1_3 = json
          L1_3 = L1_3.decode
          L2_3 = A0_3
          L1_3 = L1_3(L2_3)
          L2_3 = A1_2
          L3_3 = A1_2
          L3_3 = L1_3[L3_3]
          L4_3 = A2_2
          L3_3 = L3_3 - L4_3
          L1_3[L2_3] = L3_3
          L2_3 = MySQL
          L2_3 = L2_3.Async
          L2_3 = L2_3.execute
          L3_3 = "UPDATE users SET accounts=@accounts WHERE identifier=@identifier"
          L4_3 = {}
          L5_3 = A0_2
          L4_3["@identifier"] = L5_3
          L5_3 = json
          L5_3 = L5_3.encode
          L6_3 = L1_3
          L5_3 = L5_3(L6_3)
          L4_3["@accounts"] = L5_3
          function L5_3(A0_4)
            local L1_4, L2_4, L3_4
            L1_4 = L4_2
            L2_4 = L1_4
            L1_4 = L1_4.resolve
            L3_4 = A0_4 > 0
            L1_4(L2_4, L3_4)
          end
          L2_3(L3_3, L4_3, L5_3)
        else
          L1_3 = L4_2
          L2_3 = L1_3
          L1_3 = L1_3.resolve
          L3_3 = false
          L1_3(L2_3, L3_3)
        end
      end
      L5_2(L6_2, L7_2, L8_2)
      L5_2 = Citizen
      L5_2 = L5_2.Await
      L6_2 = L4_2
      return L5_2(L6_2)
    end
  else
    L3_2 = L0_1
    if "QB-core" == L3_2 then
      L3_2 = QBCore
      L3_2 = L3_2.Functions
      L3_2 = L3_2.GetSource
      L4_2 = A0_2
      L3_2 = L3_2(L4_2)
      if L3_2 and 0 ~= L3_2 then
        L4_2 = QBCore
        L4_2 = L4_2.Functions
        L4_2 = L4_2.GetPlayer
        L5_2 = L3_2
        L4_2 = L4_2(L5_2)
        if L4_2 then
          L5_2 = L4_2.Functions
          L5_2 = L5_2.RemoveMoney
          L6_2 = A1_2
          L7_2 = A2_2
          L5_2(L6_2, L7_2)
          L5_2 = true
          return L5_2
        else
          L5_2 = false
          return L5_2
        end
      else
        L4_2 = promise
        L4_2 = L4_2.new
        L4_2 = L4_2()
        L5_2 = MySQL
        L5_2 = L5_2.Async
        L5_2 = L5_2.fetchScalar
        L6_2 = "SELECT money FROM players WHERE license=@identifier"
        L7_2 = {}
        L7_2["@identifier"] = A0_2
        function L8_2(A0_3)
          local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3
          if A0_3 then
            L1_3 = json
            L1_3 = L1_3.decode
            L2_3 = A0_3
            L1_3 = L1_3(L2_3)
            L2_3 = A1_2
            L3_3 = A1_2
            L3_3 = L1_3[L3_3]
            L4_3 = A2_2
            L3_3 = L3_3 - L4_3
            L1_3[L2_3] = L3_3
            L2_3 = MySQL
            L2_3 = L2_3.Async
            L2_3 = L2_3.execute
            L3_3 = "UPDATE players SET money=@accounts WHERE license=@identifier"
            L4_3 = {}
            L5_3 = A0_2
            L4_3["@identifier"] = L5_3
            L5_3 = json
            L5_3 = L5_3.encode
            L6_3 = L1_3
            L5_3 = L5_3(L6_3)
            L4_3["@accounts"] = L5_3
            function L5_3(A0_4)
              local L1_4, L2_4, L3_4
              L1_4 = L4_2
              L2_4 = L1_4
              L1_4 = L1_4.resolve
              L3_4 = A0_4 > 0
              L1_4(L2_4, L3_4)
            end
            L2_3(L3_3, L4_3, L5_3)
          else
            L1_3 = L4_2
            L2_3 = L1_3
            L1_3 = L1_3.resolve
            L3_3 = false
            L1_3(L2_3, L3_3)
          end
        end
        L5_2(L6_2, L7_2, L8_2)
        L5_2 = Citizen
        L5_2 = L5_2.Await
        L6_2 = L4_2
        return L5_2(L6_2)
      end
    end
  end
end
L2_1.removeAccountMoneyFromIdentifier = L3_1
L2_1 = Framework
function L3_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L2_2 = L0_1
  if "ESX" == L2_2 then
    L2_2 = ESX
    L2_2 = L2_2.GetPlayerFromIdentifier
    L3_2 = A0_2
    L2_2 = L2_2(L3_2)
    if L2_2 then
      L3_2 = L2_2.getAccount
      L4_2 = A1_2
      L3_2 = L3_2(L4_2)
      if L3_2 then
        L4_2 = L3_2.money
        return L4_2
      elseif "money" == A1_2 then
        L4_2 = L2_2.getMoney
        return L4_2()
      end
    else
      L3_2 = promise
      L3_2 = L3_2.new
      L3_2 = L3_2()
      L4_2 = MySQL
      L4_2 = L4_2.Async
      L4_2 = L4_2.fetchScalar
      L5_2 = "SELECT accounts FROM users WHERE identifier=@identifier"
      L6_2 = {}
      L6_2["@identifier"] = A0_2
      function L7_2(A0_3)
        local L1_3, L2_3, L3_3, L4_3
        if A0_3 then
          L1_3 = json
          L1_3 = L1_3.decode
          L2_3 = A0_3
          L1_3 = L1_3(L2_3)
          L2_3 = L3_2
          L3_3 = L2_3
          L2_3 = L2_3.resolve
          L4_3 = A1_2
          L4_3 = L1_3[L4_3]
          L2_3(L3_3, L4_3)
        else
          L1_3 = L3_2
          L2_3 = L1_3
          L1_3 = L1_3.resolve
          L3_3 = 0
          L1_3(L2_3, L3_3)
        end
      end
      L4_2(L5_2, L6_2, L7_2)
      L4_2 = Citizen
      L4_2 = L4_2.Await
      L5_2 = L3_2
      return L4_2(L5_2)
    end
  else
    L2_2 = L0_1
    if "QB-core" == L2_2 then
      L2_2 = QBCore
      L2_2 = L2_2.Functions
      L2_2 = L2_2.GetSource
      L3_2 = A0_2
      L2_2 = L2_2(L3_2)
      if L2_2 and 0 ~= L2_2 then
        L3_2 = QBCore
        L3_2 = L3_2.Functions
        L3_2 = L3_2.GetPlayer
        L4_2 = L2_2
        L3_2 = L3_2(L4_2)
        if L3_2 then
          L4_2 = L3_2.PlayerData
          L4_2 = L4_2.money
          L4_2 = L4_2[A1_2]
          return L4_2
        else
          L4_2 = 0
          return L4_2
        end
      else
        L3_2 = promise
        L3_2 = L3_2.new
        L3_2 = L3_2()
        L4_2 = MySQL
        L4_2 = L4_2.Async
        L4_2 = L4_2.fetchScalar
        L5_2 = "SELECT money FROM players WHERE license=@identifier"
        L6_2 = {}
        L6_2["@identifier"] = A0_2
        function L7_2(A0_3)
          local L1_3, L2_3, L3_3, L4_3
          if A0_3 then
            L1_3 = json
            L1_3 = L1_3.decode
            L2_3 = A0_3
            L1_3 = L1_3(L2_3)
            L2_3 = L3_2
            L3_3 = L2_3
            L2_3 = L2_3.resolve
            L4_3 = A1_2
            L4_3 = L1_3[L4_3]
            L2_3(L3_3, L4_3)
          else
            L1_3 = L3_2
            L2_3 = L1_3
            L1_3 = L1_3.resolve
            L3_3 = 0
            L1_3(L2_3, L3_3)
          end
        end
        L4_2(L5_2, L6_2, L7_2)
        L4_2 = Citizen
        L4_2 = L4_2.Await
        L5_2 = L3_2
        return L4_2(L5_2)
      end
    end
  end
end
L2_1.getAccountMoneyFromIdentifier = L3_1
L2_1 = Framework
function L3_1(A0_2)
  local L1_2, L2_2
  L1_2 = L0_1
  if "ESX" == L1_2 then
    L1_2 = ESX
    L1_2 = L1_2.GetPlayerFromIdentifier
    L2_2 = A0_2
    L1_2 = L1_2(L2_2)
    if L1_2 then
      L2_2 = L1_2.source
      return L2_2
    else
      L2_2 = nil
      return L2_2
    end
  else
    L1_2 = L0_1
    if "QB-core" == L1_2 then
      L1_2 = QBCore
      L1_2 = L1_2.Functions
      L1_2 = L1_2.GetSource
      L2_2 = A0_2
      L1_2 = L1_2(L2_2)
      if L1_2 and 0 ~= L1_2 then
        return L1_2
      else
        L2_2 = nil
        return L2_2
      end
    end
  end
end
L2_1.getIdentifierPlayerId = L3_1
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2
  L1_2 = promise
  L1_2 = L1_2.new
  L1_2 = L1_2()
  L2_2 = MySQL
  L2_2 = L2_2.Async
  L2_2 = L2_2.execute
  L3_2 = "INSERT INTO management_funds(job_name, amount, type) VALUES (@jobName, 0, 'boss')"
  L4_2 = {}
  L4_2["@jobName"] = A0_2
  function L5_2(A0_3)
    local L1_3, L2_3, L3_3
    L1_3 = L1_2
    L2_3 = L1_3
    L1_3 = L1_3.resolve
    L3_3 = A0_3 > 0
    L1_3(L2_3, L3_3)
  end
  L2_2(L3_2, L4_2, L5_2)
  L2_2 = Citizen
  L2_2 = L2_2.Await
  L3_2 = L1_2
  return L2_2(L3_2)
end
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2
  L1_2 = promise
  L1_2 = L1_2.new
  L1_2 = L1_2()
  L2_2 = MySQL
  L2_2 = L2_2.Async
  L2_2 = L2_2.fetchScalar
  L3_2 = "SELECT 1 FROM management_funds WHERE job_name=@jobName and type='boss'"
  L4_2 = {}
  L4_2["@jobName"] = A0_2
  function L5_2(A0_3)
    local L1_3, L2_3, L3_3
    L1_3 = L1_2
    L2_3 = L1_3
    L1_3 = L1_3.resolve
    L3_3 = A0_3
    L1_3(L2_3, L3_3)
  end
  L2_2(L3_2, L4_2, L5_2)
  L2_2 = Citizen
  L2_2 = L2_2.Await
  L3_2 = L1_2
  return L2_2(L3_2)
end
L4_1 = Framework
function L5_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L2_2 = L0_1
  if "ESX" == L2_2 then
    L2_2 = promise
    L2_2 = L2_2.new
    L2_2 = L2_2()
    L3_2 = false
    L4_2 = "society_"
    L5_2 = A0_2
    L4_2 = L4_2 .. L5_2
    L5_2 = TriggerEvent
    L6_2 = EXTERNAL_EVENTS_NAMES
    L6_2 = L6_2["esx_addonaccount:getSharedAccount"]
    L7_2 = L4_2
    function L8_2(A0_3)
      local L1_3, L2_3, L3_3
      L1_3 = L3_2
      if L1_3 then
        return
      else
        L1_3 = true
        L3_2 = L1_3
      end
      if A0_3 then
        L1_3 = A0_3.addMoney
        L2_3 = A1_2
        L1_3(L2_3)
        L1_3 = L2_2
        L2_3 = L1_3
        L1_3 = L1_3.resolve
        L3_3 = true
        L1_3(L2_3, L3_3)
      else
        L1_3 = L2_2
        L2_3 = L1_3
        L1_3 = L1_3.resolve
        L3_3 = false
        L1_3(L2_3, L3_3)
      end
    end
    L5_2(L6_2, L7_2, L8_2)
    L5_2 = SetTimeout
    L6_2 = 500
    function L7_2()
      local L0_3, L1_3, L2_3
      L0_3 = L3_2
      if not L0_3 then
        L0_3 = L2_2
        L1_3 = L0_3
        L0_3 = L0_3.resolve
        L2_3 = false
        L0_3(L1_3, L2_3)
      end
    end
    L5_2(L6_2, L7_2)
    L5_2 = Citizen
    L5_2 = L5_2.Await
    L6_2 = L2_2
    return L5_2(L6_2)
  else
    L2_2 = L0_1
    if "QB-core" == L2_2 then
      L2_2 = PREFERRED_BOSS_SCRIPT
      if "qb-bossmenu" == L2_2 then
        L2_2 = TriggerEvent
        L3_2 = "qb-bossmenu:server:addAccountMoney"
        L4_2 = A0_2
        L5_2 = A1_2
        L2_2(L3_2, L4_2, L5_2)
      else
        L2_2 = PREFERRED_BOSS_SCRIPT
        if "qb-management" == L2_2 then
          L2_2 = L3_1
          L3_2 = A0_2
          L2_2 = L2_2(L3_2)
          if L2_2 then
            L2_2 = exports
            L3_2 = EXTERNAL_SCRIPTS_NAMES
            L3_2 = L3_2["qb-management"]
            L2_2 = L2_2[L3_2]
            L3_2 = L2_2
            L2_2 = L2_2.addMoney
            L4_2 = A0_2
            L5_2 = A1_2
            L2_2(L3_2, L4_2, L5_2)
          else
            L2_2 = L2_1
            L3_2 = A0_2
            L2_2 = L2_2(L3_2)
            if L2_2 then
              L3_2 = Framework
              L3_2 = L3_2.giveMoneyToSocietyAccount
              L4_2 = A0_2
              L5_2 = A1_2
              L3_2(L4_2, L5_2)
            else
              L3_2 = print
              L4_2 = "^1'"
              L5_2 = A0_2
              L6_2 = "' doesn't exist in qb-management, you have to add it in management_funds table in the database^7"
              L4_2 = L4_2 .. L5_2 .. L6_2
              L3_2(L4_2)
              L3_2 = false
              return L3_2
            end
          end
        else
          L2_2 = print
          L3_2 = "^1'"
          L4_2 = PREFERRED_BOSS_SCRIPT
          L5_2 = "' in sv_integrations.lua it's not a valid boss script^7"
          L3_2 = L3_2 .. L4_2 .. L5_2
          L2_2(L3_2)
          L2_2 = false
          return L2_2
        end
      end
      L2_2 = true
      return L2_2
    end
  end
end
L4_1.giveMoneyToSocietyAccount = L5_1
L4_1 = Framework
function L5_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L1_2 = L0_1
  if "ESX" == L1_2 then
    L1_2 = promise
    L1_2 = L1_2.new
    L1_2 = L1_2()
    L2_2 = "society_"
    L3_2 = A0_2
    L2_2 = L2_2 .. L3_2
    L3_2 = false
    L4_2 = TriggerEvent
    L5_2 = EXTERNAL_EVENTS_NAMES
    L5_2 = L5_2["esx_addonaccount:getSharedAccount"]
    L6_2 = L2_2
    function L7_2(A0_3)
      local L1_3, L2_3, L3_3
      L1_3 = L3_2
      if L1_3 then
        return
      else
        L1_3 = true
        L3_2 = L1_3
      end
      if A0_3 then
        L1_3 = L1_2
        L2_3 = L1_3
        L1_3 = L1_3.resolve
        L3_3 = A0_3.money
        L1_3(L2_3, L3_3)
      else
        L1_3 = L1_2
        L2_3 = L1_3
        L1_3 = L1_3.resolve
        L3_3 = false
        L1_3(L2_3, L3_3)
      end
    end
    L4_2(L5_2, L6_2, L7_2)
    L4_2 = SetTimeout
    L5_2 = 500
    function L6_2()
      local L0_3, L1_3, L2_3
      L0_3 = L3_2
      if not L0_3 then
        L0_3 = L1_2
        L1_3 = L0_3
        L0_3 = L0_3.resolve
        L2_3 = false
        L0_3(L1_3, L2_3)
      end
    end
    L4_2(L5_2, L6_2)
    L4_2 = Citizen
    L4_2 = L4_2.Await
    L5_2 = L1_2
    return L4_2(L5_2)
  else
    L1_2 = L0_1
    if "QB-core" == L1_2 then
      L1_2 = PREFERRED_BOSS_SCRIPT
      if "qb-bossmenu" == L1_2 then
        L1_2 = exports
        L2_2 = EXTERNAL_SCRIPTS_NAMES
        L2_2 = L2_2["qb-bossmenu"]
        L1_2 = L1_2[L2_2]
        L2_2 = L1_2
        L1_2 = L1_2.getJobMoney
        L3_2 = A0_2
        L1_2 = L1_2(L2_2, L3_2)
        return L1_2
      else
        L1_2 = PREFERRED_BOSS_SCRIPT
        if "qb-management" == L1_2 then
          L1_2 = exports
          L2_2 = EXTERNAL_SCRIPTS_NAMES
          L2_2 = L2_2["qb-management"]
          L1_2 = L1_2[L2_2]
          L2_2 = L1_2
          L1_2 = L1_2.getAccounts
          L3_2 = A0_2
          L1_2 = L1_2(L2_2, L3_2)
          if L1_2 then
            L2_2 = L1_2[A0_2]
            return L2_2
          else
            L2_2 = print
            L3_2 = "^1Couldn't get accounts from qb-management^7"
            L2_2(L3_2)
          end
        end
      end
    end
  end
end
L4_1.getSocietyAccountMoney = L5_1
L4_1 = Framework
function L5_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L2_2 = L0_1
  if "ESX" == L2_2 then
    L2_2 = promise
    L2_2 = L2_2.new
    L2_2 = L2_2()
    L3_2 = false
    L4_2 = "society_"
    L5_2 = A0_2
    L4_2 = L4_2 .. L5_2
    L5_2 = TriggerEvent
    L6_2 = EXTERNAL_EVENTS_NAMES
    L6_2 = L6_2["esx_addonaccount:getSharedAccount"]
    L7_2 = L4_2
    function L8_2(A0_3)
      local L1_3, L2_3, L3_3
      L1_3 = L3_2
      if L1_3 then
        return
      else
        L1_3 = true
        L3_2 = L1_3
      end
      if A0_3 then
        L1_3 = A0_3.removeMoney
        L2_3 = A1_2
        L1_3(L2_3)
        L1_3 = L2_2
        L2_3 = L1_3
        L1_3 = L1_3.resolve
        L3_3 = true
        L1_3(L2_3, L3_3)
      else
        L1_3 = L2_2
        L2_3 = L1_3
        L1_3 = L1_3.resolve
        L3_3 = false
        L1_3(L2_3, L3_3)
      end
    end
    L5_2(L6_2, L7_2, L8_2)
    L5_2 = SetTimeout
    L6_2 = 500
    function L7_2()
      local L0_3, L1_3, L2_3
      L0_3 = L3_2
      if not L0_3 then
        L0_3 = L2_2
        L1_3 = L0_3
        L0_3 = L0_3.resolve
        L2_3 = false
        L0_3(L1_3, L2_3)
      end
    end
    L5_2(L6_2, L7_2)
    L5_2 = Citizen
    L5_2 = L5_2.Await
    L6_2 = L2_2
    return L5_2(L6_2)
  else
    L2_2 = L0_1
    if "QB-core" == L2_2 then
      L2_2 = PREFERRED_BOSS_SCRIPT
      if "qb-bossmenu" == L2_2 then
        L2_2 = TriggerEvent
        L3_2 = "qb-bossmenu:server:removeAccountMoney"
        L4_2 = A0_2
        L5_2 = A1_2
        L2_2(L3_2, L4_2, L5_2)
      else
        L2_2 = PREFERRED_BOSS_SCRIPT
        if "qb-management" == L2_2 then
          L2_2 = L3_1
          L3_2 = A0_2
          L2_2 = L2_2(L3_2)
          if L2_2 then
            L2_2 = exports
            L3_2 = EXTERNAL_SCRIPTS_NAMES
            L3_2 = L3_2["qb-management"]
            L2_2 = L2_2[L3_2]
            L3_2 = L2_2
            L2_2 = L2_2.removeMoney
            L4_2 = A0_2
            L5_2 = A1_2
            L2_2(L3_2, L4_2, L5_2)
          else
            L2_2 = L2_1
            L3_2 = A0_2
            L2_2 = L2_2(L3_2)
            if L2_2 then
              L3_2 = Framework
              L3_2 = L3_2.removeMoneyFromSocietyAccount
              L4_2 = A0_2
              L5_2 = A1_2
              L3_2(L4_2, L5_2)
            else
              L3_2 = print
              L4_2 = "^1'"
              L5_2 = A0_2
              L6_2 = "' doesn't exist in qb-management, you have to add it in management_funds table in the database^7"
              L4_2 = L4_2 .. L5_2 .. L6_2
              L3_2(L4_2)
              L3_2 = false
              return L3_2
            end
          end
        else
          L2_2 = print
          L3_2 = "^1'"
          L4_2 = PREFERRED_BOSS_SCRIPT
          L5_2 = "' in sv_integrations.lua it's not a valid boss script^7"
          L3_2 = L3_2 .. L4_2 .. L5_2
          L2_2(L3_2)
          L2_2 = false
          return L2_2
        end
      end
      L2_2 = true
      return L2_2
    end
  end
end
L4_1.removeMoneyFromSocietyAccount = L5_1
L4_1 = Framework
function L5_1(A0_2)
  local L1_2, L2_2
  L1_2 = L0_1
  if "ESX" == L1_2 then
    L1_2 = ESX
    L1_2 = L1_2.GetPlayerFromId
    L2_2 = A0_2
    L1_2 = L1_2(L2_2)
    L2_2 = L1_2.identifier
    return L2_2
  else
    L1_2 = L0_1
    if "QB-core" == L1_2 then
      L1_2 = QBCore
      L1_2 = L1_2.Functions
      L1_2 = L1_2.GetPlayer
      L2_2 = A0_2
      L1_2 = L1_2(L2_2)
      if L1_2 then
        L2_2 = L1_2.PlayerData
        L2_2 = L2_2.license
        return L2_2
      end
    end
  end
end
L4_1.getIdentifier = L5_1
L4_1 = Framework
function L5_1(A0_2)
  local L1_2
  L1_2 = L0_1
  if "ESX" == L1_2 then
    L1_2 = ESX
    L1_2 = L1_2.Jobs
    L1_2 = L1_2[A0_2]
    if L1_2 then
      L1_2 = ESX
      L1_2 = L1_2.Jobs
      L1_2 = L1_2[A0_2]
      L1_2 = L1_2.label
      if L1_2 then
        goto lbl_16
      end
    end
    L1_2 = nil
    ::lbl_16::
    return L1_2
  else
    L1_2 = L0_1
    if "QB-core" == L1_2 then
      L1_2 = QBCore
      L1_2 = L1_2.Shared
      L1_2 = L1_2.Jobs
      L1_2 = L1_2[A0_2]
      if L1_2 then
        L1_2 = QBCore
        L1_2 = L1_2.Shared
        L1_2 = L1_2.Jobs
        L1_2 = L1_2[A0_2]
        L1_2 = L1_2.label
        if L1_2 then
          goto lbl_35
        end
      end
      L1_2 = nil
      ::lbl_35::
      return L1_2
    end
  end
end
L4_1.getJobLabel = L5_1
L4_1 = Framework
function L5_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = nil
  L2_2 = L0_1
  if "ESX" == L2_2 then
    L2_2 = ESX
    L1_2 = L2_2.GetPlayerFromId
  else
    L2_2 = QBCore
    L2_2 = L2_2.Functions
    L1_2 = L2_2.GetPlayer
  end
  if L1_2 then
    L2_2 = L1_2
    L3_2 = A0_2
    L2_2 = L2_2(L3_2)
    L2_2 = nil ~= L2_2
    return L2_2
  else
    L2_2 = print
    L3_2 = "^2No function for getPlayer^7"
    L2_2(L3_2)
    L2_2 = false
    return L2_2
  end
end
L4_1.isPlayerLoaded = L5_1
L4_1 = Framework
function L5_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2
  if not A2_2 then
    A2_2 = 0
  end
  L3_2 = L0_1
  if "ESX" == L3_2 then
    L3_2 = ESX
    L3_2 = L3_2.GetPlayerFromId
    L4_2 = A0_2
    L3_2 = L3_2(L4_2)
    L4_2 = INVENTORY_TO_USE
    if "ox-inventory" == L4_2 then
      L4_2 = L3_2.addInventoryItem
      L5_2 = A1_2
      L6_2 = 1
      L4_2(L5_2, L6_2)
    else
      L4_2 = L3_2.addWeapon
      L5_2 = A1_2
      L6_2 = A2_2
      L4_2(L5_2, L6_2)
    end
  else
    L3_2 = L0_1
    if "QB-core" == L3_2 then
      L3_2 = QBCore
      L3_2 = L3_2.Functions
      L3_2 = L3_2.GetPlayer
      L4_2 = A0_2
      L3_2 = L3_2(L4_2)
      if L3_2 then
        L4_2 = L3_2.Functions
        L4_2 = L4_2.AddItem
        L5_2 = A1_2
        L6_2 = 1
        L4_2(L5_2, L6_2)
      end
    end
  end
end
L4_1.giveWeaponToPlayer = L5_1
L4_1 = Framework
function L5_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2
  L2_2 = L0_1
  if "ESX" == L2_2 then
    L2_2 = ESX
    L2_2 = L2_2.GetPlayerFromId
    L3_2 = A0_2
    L2_2 = L2_2(L3_2)
    L3_2 = L2_2.removeWeapon
    L4_2 = A1_2
    L3_2(L4_2)
  else
    L2_2 = L0_1
    if "QB-core" == L2_2 then
      L2_2 = QBCore
      L2_2 = L2_2.Functions
      L2_2 = L2_2.GetPlayer
      L3_2 = A0_2
      L2_2 = L2_2(L3_2)
      L3_2 = L2_2.Functions
      L3_2 = L3_2.RemoveItem
      L4_2 = A1_2
      L5_2 = 1
      L3_2(L4_2, L5_2)
    end
  end
end
L4_1.removeWeaponFromPlayer = L5_1
L4_1 = Framework
function L5_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L1_2 = L0_1
  if "ESX" == L1_2 then
    L1_2 = ESX
    L1_2 = L1_2.GetPlayerFromId
    L2_2 = A0_2
    L1_2 = L1_2(L2_2)
    L2_2 = L1_2.getAccount
    L3_2 = "black_money"
    L2_2 = L2_2(L3_2)
    L2_2 = L2_2.money
    return L2_2
  else
    L1_2 = L0_1
    if "QB-core" == L1_2 then
      L1_2 = QBCore
      L1_2 = L1_2.Functions
      L1_2 = L1_2.GetPlayer
      L2_2 = A0_2
      L1_2 = L1_2(L2_2)
      L2_2 = L1_2.Functions
      L2_2 = L2_2.GetItemsByName
      L3_2 = "markedbills"
      L2_2 = L2_2(L3_2)
      L3_2 = 0
      L4_2 = pairs
      L5_2 = L2_2
      L4_2, L5_2, L6_2, L7_2 = L4_2(L5_2)
      for L8_2, L9_2 in L4_2, L5_2, L6_2, L7_2 do
        L10_2 = L9_2.info
        L10_2 = L10_2.worth
        L3_2 = L3_2 + L10_2
      end
      return L3_2
    end
  end
end
L4_1.getBlackMoneyValue = L5_1
L4_1 = Framework
function L5_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2
  L2_2 = L0_1
  if "ESX" == L2_2 then
    L2_2 = ESX
    L2_2 = L2_2.GetPlayerFromId
    L3_2 = A0_2
    L2_2 = L2_2(L3_2)
    L3_2 = L2_2.removeAccountMoney
    L4_2 = "black_money"
    L5_2 = A1_2
    L3_2(L4_2, L5_2)
  else
    L2_2 = L0_1
    if "QB-core" == L2_2 then
      L2_2 = QBCore
      L2_2 = L2_2.Functions
      L2_2 = L2_2.GetPlayer
      L3_2 = A0_2
      L2_2 = L2_2(L3_2)
      L3_2 = L2_2.Functions
      L3_2 = L3_2.GetItemsByName
      L4_2 = "markedbills"
      L3_2 = L3_2(L4_2)
      L4_2 = 0
      L5_2 = pairs
      L6_2 = L3_2
      L5_2, L6_2, L7_2, L8_2 = L5_2(L6_2)
      for L9_2, L10_2 in L5_2, L6_2, L7_2, L8_2 do
        L11_2 = L10_2.info
        L11_2 = L11_2.worth
        L4_2 = L4_2 + L11_2
        L11_2 = L2_2.Functions
        L11_2 = L11_2.RemoveItem
        L12_2 = "markedbills"
        L13_2 = L10_2.amount
        L14_2 = L10_2.slot
        L11_2(L12_2, L13_2, L14_2)
      end
      L4_2 = L4_2 - A1_2
      if L4_2 > 0 then
        L5_2 = L2_2.Functions
        L5_2 = L5_2.AddItem
        L6_2 = "markedbills"
        L7_2 = 1
        L8_2 = nil
        L9_2 = {}
        L9_2.worth = L4_2
        L5_2(L6_2, L7_2, L8_2, L9_2)
      end
    end
  end
end
L4_1.removeBlackMoneyValue = L5_1
L4_1 = Framework
function L5_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L2_2 = L0_1
  if "ESX" == L2_2 then
    L2_2 = ESX
    L2_2 = L2_2.GetPlayerFromId
    L3_2 = A0_2
    L2_2 = L2_2(L3_2)
    L3_2 = L2_2.addAccountMoney
    L4_2 = "black_money"
    L5_2 = A1_2
    L3_2(L4_2, L5_2)
  else
    L2_2 = L0_1
    if "QB-core" == L2_2 then
      L2_2 = QBCore
      L2_2 = L2_2.Functions
      L2_2 = L2_2.GetPlayer
      L3_2 = A0_2
      L2_2 = L2_2(L3_2)
      L3_2 = L2_2.Functions
      L3_2 = L3_2.GetItemByName
      L4_2 = "markedbills"
      L3_2 = L3_2(L4_2)
      L4_2 = nil
      if L3_2 then
        L5_2 = L3_2.info
        L5_2 = L5_2.worth
        A1_2 = A1_2 + L5_2
        L6_2 = L2_2.Functions
        L6_2 = L6_2.RemoveItem
        L7_2 = "markedbills"
        L8_2 = L3_2.amount
        L9_2 = L3_2.slot
        L6_2(L7_2, L8_2, L9_2)
        L4_2 = L3_2.slot
      end
      L5_2 = L2_2.Functions
      L5_2 = L5_2.AddItem
      L6_2 = "markedbills"
      L7_2 = 1
      L8_2 = L4_2
      L9_2 = {}
      L9_2.worth = A1_2
      L5_2(L6_2, L7_2, L8_2, L9_2)
    end
  end
end
L4_1.giveBlackMoneyValue = L5_1
L4_1 = Framework
function L5_1()
  local L0_2, L1_2
  L0_2 = L0_1
  if "ESX" == L0_2 then
    L0_2 = ESX
    L0_2 = L0_2.GetConfig
    L0_2 = L0_2()
    L0_2 = L0_2.Accounts
    return L0_2
  else
    L0_2 = L0_1
    if "QB-core" == L0_2 then
      L0_2 = QBCore
      L0_2 = L0_2.Config
      L0_2 = L0_2.Money
      L0_2 = L0_2.MoneyTypes
      return L0_2
    end
  end
end
L4_1.getAllAccounts = L5_1
L4_1 = Framework
function L5_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = L0_1
  if "ESX" == L1_2 then
    L1_2 = ESX
    L1_2 = L1_2.GetConfig
    L1_2 = L1_2()
    L1_2 = L1_2.Accounts
    L1_2 = L1_2[A0_2]
    if not L1_2 then
      return A0_2
    end
    L2_2 = type
    L3_2 = L1_2
    L2_2 = L2_2(L3_2)
    if "table" == L2_2 then
      L2_2 = L1_2.label
      return L2_2
    else
      return L1_2
    end
  else
    L1_2 = L0_1
    if "QB-core" == L1_2 then
      return A0_2
    end
  end
end
L4_1.getAccountLabel = L5_1
L4_1 = Framework
function L5_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  L1_2 = {}
  L2_2 = Framework
  L2_2 = L2_2.getFramework
  L2_2 = L2_2()
  if "ESX" == L2_2 then
    L2_2 = ESX
    L2_2 = L2_2.GetPlayerFromId
    L3_2 = A0_2
    L2_2 = L2_2(L3_2)
    L3_2 = L2_2.getLoadout
    L3_2 = L3_2()
    L1_2 = L3_2
  else
    L2_2 = Framework
    L2_2 = L2_2.getFramework
    L2_2 = L2_2()
    if "QB-core" == L2_2 then
      L2_2 = QBCore
      L2_2 = L2_2.Functions
      L2_2 = L2_2.GetPlayer
      L3_2 = A0_2
      L2_2 = L2_2(L3_2)
      L3_2 = pairs
      L4_2 = L2_2.PlayerData
      L4_2 = L4_2.items
      L3_2, L4_2, L5_2, L6_2 = L3_2(L4_2)
      for L7_2, L8_2 in L3_2, L4_2, L5_2, L6_2 do
        L9_2 = QBCore
        L9_2 = L9_2.Shared
        L9_2 = L9_2.Weapons
        L10_2 = GetHashKey
        L11_2 = L8_2.name
        L10_2 = L10_2(L11_2)
        L9_2 = L9_2[L10_2]
        if L9_2 then
          L9_2 = table
          L9_2 = L9_2.insert
          L10_2 = L1_2
          L11_2 = {}
          L12_2 = L8_2.name
          L11_2.name = L12_2
          L12_2 = L8_2.label
          L11_2.label = L12_2
          L9_2(L10_2, L11_2)
        end
      end
    end
  end
  return L1_2
end
L4_1.getPlayerWeapons = L5_1
L4_1 = Framework
function L5_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = L0_1
  if "ESX" == L1_2 then
    L1_2 = false
    return L1_2
  else
    L1_2 = QBCore
    L1_2 = L1_2.Shared
    L1_2 = L1_2.Weapons
    L2_2 = GetHashKey
    L3_2 = A0_2
    L2_2 = L2_2(L3_2)
    L1_2 = L1_2[L2_2]
    L1_2 = nil ~= L1_2
    return L1_2
  end
end
L4_1.isItemWeapon = L5_1
L4_1 = Framework
function L5_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2
  L3_2 = L0_1
  if "ESX" == L3_2 then
    L3_2 = ESX
    L3_2 = L3_2.GetPlayerFromId
    L4_2 = A0_2
    L3_2 = L3_2(L4_2)
    L4_2 = L3_2.hasWeaponComponent
    L5_2 = A1_2
    L6_2 = A2_2
    return L4_2(L5_2, L6_2)
  else
    L3_2 = L0_1
    if "QB-core" == L3_2 then
      L3_2 = QBCore
      L3_2 = L3_2.Functions
      L3_2 = L3_2.GetPlayer
      L4_2 = A0_2
      L3_2 = L3_2(L4_2)
      L4_2 = L3_2.Functions
      L4_2 = L4_2.GetItemByName
      L5_2 = A2_2
      L4_2 = L4_2(L5_2)
      L4_2 = nil ~= L4_2
      return L4_2
    end
  end
end
L4_1.hasPlayerWeaponComponent = L5_1
function L4_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = promise
  L0_2 = L0_2.new
  L0_2 = L0_2()
  L1_2 = false
  L2_2 = TriggerEvent
  L3_2 = "qb-weapons:getWeaponsAttachments"
  function L4_2(A0_3)
    local L1_3, L2_3, L3_3
    L1_3 = true
    L1_2 = L1_3
    L1_3 = L0_2
    L2_3 = L1_3
    L1_3 = L1_3.resolve
    L3_3 = A0_3
    L1_3(L2_3, L3_3)
  end
  L2_2(L3_2, L4_2)
  L2_2 = SetTimeout
  L3_2 = 1000
  function L4_2()
    local L0_3, L1_3, L2_3
    L0_3 = L1_2
    if not L0_3 then
      L0_3 = L0_2
      L1_3 = L0_3
      L0_3 = L0_3.resolve
      L2_3 = false
      L0_3(L1_3, L2_3)
    end
  end
  L2_2(L3_2, L4_2)
  L2_2 = Citizen
  L2_2 = L2_2.Await
  L3_2 = L0_2
  return L2_2(L3_2)
end
L5_1 = Framework
function L6_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2
  L2_2 = L0_1
  if "ESX" == L2_2 then
    L2_2 = ESX
    L2_2 = L2_2.GetWeaponComponent
    L3_2 = A0_2
    L4_2 = A1_2
    L2_2 = L2_2(L3_2, L4_2)
    L2_2 = nil ~= L2_2
    return L2_2
  else
    L2_2 = L0_1
    if "QB-core" == L2_2 then
      L2_2 = promise
      L2_2 = L2_2.new
      L2_2 = L2_2()
      L3_2 = false
      L4_2 = L4_1
      L4_2 = L4_2()
      L6_2 = A0_2
      L5_2 = A0_2.upper
      L5_2 = L5_2(L6_2)
      L6_2 = L4_2[L5_2]
      if L6_2 then
        L7_2 = L2_2
        L6_2 = L2_2.resolve
        L8_2 = L4_2[L5_2]
        L8_2 = L8_2[A1_2]
        L8_2 = nil ~= L8_2
        L6_2(L7_2, L8_2)
      else
        L6_2 = print
        L7_2 = "^1Weapon "
        L8_2 = L5_2
        L9_2 = " not found in "
        L10_2 = EXTERNAL_SCRIPTS_NAMES
        L10_2 = L10_2["qb-weapons"]
        L11_2 = "/config.lua^7"
        L7_2 = L7_2 .. L8_2 .. L9_2 .. L10_2 .. L11_2
        L6_2(L7_2)
      end
      L6_2 = Citizen
      L6_2 = L6_2.Await
      L7_2 = L2_2
      return L6_2(L7_2)
    end
  end
end
L5_1.doesComponentExistsForWeapon = L6_1
L5_1 = Framework
function L6_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L2_2 = L0_1
  if "ESX" == L2_2 then
    L2_2 = ESX
    L2_2 = L2_2.GetWeaponComponent
    L3_2 = A0_2
    L4_2 = A1_2
    L2_2 = L2_2(L3_2, L4_2)
    L2_2 = L2_2.label
    return L2_2
  else
    L2_2 = L0_1
    if "QB-core" == L2_2 then
      L2_2 = L4_1
      L2_2 = L2_2()
      L4_2 = A0_2
      L3_2 = A0_2.upper
      L3_2 = L3_2(L4_2)
      L4_2 = L2_2[L3_2]
      if L4_2 then
        L4_2 = L2_2[L3_2]
        L4_2 = L4_2[A1_2]
        L4_2 = L4_2.label
        if not L4_2 then
          L4_2 = Framework
          L4_2 = L4_2.getItemLabel
          L5_2 = L2_2[L3_2]
          L5_2 = L5_2[A1_2]
          L5_2 = L5_2.item
          L4_2 = L4_2(L5_2)
        end
        return L4_2
      else
        L4_2 = print
        L5_2 = "^1Weapon "
        L6_2 = L3_2
        L7_2 = " not found in "
        L8_2 = EXTERNAL_SCRIPTS_NAMES
        L8_2 = L8_2["qb-weapons"]
        L9_2 = "/config.lua^7"
        L5_2 = L5_2 .. L6_2 .. L7_2 .. L8_2 .. L9_2
        L4_2(L5_2)
      end
      return A1_2
    end
  end
end
L5_1.getWeaponComponentLabel = L6_1
L5_1 = Framework
function L6_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2
  L2_2 = L0_1
  if "ESX" == L2_2 then
    L2_2 = ESX
    L2_2 = L2_2.GetPlayerFromId
    L3_2 = A0_2
    L2_2 = L2_2(L3_2)
    L3_2 = L2_2.hasWeapon
    L4_2 = A1_2
    return L3_2(L4_2)
  else
    L2_2 = L0_1
    if "QB-core" == L2_2 then
      L2_2 = QBCore
      L2_2 = L2_2.Functions
      L2_2 = L2_2.GetPlayer
      L3_2 = A0_2
      L2_2 = L2_2(L3_2)
      L3_2 = L2_2.Functions
      L3_2 = L3_2.GetItemByName
      L4_2 = A1_2
      L3_2 = L3_2(L4_2)
      L3_2 = nil ~= L3_2
      return L3_2
    end
  end
end
L5_1.hasPlayerWeapon = L6_1
L5_1 = Framework
function L6_1(A0_2)
  local L1_2, L2_2
  L1_2 = L0_1
  if "ESX" == L1_2 then
    L1_2 = ESX
    L1_2 = L1_2.GetWeaponLabel
    L2_2 = A0_2
    return L1_2(L2_2)
  else
    L1_2 = L0_1
    if "QB-core" == L1_2 then
      L1_2 = Framework
      L1_2 = L1_2.getItemLabel
      L2_2 = A0_2
      return L1_2(L2_2)
    end
  end
end
L5_1.getWeaponLabel = L6_1
L5_1 = {}
L5_1.clip_extended = "extendedclip"
L5_1.clip_drum = "drum"
L5_1.flashlight = "flashlight"
L5_1.suppressor = "suppressor"
L5_1.scope = "scope"
L5_1.scope_advanced = "advancedscope"
L5_1.grip = "grip"
L5_1.clip_box = "drum"
L5_1.luxary_finish = "luxuryfinish"
L6_1 = Framework
function L7_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2
  L3_2 = L0_1
  if "ESX" == L3_2 then
    L3_2 = ESX
    L3_2 = L3_2.GetPlayerFromId
    L4_2 = A0_2
    L3_2 = L3_2(L4_2)
    L4_2 = L3_2.removeWeaponComponent
    L5_2 = A1_2
    L6_2 = A2_2
    L4_2(L5_2, L6_2)
  else
    L3_2 = L0_1
    if "QB-core" == L3_2 then
      L3_2 = QBCore
      L3_2 = L3_2.Functions
      L3_2 = L3_2.GetPlayer
      L4_2 = A0_2
      L3_2 = L3_2(L4_2)
      L4_2 = L4_1
      L4_2 = L4_2()
      L6_2 = A1_2
      L5_2 = A1_2.upper
      L5_2 = L5_2(L6_2)
      L4_2 = L4_2[L5_2]
      L5_2 = L5_1
      L5_2 = L5_2[A2_2]
      L4_2 = L4_2[L5_2]
      L4_2 = L4_2.item
      L5_2 = L3_2.Functions
      L5_2 = L5_2.RemoveItem
      L6_2 = L4_2
      L7_2 = 1
      L5_2(L6_2, L7_2)
    end
  end
end
L6_1.removeWeaponComponentFromPlayer = L7_1
L6_1 = Framework
function L7_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2
  L3_2 = L0_1
  if "ESX" == L3_2 then
    L3_2 = ESX
    L3_2 = L3_2.GetPlayerFromId
    L4_2 = A0_2
    L3_2 = L3_2(L4_2)
    L4_2 = L3_2.addWeaponComponent
    L5_2 = A1_2
    L6_2 = A2_2
    L4_2(L5_2, L6_2)
  else
    L3_2 = L0_1
    if "QB-core" == L3_2 then
      L3_2 = QBCore
      L3_2 = L3_2.Functions
      L3_2 = L3_2.GetPlayer
      L4_2 = A0_2
      L3_2 = L3_2(L4_2)
      L4_2 = L4_1
      L4_2 = L4_2()
      L6_2 = A1_2
      L5_2 = A1_2.upper
      L5_2 = L5_2(L6_2)
      L4_2 = L4_2[L5_2]
      L5_2 = L5_1
      L5_2 = L5_2[A2_2]
      L4_2 = L4_2[L5_2]
      L4_2 = L4_2.item
      L5_2 = L3_2.Functions
      L5_2 = L5_2.AddItem
      L6_2 = L4_2
      L7_2 = 1
      L5_2(L6_2, L7_2)
    end
  end
end
L6_1.addWeaponComponentToPlayer = L7_1
L6_1 = {}
L6_1[0] = "weapontint_black"
L6_1[1] = "weapontint_green"
L6_1[2] = "weapontint_gold"
L6_1[3] = "weapontint_pink"
L6_1[4] = "weapontint_army"
L6_1[5] = "weapontint_lspd"
L6_1[6] = "weapontint_orange"
L6_1[7] = "weapontint_plat"
L7_1 = Framework
function L8_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2
  L3_2 = L0_1
  if "ESX" == L3_2 then
    L3_2 = ESX
    L3_2 = L3_2.GetPlayerFromId
    L4_2 = A0_2
    L3_2 = L3_2(L4_2)
    L4_2 = L3_2.setWeaponTint
    L5_2 = A1_2
    L6_2 = A2_2
    L4_2(L5_2, L6_2)
  else
    L3_2 = L0_1
    if "QB-core" == L3_2 then
      L3_2 = QBCore
      L3_2 = L3_2.Functions
      L3_2 = L3_2.GetPlayer
      L4_2 = A0_2
      L3_2 = L3_2(L4_2)
      L4_2 = L3_2.Functions
      L4_2 = L4_2.AddItem
      L5_2 = L6_1
      L5_2 = L5_2[A2_2]
      L6_2 = 1
      L4_2(L5_2, L6_2)
    end
  end
end
L7_1.giveWeaponTintToPlayerWeapon = L8_1
L7_1 = Framework
function L8_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2
  L3_2 = L0_1
  if "ESX" == L3_2 then
    L3_2 = ESX
    L3_2 = L3_2.GetPlayerFromId
    L4_2 = A0_2
    L3_2 = L3_2(L4_2)
    L4_2 = L3_2.setJob
    L5_2 = A1_2
    L6_2 = A2_2
    L4_2(L5_2, L6_2)
  else
    L3_2 = L0_1
    if "QB-core" == L3_2 then
      L3_2 = QBCore
      L3_2 = L3_2.Functions
      L3_2 = L3_2.GetPlayer
      L4_2 = A0_2
      L3_2 = L3_2(L4_2)
      L4_2 = L3_2.Functions
      L4_2 = L4_2.SetJob
      L5_2 = A1_2
      L6_2 = A2_2
      L4_2(L5_2, L6_2)
    end
  end
end
L7_1.setJobToPlayer = L8_1
L7_1 = Framework
function L8_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2
  L1_2 = L0_1
  if "ESX" == L1_2 then
    L1_2 = ESX
    L1_2 = L1_2.GetPlayerFromId
    L2_2 = A0_2
    L1_2 = L1_2(L2_2)
    L2_2 = L1_2.getName
    L2_2 = L2_2()
    if not L2_2 then
      L2_2 = GetPlayerName
      L3_2 = A0_2
      L2_2 = L2_2(L3_2)
    end
    return L2_2
  else
    L1_2 = L0_1
    if "QB-core" == L1_2 then
      L1_2 = QBCore
      L1_2 = L1_2.Functions
      L1_2 = L1_2.GetPlayer
      L2_2 = A0_2
      L1_2 = L1_2(L2_2)
      L2_2 = L1_2.PlayerData
      L2_2 = L2_2.charinfo
      L3_2 = L2_2.firstname
      L4_2 = " "
      L5_2 = L2_2.lastname
      L3_2 = L3_2 .. L4_2 .. L5_2
      return L3_2
    end
  end
end
L7_1.getPlayerCharacterName = L8_1
L7_1 = RegisterServerCallback
L8_1 = Utils
L8_1 = L8_1.eventsPrefix
L9_1 = ":getPlayerLicenses"
L8_1 = L8_1 .. L9_1
function L9_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2
  L3_2 = QBCore
  L3_2 = L3_2.Functions
  L3_2 = L3_2.GetPlayer
  L4_2 = A2_2
  L3_2 = L3_2(L4_2)
  L4_2 = A1_2
  L5_2 = L3_2.PlayerData
  L5_2 = L5_2.metadata
  L5_2 = L5_2.licences
  L4_2(L5_2)
end
L7_1(L8_1, L9_1)
L7_1 = RegisterNetEvent
L8_1 = Utils
L8_1 = L8_1.eventsPrefix
L9_1 = ":giveLicenseToPlayer"
L8_1 = L8_1 .. L9_1
function L9_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L2_2 = source
  L3_2 = Framework
  L3_2 = L3_2.getFramework
  L3_2 = L3_2()
  if "QB-core" ~= L3_2 then
    L3_2 = print
    L4_2 = "Event :giveLicenseToPlayer can be used only on QBCore"
    L3_2(L4_2)
    return
  end
  L3_2 = QBCore
  L3_2 = L3_2.Functions
  L3_2 = L3_2.GetPlayer
  L4_2 = A0_2
  L3_2 = L3_2(L4_2)
  L4_2 = L3_2.PlayerData
  L4_2 = L4_2.metadata
  L4_2 = L4_2.licences
  L4_2[A1_2] = true
  L5_2 = L3_2.Functions
  L5_2 = L5_2.SetMetaData
  L6_2 = "licences"
  L7_2 = L4_2
  L5_2(L6_2, L7_2)
end
L7_1(L8_1, L9_1)
L7_1 = RegisterNetEvent
L8_1 = Utils
L8_1 = L8_1.eventsPrefix
L9_1 = ":removeLicenseFromPlayer"
L8_1 = L8_1 .. L9_1
function L9_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L2_2 = source
  L3_2 = Framework
  L3_2 = L3_2.getFramework
  L3_2 = L3_2()
  if "QB-core" ~= L3_2 then
    L3_2 = print
    L4_2 = "Event :removeLicenseFromPlayer can be used only on QBCore"
    L3_2(L4_2)
    return
  end
  L3_2 = QBCore
  L3_2 = L3_2.Functions
  L3_2 = L3_2.GetPlayer
  L4_2 = A0_2
  L3_2 = L3_2(L4_2)
  L4_2 = L3_2.PlayerData
  L4_2 = L4_2.metadata
  L4_2 = L4_2.licences
  L4_2[A1_2] = false
  L5_2 = L3_2.Functions
  L5_2 = L5_2.SetMetaData
  L6_2 = "licences"
  L7_2 = L4_2
  L5_2(L6_2, L7_2)
end
L7_1(L8_1, L9_1)

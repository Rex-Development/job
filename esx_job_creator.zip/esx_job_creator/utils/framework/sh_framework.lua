local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1, L8_1, L9_1, L10_1
CURRENT_FRAMEWORK = "ESX"
L0_1 = Framework
if not L0_1 then
  L0_1 = {}
end
Framework = L0_1
L0_1 = nil
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
  L0_2 = LoadResourceFile
  L1_2 = EXTERNAL_SCRIPTS_NAMES
  L1_2 = L1_2.es_extended
  L2_2 = "client/common.lua"
  L0_2 = L0_2(L1_2, L2_2)
  L1_2 = nil
  if L0_2 then
    L3_2 = L0_2
    L2_2 = L0_2.match
    L4_2 = "['\"](.*)['\"]"
    L2_2 = L2_2(L3_2, L4_2)
    L1_2 = L2_2
  else
    L2_2 = print
    L3_2 = "^1Couldn't find file "
    L4_2 = EXTERNAL_SCRIPTS_NAMES
    L4_2 = L4_2.es_extended
    L5_2 = "/client/common.lua^7"
    L3_2 = L3_2 .. L4_2 .. L5_2
    L2_2(L3_2)
  end
  return L1_2
end
function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = promise
  L0_2 = L0_2.new
  L0_2 = L0_2()
  L1_2 = MySQL
  L1_2 = L1_2.Async
  L1_2 = L1_2.fetchScalar
  L2_2 = "SELECT COUNT(*) FROM items"
  L3_2 = {}
  function L4_2(A0_3)
    local L1_3, L2_3, L3_3
    L1_3 = L0_2
    L2_3 = L1_3
    L1_3 = L1_3.resolve
    L3_3 = A0_3 > 0
    L1_3(L2_3, L3_3)
  end
  L1_2(L2_2, L3_2, L4_2)
  L1_2 = Citizen
  L1_2 = L1_2.Await
  L2_2 = L0_2
  return L1_2(L2_2)
end
function L3_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = promise
  L0_2 = L0_2.new
  L0_2 = L0_2()
  L1_2 = MySQL
  L1_2 = L1_2.Async
  L1_2 = L1_2.fetchScalar
  L2_2 = "SELECT COUNT(*) FROM jobs"
  L3_2 = {}
  function L4_2(A0_3)
    local L1_3, L2_3, L3_3
    L1_3 = L0_2
    L2_3 = L1_3
    L1_3 = L1_3.resolve
    L3_3 = A0_3 > 0
    L1_3(L2_3, L3_3)
  end
  L1_2(L2_2, L3_2, L4_2)
  L1_2 = Citizen
  L1_2 = L1_2.Await
  L2_2 = L0_2
  return L1_2(L2_2)
end
function L4_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = promise
  L0_2 = L0_2.new
  L0_2 = L0_2()
  L1_2 = MySQL
  L1_2 = L1_2.Async
  L1_2 = L1_2.fetchScalar
  L2_2 = "SELECT COUNT(*) FROM job_grades"
  L3_2 = {}
  function L4_2(A0_3)
    local L1_3, L2_3, L3_3
    L1_3 = L0_2
    L2_3 = L1_3
    L1_3 = L1_3.resolve
    L3_3 = A0_3 > 0
    L1_3(L2_3, L3_3)
  end
  L1_2(L2_2, L3_2, L4_2)
  L1_2 = Citizen
  L1_2 = L1_2.Await
  L2_2 = L0_2
  return L1_2(L2_2)
end
function L5_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2
  L0_2 = IsDuplicityVersion
  L0_2 = L0_2()
  if L0_2 then
    L0_2 = false
    L1_2 = false
    L2_2 = false
    L3_2 = INVENTORY_TO_USE
    if "ox-inventory" == L3_2 then
      L3_2 = pairs
      L4_2 = exports
      L5_2 = EXTERNAL_SCRIPTS_NAMES
      L5_2 = L5_2.ox_inventory
      L4_2 = L4_2[L5_2]
      L4_2 = L4_2.Items
      L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2 = L4_2()
      L3_2, L4_2, L5_2, L6_2 = L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2)
      for L7_2, L8_2 in L3_2, L4_2, L5_2, L6_2 do
        L0_2 = true
        break
      end
    else
      L3_2 = ESX
      L3_2 = L3_2.Items
      if L3_2 then
        L3_2 = pairs
        L4_2 = ESX
        L4_2 = L4_2.Items
        L3_2, L4_2, L5_2, L6_2 = L3_2(L4_2)
        for L7_2, L8_2 in L3_2, L4_2, L5_2, L6_2 do
          L0_2 = true
          break
        end
      else
        L3_2 = ESX
        L3_2 = L3_2.Items
        if not L3_2 then
          L0_2 = true
        end
      end
    end
    L3_2 = pairs
    L4_2 = ESX
    L4_2 = L4_2.Jobs
    L3_2, L4_2, L5_2, L6_2 = L3_2(L4_2)
    for L7_2, L8_2 in L3_2, L4_2, L5_2, L6_2 do
      L9_2 = L8_2.grades
      if L9_2 then
        L9_2 = pairs
        L10_2 = L8_2.grades
        L9_2, L10_2, L11_2, L12_2 = L9_2(L10_2)
        for L13_2, L14_2 in L9_2, L10_2, L11_2, L12_2 do
          L2_2 = true
          break
        end
      end
      L1_2 = true
      break
    end
    if not L0_2 then
      L3_2 = L2_1
      L3_2 = L3_2()
    end
    if not L1_2 then
      L3_2 = L3_1
      L3_2 = L3_2()
    end
    L3_2 = L2_2 or L3_2
    if not L2_2 then
      L3_2 = L4_1
      L3_2 = L3_2()
      L3_2 = not L3_2 and L3_2
    end
    return L3_2
  else
    L0_2 = true
    return L0_2
  end
end
function L6_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = EXTERNAL_SCRIPTS_NAMES
  L0_2 = L0_2.es_extended
  L1_2 = Utils
  L1_2 = L1_2.doesExportExist
  L2_2 = L0_2
  L3_2 = "getSharedObject"
  L1_2 = L1_2(L2_2, L3_2)
  if L1_2 then
    L1_2 = exports
    L1_2 = L1_2[L0_2]
    L2_2 = L1_2
    L1_2 = L1_2.getSharedObject
    L1_2 = L1_2(L2_2)
    ESX = L1_2
    return
  end
  L1_2 = promise
  L1_2 = L1_2.new
  L1_2 = L1_2()
  L2_2 = "esx_shared_object"
  L3_2 = Citizen
  L3_2 = L3_2.CreateThread
  function L4_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3
    L0_3 = ProfilerIsRecording
    L0_3 = L0_3()
    if L0_3 then
      L1_3 = ProfilerEnterScope
      L2_3 = "Getting shared object"
      L1_3(L2_3)
    end
    L1_3 = EXTERNAL_EVENTS_NAMES
    L1_3 = L1_3["esx:getSharedObject"]
    if not L1_3 then
      L1_3 = GetResourceKvpString
      L2_3 = L2_2
      L1_3 = L1_3(L2_3)
      if not L1_3 then
        L1_3 = "esx:getSharedObject"
      end
    end
    L2_3 = true
    L3_3 = GetGameTimer
    L3_3 = L3_3()
    L3_3 = L3_3 + 1000
    while true do
      L4_3 = ESX
      if nil ~= L4_3 then
        L4_3 = L5_1
        L4_3 = L4_3()
        if L4_3 then
          break
        end
      end
      L4_3 = ESX
      if not L4_3 then
        if L1_3 then
          L4_3 = TriggerEvent
          L5_3 = L1_3
          function L6_3(A0_4)
            local L1_4
            ESX = A0_4
          end
          L4_3(L5_3, L6_3)
          L4_3 = GetGameTimer
          L4_3 = L4_3()
          if L3_3 < L4_3 then
            if L2_3 then
              L2_3 = false
              L4_3 = GetGameTimer
              L4_3 = L4_3()
              L3_3 = L4_3 + 1000
              L4_3 = L1_1
              L4_3 = L4_3()
              L1_3 = L4_3
            else
              return
            end
          end
        else
          L4_3 = print
          L5_3 = "^1ESX Shared Object is nil^7"
          L4_3(L5_3)
          return
        end
      else
        L4_3 = TriggerEvent
        L5_3 = L1_3
        function L6_3(A0_4)
          local L1_4
          ESX = A0_4
        end
        L4_3(L5_3, L6_3)
      end
      L4_3 = Citizen
      L4_3 = L4_3.Wait
      L5_3 = 500
      L4_3(L5_3)
    end
    L4_3 = L0_1
    if nil ~= L4_3 then
      L4_3 = L0_1
      if L4_3 == L1_3 then
        goto lbl_81
      end
    end
    L0_1 = L1_3
    L4_3 = SetResourceKvp
    L5_3 = L2_2
    L6_3 = L1_3
    L4_3(L5_3, L6_3)
    ::lbl_81::
    if L0_3 then
      L4_3 = ProfilerExitScope
      L4_3()
    end
    L4_3 = L1_2
    L5_3 = L4_3
    L4_3 = L4_3.resolve
    L4_3(L5_3)
  end
  L3_2(L4_2)
  L3_2 = Citizen
  L3_2 = L3_2.Await
  L4_2 = L1_2
  return L3_2(L4_2)
end
getSharedObject = L6_1
function L6_1()
  local L0_2, L1_2
  L0_2 = CURRENT_FRAMEWORK
  if "ESX" == L0_2 then
    L0_2 = getSharedObject
    L0_2()
  else
    L0_2 = CURRENT_FRAMEWORK
    if "QB-core" == L0_2 then
      L0_2 = exports
      L1_2 = EXTERNAL_SCRIPTS_NAMES
      L1_2 = L1_2["qb-core"]
      L0_2 = L0_2[L1_2]
      L1_2 = L0_2
      L0_2 = L0_2.GetCoreObject
      L0_2 = L0_2(L1_2)
      QBCore = L0_2
    end
  end
end
L7_1 = Framework
function L8_1()
  local L0_2, L1_2, L2_2
  L0_2 = L6_1
  L0_2()
  L0_2 = TriggerEvent
  L1_2 = Utils
  L1_2 = L1_2.eventsPrefix
  L2_2 = ":framework:ready"
  L1_2 = L1_2 .. L2_2
  L0_2(L1_2)
  L0_2 = SECONDS_TO_REFRESH_SHARED_OBJECT
  if L0_2 then
    L0_2 = SECONDS_TO_REFRESH_SHARED_OBJECT
    L0_2 = L0_2 * 1000
    L1_2 = Citizen
    L1_2 = L1_2.CreateThread
    function L2_2()
      local L0_3, L1_3
      while true do
        L0_3 = Citizen
        L0_3 = L0_3.Wait
        L1_3 = L0_2
        L0_3(L1_3)
        L0_3 = L6_1
        L0_3()
      end
    end
    L1_2(L2_2)
  end
end
L7_1.setupFramework = L8_1
L7_1 = Framework
function L8_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L1_2 = string
  L1_2 = L1_2.match
  L2_2 = A0_2
  L3_2 = "^([^%d]*%d)(%d*)(.-)$"
  L1_2, L2_2, L3_2 = L1_2(L2_2, L3_2)
  L4_2 = PRICES_SEPARATOR
  if not L4_2 then
    L4_2 = "."
  end
  L5_2 = L1_2
  L7_2 = L2_2
  L6_2 = L2_2.reverse
  L6_2 = L6_2(L7_2)
  L7_2 = L6_2
  L6_2 = L6_2.gsub
  L8_2 = "(%d%d%d)"
  L9_2 = "%1"
  L10_2 = L4_2
  L9_2 = L9_2 .. L10_2
  L6_2 = L6_2(L7_2, L8_2, L9_2)
  L7_2 = L6_2
  L6_2 = L6_2.reverse
  L6_2 = L6_2(L7_2)
  L7_2 = L3_2
  L5_2 = L5_2 .. L6_2 .. L7_2
  return L5_2
end
L7_1.groupDigits = L8_1
L7_1 = Framework
function L8_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  if A0_2 then
    L1_2 = string
    L1_2 = L1_2.gsub
    L2_2 = A0_2
    L3_2 = "^%s*(.-)%s*$"
    L4_2 = "%1"
    L1_2 = L1_2(L2_2, L3_2, L4_2)
    return L1_2
  else
    L1_2 = nil
    return L1_2
  end
end
L7_1.trim = L8_1
L7_1 = Framework
function L8_1()
  local L0_2, L1_2
  L0_2 = CURRENT_FRAMEWORK
  return L0_2
end
L7_1.getFramework = L8_1
L7_1 = {}
L8_1 = {}
L8_1.name = "tshirt_1"
L8_1.color = "tshirt_2"
L7_1["t-shirt"] = L8_1
L8_1 = {}
L8_1.name = "torso_1"
L8_1.color = "torso_2"
L7_1.torso2 = L8_1
L8_1 = {}
L8_1.name = "decals_1"
L8_1.color = "decals_2"
L7_1.decals = L8_1
L8_1 = {}
L8_1.name = "arms"
L8_1.color = "arms_2"
L7_1.arms = L8_1
L8_1 = {}
L8_1.name = "pants_1"
L8_1.color = "pants_2"
L7_1.pants = L8_1
L8_1 = {}
L8_1.name = "shoes_1"
L8_1.color = "shoes_2"
L7_1.shoes = L8_1
L8_1 = {}
L8_1.name = "mask_1"
L8_1.color = "mask_2"
L7_1.mask = L8_1
L8_1 = {}
L8_1.name = "bproof_1"
L8_1.color = "bproof_2"
L7_1.vest = L8_1
L8_1 = {}
L8_1.name = "chain_1"
L8_1.color = "chain_2"
L7_1.accessory = L8_1
L8_1 = {}
L8_1.name = "helmet_1"
L8_1.color = "helmet_2"
L7_1.hat = L8_1
L8_1 = {}
L8_1.name = "glasses_1"
L8_1.color = "glasses_2"
L7_1.glass = L8_1
L8_1 = {}
L8_1.name = "bags_1"
L8_1.color = "bags_2"
L7_1.bag = L8_1
L8_1 = Framework
function L9_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L1_2 = {}
  L2_2 = pairs
  L3_2 = A0_2
  L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
  for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
    L8_2 = L7_1
    L8_2 = L8_2[L6_2]
    if L8_2 then
      L8_2 = L7_1
      L8_2 = L8_2[L6_2]
      L8_2 = L8_2.name
      L9_2 = L7_1
      L9_2 = L9_2[L6_2]
      L9_2 = L9_2.color
      L10_2 = L7_2.item
      L1_2[L8_2] = L10_2
      L10_2 = L7_2.texture
      L1_2[L9_2] = L10_2
    end
  end
  return L1_2
end
L8_1.convertOutfitFromQBCoreToESX = L9_1
function L8_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L1_2 = pairs
  L2_2 = L7_1
  L1_2, L2_2, L3_2, L4_2 = L1_2(L2_2)
  for L5_2, L6_2 in L1_2, L2_2, L3_2, L4_2 do
    L7_2 = L6_2.name
    if L7_2 == A0_2 then
      L7_2 = L5_2
      L8_2 = "name"
      return L7_2, L8_2
    else
      L7_2 = L6_2.color
      if L7_2 == A0_2 then
        L7_2 = L5_2
        L8_2 = "color"
        return L7_2, L8_2
      end
    end
  end
end
L9_1 = Framework
function L10_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L1_2 = {}
  L2_2 = pairs
  L3_2 = A0_2
  L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
  for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
    L8_2 = L8_1
    L9_2 = L6_2
    L8_2, L9_2 = L8_2(L9_2)
    if L8_2 then
      L10_2 = L1_2[L8_2]
      if not L10_2 then
        L10_2 = {}
      end
      L1_2[L8_2] = L10_2
      if "name" == L9_2 then
        L10_2 = L1_2[L8_2]
        L10_2.item = L7_2
      elseif "color" == L9_2 then
        L10_2 = L1_2[L8_2]
        L10_2.texture = L7_2
      end
    end
  end
  return L1_2
end
L9_1.convertOutfitFromESXToQBCore = L10_1
